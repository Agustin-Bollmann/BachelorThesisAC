---
title: A Survey of Remote Automotive Attack Surfaces
authors: Chris Valasek, Charlie Miller
year: 2014
---

# A Survey of Remote Automotive Attack Surfaces
##### Chris Valasek, Charlie Miller (2014)
[Zotero-Link](zotero://select/items/@valasekSurveyRemoteAutomotive2014)

Tags: #Remote #PhysicalAttack #PrivilegeEscalation #Spying #BrakeAttack #RKE #KeyFob #Theft #Telematics #RemoteAttack #Apps #CarRatings #CAN #Injection #Encryption #Authentication #V2V #V2I #Segregation #Isolation #Detection #IDS 

>[!ABSTRACT]-
>


---

# Summary

- The paper provides a detailed survey of potential remote attack vectors in vehicles, including **Bluetooth**, **Telematics**, **Wi-Fi**, and other wireless communication systems. It discusses how attackers can exploit these vectors to gain access to vehicle networks and perform unauthorized actions such as **CAN message injection**.
- The authors explain the **three stages** of a remote automotive attack: initial access through a remote endpoint, bridging compromised ECUs to access critical systems, and injecting messages to control physical vehicle functions like steering or braking.
- The paper also includes a review of specific models (e.g., Audi, BMW, Jeep) and highlights the evolution of vehicle network architectures over the years, illustrating how increased connectivity has expanded the attack surface.
- The authors propose defensive strategies, such as the use of **Intrusion Detection Systems (IDS)** and secure network architecture designs to reduce the risk of remote attacks.

# Relevancy

- **Covers Remote Attack Techniques**: The survey provides comprehensive insights into various remote attack vectors, directly aligning with your focus on understanding and testing vehicle vulnerabilities in autonomous and connected systems.
- **Focuses on CAN Message Injection**: The description of remote access methods and CAN message injection aligns with your thesis's goal of testing CAN manipulation using simulation tools like CARLA.
- **Highlights Defense Mechanisms**: The discussion on IDS and secure architecture offers useful strategies that could support the development of secure frameworks within your simulation environment.

# Notable Sections and Pages

- **Anatomy of a Remote Attack (Pages 4-6)**: Details the stages of a remote attack and how attackers can move from initial access to controlling critical vehicle functions, essential for structuring your experiments.
- **Remote Attack Surfaces of Automobiles (Pages 7-19)**: Provides specific attack vectors for different models, offering practical insights into the vulnerabilities of vehicles you may simulate.
- **Defending Against Remote Attacks (Pages 87-88)**: Discusses strategies like CAN injection mitigations and IDS implementations, relevant for developing secure testing environments in your thesis.

# Recommendations

This paper is a critical addition to your thesis literature. It provides a thorough analysis of remote attack surfaces and methods for securing automotive networks, directly applicable to your work on manipulating CAN traffic and understanding vulnerabilities in autonomous vehicles. I recommend citing it for its detailed examination of attack vectors and defense mechanisms.

---

# Annotations  
(11/5/2024, 7:17:39 PM)

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=4&annotation=XCVL4M5J) “Safety critical attacks against modern automobiles generally require three stages. The first stage consists of an attacker remotely gaining access to an internal automotive network. This will allow the attacker to inject messages into the cars networks, directly or indirectly controlling the desired ECU. You can imagine such an attack occurring by sending some kind of wireless signal and compromising a listening ECU, subsequently injecting code. Researchers from the University of Washington and the University California San Diego were able to get remote code execution on a telematics unit of a vehicle by exploiting a vulnerability in the Bluetooth stack of an ECU and separately compromising a cellular modem [3]. Depending on the desires of the attacker, this might be the end of the attack, for example the compromised ECU may control a microphone used to eavesdrop on the vehicle.” ([Valasek and Miller, 2014, p. 4](zotero://select/library/items/YDVTLH52)) 

Remote

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=4&annotation=F5ZZJHT2) “Cyber physical attacks (attacks that result in physical control of various aspects of the automobile), on the other hand, will require interaction with other ECUs. It is difficult to measure how susceptible a particular vehicle is to remote attacks since it depends on the presence (or absence) of vulnerabilities. What we can measure (and do measure in this paper) is the attack surface of each vehicle and use this information as a proxy to estimate susceptibility to the first stage of remote attack.” ([Valasek and Miller, 2014, p. 4](zotero://select/library/items/YDVTLH52)) 

physical

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=5&annotation=A5NY8NFH) “In some vehicles, this may be trivial, but in many designs, the ECU which was compromised remotely will not be able to directly send messages to these safety critical ECUs. In this case, the attacker will have to somehow get messages bridged from the network of compromised ECU to the network where the target ECU lives. This might require tricking the gateway ECU or compromising it outright. The academic researchers mentioned above demonstrated a way to compromise the bridge ECU in their vehicle to get from the less privileged CAN network to the one containing the ECU in charge of braking. In this paper we discuss the various architectures of different vehicles and examine the effect these topologies may have on a remote attack.” ([Valasek and Miller, 2014, p. 5](zotero://select/library/items/YDVTLH52)) 

Privelege Esacaltion

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=5&annotation=HMZ4LPU7) “After the attacker has wirelessly compromised an ECU and acquired the ability to send messages to a desired target ECU, the attacker may communicate with safety critical ECUs. The final step is to make the target ECU behave in some way that compromises vehicle safety. This involves reverse engineering the messages on the network and figuring out the exact format to perform some physical action. Since each manufacturer (and perhaps each model and even each year) use different data in the messages on the bus, the message reverse engineering process requires a large amount of work and will be manufacturer specific. For example, the messages to lock the brakes on one manufacturer’s vehicle likely won’t work on a vehicle from a different manufacturer.” ([Valasek and Miller, 2014, p. 5](zotero://select/library/items/YDVTLH52))

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=6&annotation=6DXYGW6B) “There are a number of remote attacks that have nothing to do with sending messages on automotive networks such as CAN, a large focus of this paper. These mostly fall into two categories. The first are attacks where the remotely attacked ECU is the final target of the attack. For example, a remote attack against the telematics unit may allow the attacker to listen and record conversations in the vehicle. If this is all the attacker wants, then the automotive network containing the telematics unit is likely to be irrelevant.” ([Valasek and Miller, 2014, p. 6](zotero://select/library/items/YDVTLH52)) 

spying

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=6&annotation=SYYSXPTS) “The second type of attack is one that doesn’t actually get remote code execution, but still impacts the physical behavior of the vehicle. An example of this might include tricking the sensors of the vehicle. One could imagine sending radar signals that interfere with a car’s collision detection system and cause it to think a collision is imminent, resulting in the brakes being engaged.” ([Valasek and Miller, 2014, p. 6](zotero://select/library/items/YDVTLH52)) 

brake

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=12&annotation=F8MYJHTX) “Key fobs contain a short-range radio transmitter that communicates with an ECU in the vehicle. The radio transmitter sends encrypted data containing identifying information from which the ECU can determine if the key is valid and subsequently lock, unlock, and start the vehicle. For example, in the Toyota Prius, the smart key sends a signal to a receiver, which in turn sends the information to the Smart Key ECU that is connected to the CAN and LIN buses.” ([Valasek and Miller, 2014, p. 12](zotero://select/library/items/YDVTLH52)) 

RKE, Keyfob

![](D5JDXUAH.png)  
>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=12&annotation=D5JDXUAH)  
([Valasek and Miller, 2014, p. 12](zotero://select/library/items/YDVTLH52)) 

Keyfob, Theft

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=18&annotation=ZNKKUGKN) “Analysis: This is the holy grail of automotive attacks since the range is quite broad (i.e. as long as the car can have cellular communications). Even though a telematics unit may not reside directly on the CAN bus, it does have the ability to remotely transfer data/voice, via the microphone, to another location. Researchers previously remotely exploited a telematics unit of an automobile without user interaction [3].” ([Valasek and Miller, 2014, p. 18](zotero://select/library/items/YDVTLH52)) 

Telematic, Remote

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=19&annotation=8W78IK7H) “As cars move into the future, they are being more connected with features normally found in desktop computers like apps and even web browsers. The 2014 Jeep Cherokee even has a Wi-Fi hotspot with open ports (when not using encryption).” ([Valasek and Miller, 2014, p. 19](zotero://select/library/items/YDVTLH52)) 

Apps

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=84&annotation=R69TYSBD) “As you can see, each manufacturer differs not only in remote communications and cyber physical systems, but also network architecture. This means that remote compromises will generally be different for each manufacturer and each car.” ([Valasek and Miller, 2014, p. 84](zotero://select/library/items/YDVTLH52))

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=84&annotation=PR9Z6IQU) “There are a large number of ECUs in 2014 vehicles from 19 (Dodge Viper) to 98 (Range Rover)  The remote attack surface and the number of cyber physical features has increased as time has gone on.  The number of different networks in cars (complexity of architecture) has increased over time.  The addition of ECUs over time is a result of manufacturers requiring more technology, specifically around user experience and safety, which is most easily added to the vehicle by patching it into the multiplex systems available, instead of adding new wiring or networks.  Vehicles are having common desktop technology, such as web browsers and incar apps, providing a familiar attack surface known to attackers for many years [12].  The TPMS and RKE are the most likely ECUs with remote attack surface on the same segment as cyber physical ECUs.  6 out of 14 (42%) of the 2014 vehicles we looked at have no separation between at least one cyber physical ECU and one with remote attack surfaces.  The diagrams of the cars examined (above) show network topologies with a large degree of variance. Some vehicles separate certain functionality while others had most of the technology and cyber physical components on the same bus.  On the other hand, Cars manufactured in the same region tend to have similar network topologies. We’ve seen common architectures in Japanese (Toyota & Infiniti), German (Audi/VW & BMW), and American (GM & Ford) automobiles. This could be due to similar thought process or engineer turnover.  Cyber physical controls, such as Adaptive Cruise Control, are more prevalent in newer automobiles. Much of the new technology has to do with customer demand for more safety conscious automobiles. Permitting computers to perform physical actions make the driver safer, but at the same time, give an attacker built-in functionality of which to abuse to bring potential harm to the passenger and vehicle.  Our survey shows newer cars have more cyber physical features but many times are segmented on different computer networks. Since we did not have all of the cars reviewed in this paper we cannot say definitely how big of an obstacle segmented networks would put in front of an attacker. From our perspective, we have rarely seen segmentation used for security boundaries, instead network segmentation is used for non-communicable network buses.  ‘How patchable is the modern automobile’? Right now, we’ve received several recall notices for the 2010 Ford Escape and the 2010 Toyota Prius. All of them required us to bring the vehicle to a local dealership. It does not appear that many manufacturers support Over-the-Air (OTA) update as this time (July 2014). We’ve seen patching wasn’t nearly as effective until Microsoft automated the Windows Update functionality and assume vehicles will not be any different.” ([Valasek and Miller, 2014, p. 84](zotero://select/library/items/YDVTLH52))

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=85&annotation=I88WXY5R) “Most Hackable 1. 2014 Jeep Cherokee 2. 2015 Cadillac Escalade 3. 2014 Infiniti Q50 Least Hackable 1. 2014 Dodge Viper 2. 2014 Audi A8 3. 2014 Honda Accord” ([Valasek and Miller, 2014, p. 85](zotero://select/library/items/YDVTLH52))

![](6ZJW6C7B.png)  
>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=86&annotation=6ZJW6C7B)  
([Valasek and Miller, 2014, p. 86](zotero://select/library/items/YDVTLH52)) 

Car ratings

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=87&annotation=NXUJGK3E) “Once an attacker gets code running on an ECU, it is possible to make it harder to for the attacker to inject CAN messages immediately. For example, the Bluetooth stack probably does not need the ability to send CAN messages (but we can’t completely rule anything out). It seems telematics units in the future may run Android which would have this capability. However, as we’ve seen with other sandbox technologies (and Android in particular), there is always a way to escape these sandboxes or elevate privileges, say through a Linux kernel exploit, to bypass these mechanisms.” ([Valasek and Miller, 2014, p. 87](zotero://select/library/items/YDVTLH52)) 

can, injection

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=87&annotation=W2LJIVH7) “One idea often suggested is to cryptographically verify CAN messages to make injection difficult. The idea is that only the ECUs (and mechanics tools) have the keys and so a random attacker wouldn’t be able to send valid CAN messages on the compromised automotive network. This idea may present obstacles for attackers who add rogue devices to automotive networks, but in the context of a remote attack, the attacker is executing code on a compromised ECU. At this point, the keys are also compromised, or at least the ability to send valid CAN messages. So this idea doesn’t seem to present much of an obstacle in the remote attack scenario, which is most concerning to consumers and manufacturers alike.” ([Valasek and Miller, 2014, p. 87](zotero://select/library/items/YDVTLH52)) 

encryption, authentication

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=87&annotation=K2DXS3R8) “As we’ve seen by looking at existing automotive architectures, some automotive networks present more of a challenge to attack safety critical ECUs than others. This forwards the idea that manufacturers should design their automotive networks in such a way to isolate those ECUs with remote functionality from those that control safety critical features. This is a great idea and is definitely recommended. However, it is not a panacea and does not solve all the problems. First, major architectural changes like this are expensive, take years to implement, and most likely aren’t going to be happening anytime soon. One of the underlying problems is that while you can isolate these two types of ECUs, some communication between them is likely. This means there will have to be some kind of bridge/gateway between them. This bridge ECU then opens up the possibility of being tricked into forwarding messages or straight up becoming the target of compromise. While this does add an additional barrier (for example, the academic researchers cited throughout this work were able to move from one network to the other by compromising the bridge), it is not going to be perfect, and may even become the single point of failure. Additionally, with more connectivity technology, including Vehicle-to-Vehicle (V2V) and Vehicle-to-Infrastructure (V2I), becoming more prevalent, there seems to be the requirement of remote communications devices talking to cyber physical components. For example, for V2V collision avoidance systems to work correctly a wireless component must receive a signal and send messages that control braking and/or steering.” ([Valasek and Miller, 2014, p. 87](zotero://select/library/items/YDVTLH52)) 

V2V, V2I, Segregation, Isolation

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=88&annotation=UJF3G3TK) “A final suggestion is to add attack detection and prevention technology into critical CAN networks. This represents an inexpensive and accurate way to greatly improve the security of CAN networks and can be added to vehicles immediately, especially since most major cyber physical components rely on CAN (although FlexRay and other communications protocols are gaining traction). While attack detection typically doesn’t work well in enterprise network environments, initial data shows that it works quite well in automotive networks. The primary difference is that automotive networks are highly regular and only involve computers talking with computers, without human interaction. Furthermore, while typical software exploits can vary widely and can be designed to be stealthy, this doesn’t appear possible in automotive networks. All known CAN injection attacks (both ours and the academic researchers) all take one of two forms. They are either CAN diagnostic messages or they are standard message with a highly inflated send rate. While it is obvious why diagnostic messages might be dangerous, it may need a quick discussion of why normal messages used for attack must be transmitted at a much higher rate than normal. The rate must be higher because there are always messages going from ECUs to ECUs. Unless the attacker happens to be on the ECU that sends the particular message the attacker wishes to inject, the original ECU will still be sending the original message along with the attacker. That means the attacker can send the same message but the target ECU will be receiving messages from the original ECU and the attacker. At this point, the rate of the CAN messages are higher than normal. But, even more so, in practice, the way an attacker ensures the target ECU listens to the injected messages and not the original ones is to send them even faster than the original ECU. Regardless of the normal message injection attack, the rate of messages will be twice as high as normal and in practice 20100x higher than normal. The point is that abnormal messages occur whether the attacker is sending diagnostic messages or normal messages at an increased rate, permitting easy detection and possible prevention of attacks. The other interesting aspect of detection, unlike the other possibilities mentioned here, is that individual researchers can build and test these devices. All of our attacks are published and important aspects of the academics are public as well. As a proof of concept, we built a small device that plugs into the OBD-II port of a car, learns traffic patterns, and then detects anomalies. When the device does detect something, it short circuits the CAN bus, thus disabling all CAN messages, see Figure below.” ([Valasek and Miller, 2014, p. 88](zotero://select/library/items/YDVTLH52)) 

Deteciton, IDS

>[Go to annotation](zotero://open-pdf/library/items/7N4VNG7Y?page=90&annotation=2W988KFB) “Remote attacks against vehicles having physical implications will typically need three stages. These three stages are remote compromise; sending injected messages to cyber-physical components, and making the destination ECU perform some unsafe action. In this paper, for a large variety of vehicles, we identified the remote attack surface to estimate how difficult remote compromise might be. We then examined the architecture of the internal networks of each vehicle, identifying the location of ECUs which process external inputs as well as ECUs that contain capabilities to cause physical changes to the vehicle. This will give an indication on how easy it would be to get messages from the former to the latter. Finally, we identify the features that the car possesses which may help in taking physical control of the vehicle. Combining this data, we can make rough estimates on the difficulty of remote exploitation for these vehicles. Since these types of remote attacks will necessarily be multi-stage, we recommend a defense in depth strategy that includes detection of message injection as part of an overall safety strategy.” ([Valasek and Miller, 2014, p. 90](zotero://select/library/items/YDVTLH52))