---
title: "Self-Aware Cybersecurity Architecture for Autonomous Vehicles: Security through System-Level Accountability"
authors: Akwasi Adu-Kyere, Ethiopia Nigussie, Jouni Isoaho
year: 2023
---

# Self-Aware Cybersecurity Architecture for Autonomous Vehicles: Security through System-Level Accountability
##### Akwasi Adu-Kyere, Ethiopia Nigussie, Jouni Isoaho (2023)
[Zotero-Link](zotero://select/items/@adu-kyereSelfAwareCybersecurityArchitecture2023)

Tags: #Vulnerabilities #V2X #Future #CV #Countermeassures #TEE #2F #WhiteList #SecureBoot #Tampering #TamperProof #AccessControl #Firewall #IDS #VSOC #SAELevels #SelfAware #BlackBox 

>[!ABSTRACT]-
>The inherent dynamism of recent technological advancements in intelligent vehicles has seen multitudes of noteworthy security concerns regarding interactions and data. As future mobility embraces the concept of vehicles-to-everything, it exacerbates security complexities and challenges concerning dynamism, adaptiveness, and self-awareness. It calls for a transition from security measures relying on static approaches and implementations. Therefore, to address this transition, this work proposes a hierarchical self-aware security architecture that effectively establishes accountability at the system level and further illustrates why such a proposed security architecture is relevant to intelligent vehicles. The article provides (1) a comprehensive understanding of the self-aware security concept, with emphasis on its hierarchical security architecture that enables system-level accountability, and (2) a deep dive into each layer supported by algorithms and a security-specific in-vehicle black box with external virtual security operation center (VSOC) interactions. In contrast to the present in-vehicle security measures, this architecture introduces characteristics and properties that enact self-awareness through system-level accountability. It implements hierarchical layers that enable real-time monitoring, analysis, decision-making, and in-vehicle and remote site integration regarding security-related decisions and activities.


---

# Summary

- The paper proposes a **self-aware cybersecurity architecture** designed for autonomous vehicles (AVs) that emphasizes **system-level accountability**. It introduces a hierarchical architecture consisting of **monitoring, analysis, decision-making**, and **visualization layers** that work in coordination to detect and respond to security threats in real time.
- The architecture integrates a security-specific **black box** and a **Virtual Security Operation Center (VSOC)**, enabling continuous monitoring, incident archiving, and external interaction for AVs.
- The framework addresses the limitations of traditional static security models by incorporating **dynamic monitoring** and **adaptive response mechanisms** to cope with the evolving nature of cyber threats in AV environments.

# Relevancy

- **Introduces Advanced Security Architectures**: The hierarchical architecture proposed aligns with your objective of exploring and testing new cybersecurity vulnerabilities and defenses in autonomous vehicles using simulations like CARLA.
- **Focuses on Real-Time Monitoring and Response**: The integration of a black box and VSOC for real-time monitoring provides insights into creating similar monitoring setups in your experiments to validate the effects of CAN traffic manipulation.
- **Emphasizes System Accountability**: The emphasis on system-level accountability and dynamic response aligns with your need to understand and simulate advanced defensive measures in autonomous vehicle systems.

# Notable Sections and Pages

- **Section 1.2: Research Objectives and Contributions (Pages 2-3)**: Details the motivation behind the proposed architecture and the need for adaptive security measures in AVs. This is foundational for developing your thesis framework.
- **Section 3: Proposed Self-Aware Security Architecture (Pages 5-7)**: Explains the components of the architecture, including monitoring, analysis, and decision modules, which are relevant for designing similar mechanisms in CARLA.
- **Section 5: Decision and Critical Incident Handling (Pages 9-10)**: Describes how the decision modules operate, including system incident and critical incident controllers, essential for structuring attack scenarios and responses in your experiments.

# Recommendations

This paper is an excellent addition to your thesis literature. It provides a detailed examination of advanced security architectures and real-time monitoring approaches that are crucial for your work on CAN traffic manipulation. I recommend citing it for its comprehensive explanation of a dynamic and adaptive security framework.

---

# Annotations  
(11/2/2024, 1:10:45 PM)

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=3HR42RP5) “Recent projections predict 115 million connected vehicles (CVs) by 2025, while the frequency of attacks on modern cars has increased by 225% in the past three years [12]. These vehicular networks will rely on complex interactions between vehicles, intelligent gadgets, the Internet of Things (IoTs), people, and external infrastructure (vehicle-to-everything (V2X)).” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

vulnerabitlities, V2X, Future, CV

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=YJTHLW4F) “Trusted execution environments (TEEs) are utilized in low-energy embedded devices in addition to other cloud solutions and desktop computers as an isolated execution environment and platform [21]. Its implementation is to leverage secure application execution with the provided enclaves and integrity as a separate secure operating system (OS) in isolation specific to its hardware environment [22].” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

Countermeassures, TEE

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=JFYMMKR7) “Two-factor authentication (2F) is a widely used provision of assurance of the claimed identity requiring additional attestations or proof. Two independent factors are involved through verification and authentication processes to enhance, restrict, or prevent unauthorized access [23] to services and client-side infrastructural resources such as vehicular remote applications and systems.” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

2F

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=MS2E57IM) “White-listing defines a set of rules or pre-selective applications, processes, or system activity permitted for execution at runtime or allowed to run when required [24]. Vendors deploy this solution in vehicles to restrict user space and system domain access. It also extends to hardware-based, native OS implementation and third-party add-ons [25].” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

Whitelisting

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=GHEMR5ZG) “Secure boot using a hardware–software combination ensures that all the software implementations are from a trusted source with vendor authentication to ensure that only the right OS is booted [26]. Secure boot, often combined with whitelisting, is used for restricting and applying selective installations of applications and firmware.” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

SecureBoot

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=IMIAPDIP) “Tamper-proofing sensors are used in modern vehicles to detect various forms of tampering [27] in several sections, including the electronic control unit (ECU), engine, and other in-vehicle controls. It is a widespread security measure with external add-ons from third-party providers.” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

Tamperproofing

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=CJCVD2QZ) “Access control is a common form of restricting unauthorized access to create roles according to the job functions performed to grant permissions (access authorization) to that role [28]” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

Access Control

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=L6U334KQ) “Firewall deployment prevents external attacks on the in-vehicle systems, such as the infotainment system. It is applicable in several ways in a vehicular context at the circuit level, application level, and filtering level [29].” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

Firewall

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=3&annotation=EH6SMKEN) “Intrusion detection systems monitor in-vehicle networks for suspicious activities and are often combined with the other security measures mentioned in this table.” ([Adu-Kyere et al., 2023, p. 3](zotero://select/library/items/W38M4FA4)) 

IDS

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=7&annotation=54IDUEFF) “In state-of-the-art vehicular security, white-listing, access control, and firewall deployments exist from vendors. However, some of these implementations have precise tailoring to unique instances and situations lacking security dynamism in security based on the situation. Furthermore, with the lifespan of vehicles and continuity factors influencing security, connected, intelligent, and autonomous vehicles, firewall implementation, for example, needs a dynamic security mechanism that can be assistive via analysis at either the circuit level, application level, or packet filtering level [29]. The capability of making security decisions in dilemmas within the vehicular ecosystem and vehicle-to-everything internal and external communication and transaction is vital in such a security mechanism or solution.” ([Adu-Kyere et al., 2023, p. 7](zotero://select/library/items/W38M4FA4)) 

Countermeassures

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=12&annotation=J6YNEJ2W) “The VSOC container represents the future trends for intelligent, connected, and autonomous vehicles in the context of security as subscription-based models gradually become the norm. In SAE level 3 to level 5, autonomous vehicles by popular and leading companies such as Waymo, Tesla, and Baidu have features such as remote assistance, remote management, redundant controls, and safe pull-over. In their routine operations, some of these services require over-the-air updates, operational status, and other requirements and characteristics, making remote operational centers visualize the statistics in real time for security impacts. Human-to-machine interfaces are applicable for such situations with emphasis on our three assumptions.” ([Adu-Kyere et al., 2023, p. 12](zotero://select/library/items/W38M4FA4)) 

VSOC, SAELevels

>[Go to annotation](zotero://open-pdf/library/items/7YKXI5NE?page=13&annotation=59ZT5KJI) “In this work, we provided a systematic overview and exploration of security dynamism, self-awareness, and adaptiveness in the vehicular ecosystem. Based on our exploration, we proposed a hierarchical self-aware security architecture that effectively establishes accountability at the system level. In addition, we presented the sub-components of the self-aware architecture, their algorithms, and the integration of a security-specific black box. To this end, this work extended the existing state-of-the-art by a self-aware architecture that addresses security complexities and challenges concerning dynamism, adaptiveness, and self-awareness.” ([Adu-Kyere et al., 2023, p. 13](zotero://select/library/items/W38M4FA4)) SelfAware, 

BLackbox