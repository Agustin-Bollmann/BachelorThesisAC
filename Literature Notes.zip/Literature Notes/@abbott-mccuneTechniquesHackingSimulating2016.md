---
title: Techniques in hacking and simulating a modem automotive controller area network
authors: Sam Abbott-McCune, Lisa A. Shay
year: 2016
---

# Techniques in hacking and simulating a modem automotive controller area network
##### Sam Abbott-McCune, Lisa A. Shay (2016)
[Zotero-Link](zotero://select/items/@abbott-mccuneTechniquesHackingSimulating2016)

Tags: #CAN #CIA #Fuzzing #IDS #Recall #RemoteAttack #HackingTool #Ownstar #SafetySecurity 

>[!ABSTRACT]-
>This research will demonstrate hacking techniques on the modern automotive network and describe the design and implementation of a benchtop simulator. In currently-produced vehicles, the primary network is based on the Controller Area Network (CAN) bus described in the ISO 11898 family of protocols. The CAN bus performs well in the electronically noisy environment found in the modern automobile. While the CAN bus is ideal for the exchange of information in this environment, when the protocol was designed security was not a priority due to the presumed isolation of the network. That assumption has been invalidated by recent, well-publicized attacks where hackers were able to remotely control an automobile, leading to a product recall that affected more than a million vehicles. The automobile has a multitude of electronic control units (ECUs) which are interconnected with the CAN bus to control the various systems which include the infotainment, light, and engine systems. The CAN bus allows the ECUs to share information along a common bus which has led to improvements in fuel and emission efficiency, but has also introduced vulnerabilities by giving access on the same network to cyber-physical systems (CPS). These CPS systems include the anti-lock braking systems (ABS) and on late model vehicles the ability to turn the steering wheel and control the accelerator. Testing functionality on an operational vehicle can be dangerous and place others in harm’s way, but simulating the vehicle network and functionality of the ECUs on a bench-top system provides a safe way to test for vulnerabilities and to test possible security solutions to prevent CPS access over the CAN bus network. This paper will describe current research on the automotive network, provide techniques in capturing network traffic for playback, and demonstrate the design and implementation of a benchtop system for continued research on the CAN bus.


---

# Summary

- The paper discusses hacking techniques for automotive networks, emphasizing vulnerabilities in the **CAN bus** due to its initial design, which lacked security considerations. This has made it susceptible to remote and physical attacks.
- It details the creation of a **benchtop simulation system**, providing a controlled environment to test and demonstrate these hacking techniques, including **CAN traffic manipulation** and **replay attacks**.
- The researchers explore various **penetration testing frameworks** and attack vectors, emphasizing both physical (OBD-II port access) and remote attack strategies, as well as proposing mitigation strategies.

# Relevancy

This document is **highly relevant** to your thesis due to its detailed focus on:

1. **CAN Traffic Manipulation**: It explores methods for capturing, replaying, and injecting CAN messages, aligning well with your objectives in manipulating CAN traffic using simulation environments like CARLA.
2. **Simulation Setup**: The design of the benchtop simulator provides valuable insights that can be translated into your work with CARLA and Autoware.
3. **Penetration Testing Techniques**: The document outlines practical steps for hacking vehicles via physical and remote methods, which is crucial for your thesis on autonomous vehicle vulnerabilities.

# Notable Sections and Pages

- **Introduction and Background (Pages 1-3)**: Provides foundational information on CAN bus protocol vulnerabilities and the rationale for using simulations. Useful for establishing the theoretical background of your thesis.
- **Benchtop Simulator (Section III, Subsection A, Pages 5-7)**: Discusses the hardware used in their simulation system, including CAN adapters and OBD-II setups, which are relevant to building a similar setup in a simulated environment like CARLA.
- **Penetration Testing Techniques (Section IV, Subsection C, Pages 8-9)**: Describes the methodologies and scenarios for testing vulnerabilities, focusing on both physical and remote access. This section directly informs your approach to manipulating CAN traffic and testing security measures.

# Recommendations

This paper is a valuable addition to my thesis. It should be cited for:

- **CAN bus vulnerabilities and manipulation techniques**: The detailed methodologies provided can directly support your experiments.
- **The use of benchtop simulation as a safe testing environment**: This insight is particularly useful for translating testing results from simulation to real-world scenarios.

---

# Annotations  
(10/27/2024, 4:13:30 PM)

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=2&annotation=8UHCFD6E) “The CAN bus is a multi-master, asynchronous, message broadcast system designed to operate in a noisy environment. The CAN protocol is internationally standardized in ISO 118981[5], and it comprises the data link layer and physical layers of the 7-layer ISO/OSI reference model. CAN is based on the broadcast communication mechanism, which is based on a message-oriented transmission protocol. It defines message contents rather than nodes and node addresses. Every transmitted message has a unique message identifier, the arbitration identifier (ARBid), within the whole network, much like a media access control (MAC) address, and it defines the content and the priority of the message. CAN bus arbitration enforces carrier sense multiple access/collision avoidance (CSMA/CA), which prevents collisions on the bus when several nodes compete for access, also known as bus arbitration [1]. The various CAN buses operate at different bitrates depending on the cost, performance, safety, and data-rates required on the network. The normal CAN bus data-rates are 125 kbps, 250 kbps, 500 kbps, and 1 Mbps, but other data rates are used for manufacturer-specific implementations.” ([Abbott-McCune and Shay, 2016, p. 2](zotero://select/library/items/JDBZ2HM4)) 

CAN Bus Definition and Function

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=Z4TRA6DP) “Hoppe et al. [4]compares some scenarios to the CIA–triad, which is predominately an IT security concept, but as vehicles become computer-based mobility platforms the concepts can apply. In 2013, the Information Assurance and Security (IAS) literature was reviewed and an extension to the CIA-triad was proposed. The IAS-octave includes Confidentiality, Integrity, Availability, Accountability, Auditability, Authenticity/Trustworthiness, Non-repudiation and Privacy. Table III: IT security aspects mapped to automotive network Security Concept Definition Confidentiality Is communicated information read by unauthorized nodes? Integrity Is there communicated information which is semantically incorrect? Availability Is information accessible by all requiring nodes? Authenticity Has the communicated information been created by an authorized node? Non-repudiation Did a node communicate certain information?” ([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

CIA triad extension


![](7V37L7AJ.png)  
>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=7V37L7AJ)  
([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

CIA Extended Table

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=GCPRUVKZ) “Koscher et al. [17] and Checkoway et al. [18] are the seminal papers in the field of automotive vulnerability assessment. In the first paper, they evaluated two identical vehicles on a closed test track, on blocks, and on the test bench by removing specific components. A custom program, CARSHARK, was created to take advantage of the vulnerabilities found. Vulnerabilities were found during monitoring of the CAN bus while plugging in the various components to determine the messages associated with the component. After determination of the arbitration identifier, introducing packets containing a valid identifier but random data caused actuation in the cyber-physical vehicle. Elimination of the replay attack would prevent this fuzzing capability and the associated responses which led to targeting of specific subsystems. Additionally the authors were able to inject malicious code into the telematics system allowing them to send custom commands on the CAN bus.” ([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

CAN Bus Manipulation

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=BCHKWZ54) “Miller and Valasek [16] extended the work of Kocher et al. by implementing new attacks and building a framework that will allow the construction of tools for automotive systems. This would allow researchers to monitor and demonstrate vehicle vulnerabilities. They successfully dissected a Ford Escape and Toyota Prius showing they could control almost all functionality in the vehicles. The research team were able to demonstrate their attacks while the car was being driven. Histograms of the CAN bus demonstrated the cyclic nature of some messages and by detecting diagnostic packages during normal operation, anomalies can be detected. They concluded that automobiles are designed with safety in mind but one cannot have safety without security in mind. Their goal was to show the need for safer ECU’s in a hostile CAN bus network and the ability to detect and stop attacks on the vehicle network.” ([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

Ford Escape and Toyota Prius Dissection, Attackers can save hacking blueprints for each model. No Safety without Security. Intrustion Detection

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=GRM7L6B9) “Miller and Valasek [19] additionally conducted a survey of numerous modern vehicles looking at how the remote attack surfaces have evolved over time. They quantify the attack surfaces of the cyber-physical features installed in the vehicle and then recommend some defensive strategies such as an Intrusion Detection System (IDS) to prevent the attacks on the CAN bus. The culmination of their research occurred when they were able to remotely attack a vehicle by re-flashing the firmware of a microprocessor in the infotainment unit and send custom CAN bus commands to affect the driving of a vehicle. This led to the recall of 1.4 million vehicles.” ([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

Remote attack evolution. IDS Recommendation, Vehicle Recall

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=G9BFNG9D) “Samy Kamkar developed the hacking tool named Ownstar which can locate, unlock and remote start any vehicle with OnStar Remote Link after intercepting communications between the RemoteLink mobile app and OnStar servers.” ([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

Samy Kamkar Hacking Tool Ownstar

>[Go to annotation](zotero://open-pdf/library/items/2ZUZS72P?page=3&annotation=RTE56J2F) “The lack of security in the creation of the CAN bus protocol, which is a robust communications protocol for noisy environments like the automobile, has the automobile industry feverishly adding on security to provide a quality product which is safe to their consumers. The CAN bus is a message-based real-time network which does not conform to the nonrepudiation concept, does not ensure the authenticity of the node, and does not provide confidentiality due to the broadcast nature to all nodes on the network.” ([Abbott-McCune and Shay, 2016, p. 3](zotero://select/library/items/JDBZ2HM4)) 

CAN CIA Failures

