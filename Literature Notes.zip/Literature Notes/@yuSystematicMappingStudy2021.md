---
title: A Systematic Mapping Study on Security Countermeasures of In-Vehicle Communication Systems
authors: Jinghua Yu, Stefan Wagner, Bowen Wang, Feng Luo
year: 2021
---

# A Systematic Mapping Study on Security Countermeasures of In-Vehicle Communication Systems
##### Jinghua Yu, Stefan Wagner, Bowen Wang, Feng Luo (2021)
[Zotero-Link](zotero://select/items/@yuSystematicMappingStudy2021)

Tags: #Telematics #Infotainment #Vulnerabilities #Apps #Attackers #ECU #CAN #IDS #FlexRay #Ethernet #Encryption #Countermeassures #Papers #Countries

>[!ABSTRACT]-
>The innovations of vehicle connectivity have been increasing dramatically to enhance the safety and user experience of driving, while the rising numbers of interfaces to the external world also bring security threats to vehicles. Many security countermeasures have been proposed and discussed to protect the systems and services against attacks. To provide an overview of the current states in this research field, we conducted a systematic mapping study (SMS) on the topic area “security countermeasures of in-vehicle communication systems.” A total of 279 papers are identified based on the defined study identification strategy and criteria. We discussed four research questions (RQs) related to the security countermeasures, validation methods, publication patterns, and research trends and gaps based on the extracted and classified data. Finally, we evaluated the validity threats and the whole mapping process. We found that the studies in this topic area are increasing rapidly in recent years. However, there are still gaps in various subtopics like automotive Ethernet security, anomaly reaction, and so on. This study reviews the target field not only related to research findings but also research activities, which can help identify research gaps at a high level and inspire new ideas for future work.


---

# Summary

- The paper conducts a **Systematic Mapping Study (SMS)** on security countermeasures for in-vehicle communication systems, identifying and analyzing **279 papers** related to this field. The aim is to categorize the security measures, evaluate their effectiveness, and identify research trends and gaps.
- The authors discuss countermeasures such as **anomaly detection**, **secure communication schemes**, and **system security design**, focusing mainly on **CAN bus networks**. The study finds that while research in anomaly detection and secure communication is prevalent, areas like **automotive Ethernet** and **anomaly reaction** are still underexplored.
- The study highlights that most countermeasures are evaluated through **prototyping and experiments**, often involving hardware devices for validation. The study also identifies security goals such as **authenticity**, **availability**, and **integrity** as the most frequently targeted objectives.

# Relevancy

- **Identifies Research Gaps in CAN Security**: The focus on CAN bus networks aligns with your thesis topic, providing a comprehensive overview of existing countermeasures and highlighting underexplored areas like anomaly reaction.
- **Offers a Structured Review of Countermeasures**: The systematic mapping approach gives you a detailed look at the effectiveness of various countermeasures, helping you position your work within the broader context of current research.
- **Emphasizes Security Goals and Evaluation Methods**: Understanding the focus on authenticity and availability will help tailor your simulation experiments, while the emphasis on prototyping provides practical guidance for your testing methodology.

# Notable Sections and Pages

- **Section 3.4: Data Extraction and Classification (Pages 102-105)**: Provides insights into the categorization and validation of countermeasures, relevant for structuring your experiments.
- **Section 4.2: Research Trends and Gaps (Pages 110-114)**: Highlights the focus areas and gaps, directly applicable to refining your research focus on CAN manipulation.
- **Charts and Visualizations (Pages 107-112)**: Visual data showing the distribution of research types, methods, and countermeasures, offering a quantitative perspective on the field.

# Recommendations

This paper is essential for your thesis. It provides a detailed map of existing research on CAN bus security and identifies gaps you can explore. I recommend citing it for its comprehensive analysis of countermeasures and its structured approach to evaluating in-vehicle communication system security.

---

# Annotations  
(11/7/2024, 11:45:08 PM)

>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=98&annotation=DB3ICGNZ) “The connected vehicle is a big trend in the automotive industry. A report from Juniper Research in 2018 predicted that 775 million consumer vehicles will be connected via telematics or by in-vehicle applications (apps) by 2023, rising from 330 million vehicles in 2018 [1, 2]. Another report from Frost and Sullivan indicates that connected vehicles will comprise nearly 86% of the global automotive market by 2025 [3, 4]. With various cyber interfaces, users can receive external information like entertainment streams, real-time traffic conditions, or the nearest gas station’s location to increase the user experience and driving safety. The vehicle can install or upgrade software or firmware remotely to add new features or fix bugs. Furthermore, the data can also be sent from the vehicle side. An SOS message can be triggered immediately for rescue when an accident happens. User’s customized data can be uploaded to the cloud for backup or management. The vehicle’s operation states can be collected by the manufacturers for product improvement or after-sales services. More service models will be continuously innovated with this exciting property.” ([Yu et al., 2021, p. 98](zotero://select/library/items/3T96SP8N)) 

Telematics, Infotainment, vulnerabilities, Apps

>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=98&annotation=CSR8WF3W) “However, intelligent connectivity also brings cybersecurity threats to stakeholders. The Upstream research team analyzed 633 publicly reported incidents since 2010, while there were 207 incidents in 2020 (by Nov. 25, 2020) [4] and 155 in 2019 (by Dec. 7, 2019) [2]. By analyzing these incidents, the researchers found that the majority of the attackers are black hat (54.6% in 2020) [4], who hack the system for personal gain or malicious purposes and cause losses to the stakeholders. Therefore, it is increasingly important and urgent to keep an eye on the security issues of modern cars.” ([Yu et al., 2021, p. 98](zotero://select/library/items/3T96SP8N)) 

Attackers,

>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=98&annotation=XRRJQ9LT) “Besides, the Upstream team also found that the Engine Control Unit (ECU)/ Telematics Control Unit (TCU)/Gateway (GW) and in-vehicle networks can be ranked as the eighth (4.27%) and ninth (3.75%) common attack vectors based on the same incident set [4]. Many researchers have proposed various countermeasures to protect the target systems against hacking attempts and also conducted surveys to investigate current research states of existing security countermeasures. However, no systematic mapping study (SMS) has been published according to our knowledge. They mainly investigated the concrete solutions but omitted the research activity patterns at a more general level (e.g., the research year and publication venue), which can reveal more information of the research state and inspire new research ideas.” ([Yu et al., 2021, p. 98](zotero://select/library/items/3T96SP8N)) 

ECU

>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=99&annotation=G2TE3LHD) “Several review articles have been published in this topic area. Hu and Luo [5] discussed the state-of-the-art techniques of secure communication for in-vehicle networks including message authentication, data encryption, and intrusion protection and concluded technical requirements of cryptographic mechanisms and intrusion detection policy. Zoppelt and Kolagari [6] described seven typical automotive security and dependability mechanisms, examined them with a set of known attacks, and led to the conclusion that most countermeasures against attacks are hardly effective.” ([Yu et al., 2021, p. 99](zotero://select/library/items/3T96SP8N))


>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=99&annotation=KSW7Z898) “Other than the reviews at a general level, some researchers focus on specific techniques. Loukas et al. [7] conducted a survey on the intrusion detection systems (IDS) of vehicles, proposed a classification scheme, and discussed learned lessons and open issues in relevant industries. Lokman, Othman, and Abu-Bakar [8] investigated the IDS implementation of the Controller Area Network (CAN) systems in four aspects (i.e., detection approaches, deployment strategies, attacking techniques, and technical challenges) and categorized them based on seven detection strategies. Grimm, Pistorius, and Sax [9] presented a classification of network monitoring techniques for security purposes and compared typical security measures in enterprise information technology systematically with the ones in the vehicle security field.” ([Yu et al., 2021, p. 99](zotero://select/library/items/3T96SP8N)) 

CAN, IDS

>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=99&annotation=HJKJWNPP) “Additionally, some reviews are on a certain type of communication media. Gmiden et al. [10] and Bozdal et al. [11] discussed the vulnerabilities of the CAN bus protocol and presented and compared various countermeasures against attacks. Kishikawa et al. [12] highlighted the vulnerabilities of the FlexRay and discussed countermeasures against spoofing attacks on FlexRay networks. Boatright and Tardo [13] examined the security aspects of the Ethernet AVB backbone and discussed various Ethernet security solutions including protocols, algorithms, and encryption mechanisms appropriate for vehicular requirements.” ([Yu et al., 2021, p. 99](zotero://select/library/items/3T96SP8N)) 

FlexRay, Ethernet, encryption

>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=105&annotation=N7GG82EW) “What Countermeasures Were Proposed or Evaluated for In-Vehicle Communication Systems? To identify which countermeasures are mostly focused on by researchers, we abstracted the main countermeasures from publications and counted the paper numbers. The anomaly detection” is the most popular topic among studies (94), followed by the “secure communication scheme” (89). Figure 5 shows all numbers of abstracted countermeasures with the research type distribution. Note that there may be a bias in the number of the “secure mechanism at app layer” class because authors may use other application-specific words (e.g., vehicle diagnostic) other than general keywords used in our search string.” ([Yu et al., 2021, p. 105](zotero://select/library/items/3T96SP8N))


![](TTRRZ6NM.png)  
>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=106&annotation=TTRRZ6NM)  
([Yu et al., 2021, p. 106](zotero://select/library/items/3T96SP8N)) 

Countermeassures

![](ZS5639UR.png)  
>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=107&annotation=ZS5639UR)  
([Yu et al., 2021, p. 107](zotero://select/library/items/3T96SP8N))


![](Y8U6XHTY.png)  
>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=109&annotation=Y8U6XHTY)  
([Yu et al., 2021, p. 109](zotero://select/library/items/3T96SP8N)) 

Papers

![](QNZGSAAW.png)  
>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=109&annotation=QNZGSAAW)  
([Yu et al., 2021, p. 109](zotero://select/library/items/3T96SP8N)) 

Papers

![](AV3Q6T9M.png)  
>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=110&annotation=AV3Q6T9M)  
([Yu et al., 2021, p. 110](zotero://select/library/items/3T96SP8N)) 

Papers

![](YTVBLSAD.png)  
>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=111&annotation=YTVBLSAD)  
([Yu et al., 2021, p. 111](zotero://select/library/items/3T96SP8N))


>[Go to annotation](zotero://open-pdf/library/items/VBFMLQ2J?page=114&annotation=DJTZDXMT) “In this mapping study, we first worked out the systematic workflow according to a widely used guideline and defined strategies and criteria of study identification and data extraction steps. By following the work protocols, we identified 279 related papers, extracted data from the metadata and full text of selected papers, and visualized the abstracted and classified data by (stacked) bar or bubble charts. Finally, we discussed the validity threats of this mapping and evaluated the whole study process. The complete paper list with classified data has been uploaded to a public repository [25]. We mainly focus on four RQs in this study. For the RQ1, security countermeasures are collected and classified into nine classes, in which the anomaly detection” and “secure communication scheme” are the two top kinds of countermeasures discussed by researchers. Most of the countermeasures are mentioned in the PS papers, and the majority of them are specific to the CAN bus networks. Authenticity is the most mentioned security goal by researchers. For the RQ2, the majority of the validation approach is “prototyping and then doing experiments,” in which about 61% of validation processes require hardware devices other than computers. The effectiveness and efficiency are the two top properties concerned in the validation. For the RQ3, the publication numbers have been increased rapidly in recent years, but there’s a drop in 2020 due to the possible impact of the Covid-19 pandemic. The publication distribution of media types in different years is also displayed in a bubble chart to show the trends of each type. The top three countries in this field are the United States, China, and Germany, and the majority of research comes from the academic field. The distribution of various media types related to countries is presented to show which country contributes the most to a certain media type. For the RQ4, the future work mentioned in papers is counted and visualized, which shows that “further evaluation” is the most mentioned future work by authors. Finally, we concluded the trends and gaps based on all data we obtained in this study. The research interest on security issues has been increasing rapidly in recent years, but the publication number dropped in 2020 due to the pandemic (the most possible reason). Three research gaps are identified. First, there’s not much research related to the Ethernet, which has attracted much attention in the automotive industry recently. Second, the cooperation between academia and industry should be enhanced to solve real-world problems and accelerate the technique evolution. Third, the majority of research in this area focuses on a few subtopics (e.g., anomaly detection, protecting the CAN bus), and other countermeasures and media types with less attention (e.g., anomaly reaction, protecting the automotive Ethernet networks) are still worth being studied. The outcomes of this study, including an inventory of relevant papers and the extracted data, are useful references for research on a certain security technique or further SLRs in this topic area. The reported workflow, strategies, and criteria can also be served as examples for SMSs on other topics. This study, not like other review articles in this research field, investigates not only the research findings (i.e., security countermeasures and relevant validation methods) but also research activity patterns (e.g., publication years, countries, and author’s fields). From such a broader perspective, researchers can have an overview of the current research state at a higher level and identify research trends and gaps for better future work.” ([Yu et al., 2021, p. 114](zotero://select/library/items/3T96SP8N))