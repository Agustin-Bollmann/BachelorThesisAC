---
title: A Method for Constructing Automotive Cybersecurity Tests, a CAN Fuzz Testing Example
authors: Daniel S. Fowler, Jeremy Bryans, Madeline Cheah, Paul Wooderson, Siraj A. Shaikh
year: 2019
---

# A Method for Constructing Automotive Cybersecurity Tests, a CAN Fuzz Testing Example
##### Daniel S. Fowler, Jeremy Bryans, Madeline Cheah, Paul Wooderson, Siraj A. Shaikh (2019)
[Zotero-Link](zotero://select/items/@fowlerMethodConstructingAutomotive2019)

Tags: #RealAttacks #Fuzzing #CAN #CIA #CANPackets #Collision #ECU #Damage #Randomization #ReverseEngineering #Pentesting #OBD #ECU #CANFuzzer #DesignSecurity 

>[!ABSTRACT]-
>There is a need for new tools and techniques to aid automotive engineers performing cybersecurity testing on connected car systems. This is in order to support the principle of secure-by-design. Our research has produced a method to construct useful automotive security tooling and tests. It has been used to implement Controller Area Network (CAN) fuzz testing (a dynamic security test) via a prototype CAN fuzzer. The black-box fuzz testing of a laboratory vehicle’s display ECU demonstrates the value of a fuzzer in the automotive field, revealing bugs in the ECU software, and weaknesses in the vehicle’s systems design.


---

# Summary

- The paper discusses a structured method for constructing **automotive cybersecurity tests**, with a focus on **fuzz testing** the CAN bus. The authors present a systematic approach to test development and demonstrate its application using a prototype CAN fuzzer tool.
- The CAN fuzzer was tested on a laboratory vehicle’s **display ECU**, revealing vulnerabilities and weaknesses in the ECU software and the vehicle’s system design. The study shows how fuzz testing can effectively identify security flaws by injecting malformed or random data into the CAN bus.
- The methodology outlined includes establishing a test environment, selecting the technology to test (in this case, CAN), and developing and validating the test tools. The paper highlights the importance of **iterative testing** and continuous refinement of tools and methods.

# Relevancy

1. **Explores CAN Fuzz Testing Techniques**: The focus on fuzz testing aligns with your thesis’s goal of testing CAN vulnerabilities in simulation environments like CARLA.
2. **Provides a Structured Testing Framework**: The methodology outlined offers a detailed framework for developing and refining cybersecurity tests, which can be adapted for your experiments.
3. **Validates Tools in Real-World Scenarios**: The practical application of the CAN fuzzer on an ECU provides insights into how similar tests can be structured and validated in simulated environments.

# Notable Sections and Pages

- **Section III: The CAN Bus (Pages 2-3)**: Provides an overview of the CAN protocol and its vulnerabilities, offering foundational knowledge for your experiments.
- **Section IV: Methodology for Constructing Automotive Security Tests (Pages 3-5)**: Details the structured approach for developing and refining fuzz testing tools, directly applicable to your simulation setup.
- **Section V: Results from Fuzz Testing a Display ECU (Pages 5-6)**: Discusses the outcomes of fuzz testing an ECU, demonstrating the practical effectiveness of the method and tool used.

# Recommendations

This paper is a valuable addition to your thesis literature as it offers a comprehensive approach to testing CAN vulnerabilities and refining testing tools. I recommend citing it for its structured methodology and practical insights into fuzz testing CAN traffic in automotive systems.

----

# Annotations  
(11/7/2024, 5:26:07 PM)

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=1&annotation=3YFUFNQQ) “At Black Hat 2015, the premier convention for hackers, security researchers Miller and Valasek showed the first remote exploitation and control of an unmolested mass production car [1]. Their research provided a demonstration of cyberphysical hacking that could potentially cause harm to the vehicle’s occupants, other road users, and pedestrians. Their widely reported research once again showed that any type of device that has connectivity could become a target for a cyberattack and highlighted the potentially severe consequences of a compromised connected car. If car manufacturers were not already addressing the cybersecurity of their products, then their research showed the importance of doing so.” ([Fowler et al., 2019, p. 1](zotero://select/library/items/EBT9IP4F)) 

RealAttack

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=1&annotation=S79S2CBD) “The automotive industry is responding to the cybersecurity threat to their products. In the SAE J3061 guidelines [2] the use of Threat Analysis and Risk Assessment (TARA) and designing security into systems is advocated. The goal of secure-by-design [2]–[4] is to raise assurance levels [4], [5] in the software and hardware within vehicle systems. High assurance is important in order to maintain confidence [5] in a connected car’s operation and safety.” ([Fowler et al., 2019, p. 1](zotero://select/library/items/EBT9IP4F))


>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=1&annotation=8EETB67V) “The secure-by-design goal is verified with security testing [2], [4]. One of the goals of our research is to examine how a class of security testing, called fuzz testing, can have an impact on the automotive systems engineering field. Fuzz testing is a successful dynamic security testing technique used in traditional information systems [7]. However, there is a scarcity of detailed published works in the application of fuzz testing to vehicle systems [6].” ([Fowler et al., 2019, p. 1](zotero://select/library/items/EBT9IP4F)) 

Fuzzing

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=1&annotation=GYUFAFZS) “Within vehicle systems several types of data networks are used, here, the Controller Area Network (CAN) is chosen as the target for fuzz testing, for several reasons [6]: • it is a commonly used in-vehicle network; • many of the computers in a vehicle have a CAN interface; • the design of CAN makes it very susceptible to attack; • tools and techniques for manipulating the CAN protocol are inexpensive and readily available. In our research we examine how a new, easy to use, and easy to install prototype automotive fuzz testing tool, a CAN fuzzer, can be used to test the security properties of a vehicle’s computers.” ([Fowler et al., 2019, p. 1](zotero://select/library/items/EBT9IP4F)) 

CAN

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=2&annotation=MY4QYPRI) “In our previous work [6] we examined the use of fuzz testing within the automotive field. Fuzz testing is used by security researchers, software testers and attackers. The aim of fuzz testing is to discover software and hardware issues that may then be used to compromise a system’s security properties, its confidentiality, integrity, and availability.” ([Fowler et al., 2019, p. 2](zotero://select/library/items/EBT9IP4F)) 

CIA

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=2&annotation=RJG6QMSH) “Fuzz testing is a dynamic software stress test (equivalent to injecting noise into computer electronics when performing hardware fault injection tests): 1) High volumes of random or malformed data are sent into the system’s interfaces by a fuzzer. 2) The system’s reaction to the fuzz testing is monitored. 3) Conditions at a point of failure or interest are recorded for analysis. 4) Fuzz testing is highly automated for efficiency, and to cover a wide value space. 5) Analysis of fuzz testing results may reveal a system’s weaknesses. 6) An attacker will use weaknesses to try and compromise a system. A software tester will use the results to improve system design, and hence a system’s assurance levels.” ([Fowler et al., 2019, p. 2](zotero://select/library/items/EBT9IP4F))


![](C4XBEYCZ.png)  
>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=2&annotation=C4XBEYCZ)  
([Fowler et al., 2019, p. 2](zotero://select/library/items/EBT9IP4F)) 

CAN Packet

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=3&annotation=U8BSP7T3) “For a CAN packet the arbitration identifier (id), determines transmission priority. The lowest id continues transmission in the event of packet collision (two or more ECUs attempting simultaneous transmission). Examples of CAN packets logged from the lab vehicle are shown in Table II. CAN was designed prior to vehicle connectivity and without consideration for cybersecurity. It has vulnerabilities and is susceptible to several types of attack [15], including packet sniffing and replay, injecting false values, denial of service via flooding, jamming (known as bus-off) and spoofing data from ECUs.” ([Fowler et al., 2019, p. 3](zotero://select/library/items/EBT9IP4F)) 

Collision, ECU

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=4&annotation=VACK5Y3Y) “In our experience fuzz testing may damage components and so another display ECU was purchased for the experiment. The purchased ECU does not have the full color display but functions correctly within the vehicle, see Fig. 7. The ECU’s internal CAN connection was confirmed to run at 500Kbps, and the observed CAN packets have an eight-byte payload.” ([Fowler et al., 2019, p. 4](zotero://select/library/items/EBT9IP4F)) 

Damage

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=5&annotation=JQPFBZT9) “For the bench-based fuzz testing, custom cabling, correctly terminated2, was used to connect to the PC based CAN fuzzer. A bench supply, to power the ECU, replicated the 12.4 volts that was measured at the vehicle. The fuzzer was configured to randomise the standard CAN id range from 0 to 2047. At the fuzzer’s default transmission rate of one packet per millisecond, it would take less than three seconds to run through the standard range of id values (2048 · 0.001s = 2.048s). The CAN packet payload was configured to be fixed at eight bytes, as observed on the car’s CAN bus. The byte values were randomised over their full range of 0 to 255. It was observed that the display ECU, as with other ECUs that have been tested, enters a standby mode when no CAN communications are present on the CAN bus. This can cause the CAN fuzzer to report communications errors. This is because the initial CAN packet transmission from the fuzzer does not get acknowledged, due to the ECU waking from its standby mode. If the ECU does not wake up quickly enough then the fuzzer’s CAN interface can enter what is known as a bus-off state. To overcome this problem a second CAN interface is configured within the CAN fuzzer and attached to the CAN bus. This second interface allows for the initial CAN packets from the fuzzer to be acknowledged, while the ECU awakens from standby. This prevents the possible bus-off state.” ([Fowler et al., 2019, p. 5](zotero://select/library/items/EBT9IP4F)) 

Randomization,

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=5&annotation=UQLDYHCA) “Having found the packet that causes the ECU to react, the next test was to determine what functionality the individual bytes in the CAN packet perform. The identified packet has eight bytes of data. Testing the effect of the byte values can be done in different ways: 1) Treat the individual bits in a byte as flags. Testing involves setting and clearing different bits in each of the packet’s bytes. 2) Treat the data bytes as integer numbers and increment the values from 0 to 255. 3) Generate random values over a byte’s range from 0 to 255. For 2) and 3) there is a combinatorial explosion problem. For an eight byte data packet, with eight bits per byte, the 64 bits give 264 value combinations, or nearly 18.5 Exa (Exa = 1018) possible values. Thus, methods to simplify the search of the value space for the meaning of a CAN packet’s byte values are required. One method is to view the packet contents as individual bit flags. This vastly reduces possible combinations by testing each bit individually. This bit setting was chosen for its simplicity, testing the 64 packet bits using this method: 1) At the start, data bytes in the CAN packet are zeroed. 2) The CAN packet is transmitted to the display ECU. 3) The display ECU’s screen is observed for any reaction. 4) Each bit is set to one in order (starting at the first bit in the first byte). 5) If the last bit has been set then finish, otherwise go to step 2. To aid with the single bit testing the prototype CAN fuzzer’s single shot functionality was modified to make it easy to increment the byte values, see Fig. 9.” ([Fowler et al., 2019, p. 5](zotero://select/library/items/EBT9IP4F)) 

CANPacket

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=6&annotation=G86NDT3R) “The setting of individual bits within the CAN packet (id 793) did result in messages being displayed. The results for the first two bytes are shown in Table IV, space restrictions prevent all the results being included. The messages found were compared to the messages listed in the user manual for the car, available from the manufacturer’s customer website (the reference has been redacted due to commercial disclosure reasons). The user manual lists 78 possible messages that the display may show. Some of the” ([Fowler et al., 2019, p. 6](zotero://select/library/items/EBT9IP4F))


>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=6&annotation=63MVRUJ7) “possible messages relate to options and equipment that may not be present due to the vehicle model. For packet 793, out of the total 64 bit positions, there are 22 bits that result in a message being displayed. However, the message Park brake applied was seen twice. Furthermore, two messages are not present in the user manual (Engine on OK and Selector lever unlocked). Therefore, the bit testing for CAN id 793 revealed 20 of the 78 messages listed in the manual. The CAN fuzz testing, packet discovery, binary search and bit setting was repeated to find another CAN packet, id 752, that controls the display ECU. For the second round of testing the previously found id, 793 was excluded from the fuzz testing, by entering it into an exclusion list in the fuzzer (see Fig. 4). Fig. 10 shows one of the messages displayed by packet 752.” ([Fowler et al., 2019, p. 6](zotero://select/library/items/EBT9IP4F))


>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=7&annotation=3UILWIT7) “Reverse engineering of ECU functionality is needed to determine how systems work. System knowledge is useful to hackers, pen testers, functional safety engineers, rival manufacturers, and parts suppliers. The reverse engineering of the display ECU could be continued. Indeed, another run of the fuzz testing, with the found ids excluded, found a CAN packet with id 753 responsible for an additional 4 messages. However, the focus of our research is not to fully reverse engineer a component, as the primary aim is to determine the usefulness of fuzz testing to improve automotive systems assurance levels. To that end the results from testing against the ECU have provided useful evidence to support the use of automotive fuzz testing. Furthermore, the results were used to inject unexpected messages into the lab vehicle.” ([Fowler et al., 2019, p. 7](zotero://select/library/items/EBT9IP4F)) 

Reverse Engineering, pentesting

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=7&annotation=XWDPYDMT) “One aim of security experiments is to learn enough about a component in order to use the knowledge to compromise a vehicle. In doing so it provides evidence needed to improve the component design, system design and mitigate the attack. For the display ECU the knowledge to control what is shown to vehicle occupants is useful for attackers. In this case it allows for the display of incorrect messages to the vehicle users, including messages that may not be understood because they are not in the user manual. Displaying those messages would be disturbing in a variety of situations. It can be seen, Fig. 6, that the display ECU is not connected to the On-Board Diagnostics (OBD) port, a common entry when attacking vehicle CAN busses. Thus, the CAN packets needed to display a rogue message must be sent via a connection to the vehicle’s internal CAN bus. This is achieved using a man-in-the-middle connection close to another ECU under the dashboard, see Figure 11.” ([Fowler et al., 2019, p. 7](zotero://select/library/items/EBT9IP4F)) 

OBD, ECU, CAN

>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=8&annotation=X2252ZTF) “the argument that if physical access is required then some other attack would be performed. However, the principles behind the discovery of the display ECU functionality, and the message injection, are applicable to future security testing. Furthermore, there are multi-stage scenarios in which a similar, or the same, type of attack would be useful to certain adversaries, for example state actors or unscrupulous repair businesses planting controllable devices in a vehicle, in order to facilitate stopping a vehicle or a false repair. Although an attack is possible it may not necessarily be used, however, there are always lessons to learn, and knowledge that can be applied elsewhere. In Figure 12 the message injection can be seen in action. The injected messages cause a loud beeping sound within the vehicle, which is not heard during the bench-based experiments, and would heighten anxiety for vehicle users.” ([Fowler et al., 2019, p. 8](zotero://select/library/items/EBT9IP4F))


>[Go to annotation](zotero://open-pdf/library/items/V6KZJGZR?page=8&annotation=FABIQBC4) “The full range of processes required for automotive security testing are not trivial due to the attack surface of vehicles. Furthermore, complexity is increasing with the advent of autonomous driving. We have developed a method that is suitable for developing testbeds, tooling and security tests. Our method has been applied to automotive fuzz testing, starting with insecure CAN, which is present within all mass manufactured vehicles. We have developed an easy to use and easy to deploy prototype CAN fuzzer to supplement TARA and secure-by-design with a dynamic test method. The fuzzer was used against a display ECU and it revealed problems with the software, confidential operational information, and system integrity issues. If this security fuzz testing had been available, and was performed prior to production, then beneficial system design changes and bug fixes would have been made. It is also applicable to the post-production vehicle life cycle, where security testing can be applied to design iterations. Therefore, the development of security tests is a requirement in automotive engineering, and supplements traditional functional testing. A validated security test, as with the CAN fuzz testing, does improve system security assurance. One area that requires further research, and noticeably absent from the literature, is how to gather useful metrics on fuzz testing. The fuzzer will be used to explore this issue within the automotive field.” ([Fowler et al., 2019, p. 8](zotero://select/library/items/EBT9IP4F)) 

CAN Fuzzer, Design