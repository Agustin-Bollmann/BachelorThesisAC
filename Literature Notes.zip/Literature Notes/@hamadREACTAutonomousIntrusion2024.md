---
title: "REACT: Autonomous Intrusion Response System for Intelligent Vehicles"
authors: Mohammad Hamad, Andreas Finkenzeller, Michael Kühr, Andrew Roberts, Olaf Maennel, Vassilis Prevelakis, Sebastian Steinhorst
year: 2024
---

# REACT: Autonomous Intrusion Response System for Intelligent Vehicles
##### Mohammad Hamad, Andreas Finkenzeller, Michael Kühr, Andrew Roberts, Olaf Maennel, Vassilis Prevelakis, Sebastian Steinhorst (2024)
[Zotero-Link](zotero://select/items/@hamadREACTAutonomousIntrusion2024)

Tags: #Vulnerabilities #ECU #LiDAR #Sensors #Code #ISO #ISO21434 #VSOC #REACT #ENISA #CAN #FlexRay #Ethernet #ADAS #Camera #SteppingStone #PrivilegeEscalation #TARA #STRIDE #SAVTA #AttackSurfaces #IRS #Intrusions #IDS

>[!ABSTRACT]-
>Autonomous and connected vehicles are rapidly evolving, integrating numerous technologies and software. This progress, however, has made them appealing targets for cybersecurity attacks. As the risk of cyber threats escalates with this advancement, the focus is shifting from solely preventing these attacks to also mitigating their impact. Current solutions rely on vehicle security operation centers, where attack information is analyzed before deciding on a response strategy. However, this process can be timeconsuming and faces scalability challenges, along with other issues stemming from vehicle connectivity. This paper proposes a dynamic intrusion response system integrated within the vehicle. This system enables the vehicle to respond to a variety of incidents almost instantly, thereby reducing the need for interaction with the vehicle security operation center. The system offers a comprehensive list of potential responses, a methodology for response evaluation, and various response selection methods. The proposed solution was implemented on an embedded platform. Two distinct cyberattack use cases served as the basis for evaluating the system. The evaluation highlights the system’s adaptability, its ability to respond swiftly, its minimal memory footprint, and its capacity for dynamic system parameter adjustments. The proposed solution underscores the necessity and feasibility of incorporating dynamic response mechanisms in smart vehicles. This is a crucial factor in ensuring the safety and resilience of future smart mobility.


---

# Summary

- The paper introduces **REACT**, a dynamic intrusion response system designed for autonomous and connected vehicles. It addresses the limitations of current Vehicle Security Operation Centers (VSOCs) by providing a **vehicle-embedded solution** capable of responding to cyber incidents in near-real-time without waiting for external intervention.
- REACT is designed to handle **multiple types of cyberattacks**, including information falsification, system unavailability, and DoS attacks, using a **modular architecture**. The system includes **risk evaluation, response generation, and optimal response selection** modules to assess and address attacks dynamically.
- The paper evaluates REACT on an embedded platform and demonstrates its efficiency, with the system showing low memory consumption and swift response times in real-world scenarios, such as adversarial sample manipulation and infotainment system breaches.

# Relevancy

1. **Focuses on Real-Time Intrusion Response**: The dynamic response capabilities align with your objective of testing CAN traffic manipulation and evaluating response mechanisms in a simulation environment like CARLA.
2. **Covers Attack Scenarios and Defensive Strategies**: The attack scenarios and response methods discussed provide a foundation for understanding how similar systems could be tested and validated in your experiments.
3. **Emphasizes Embedded System Implementation**: The focus on implementing REACT in an embedded platform offers insights into the practical application of security mechanisms within autonomous vehicle architectures.

# Notable Sections and Pages

- **Section 2: Response Strategies (Pages 3-6)**: Explains various response strategies tailored for automotive systems, relevant for designing defensive measures in your CAN traffic manipulation tests.
- **Section 3: Dynamic Cost and Impact Evaluation (Pages 6-9)**: Discusses methods for evaluating the impact and response costs dynamically, which can support your thesis's experiments in assessing CAN traffic manipulation impacts.
- **Section 5: Proposed Automotive IRS (Pages 11-13)**: Describes the architecture of REACT and its components, providing a model for integrating a dynamic response system into autonomous vehicle simulations.
- **Section 6: Evaluation (Pages 14-17)**: Details the evaluation of REACT using real-world scenarios, offering examples that can guide the setup and validation of your testing framework.

# Recommendations

This paper is an essential addition to your thesis literature as it provides a detailed examination of an embedded intrusion response system tailored for autonomous vehicles. I recommend citing it for its structured approach to dynamic risk assessment and response mechanisms.

---

# Annotations  
(11/3/2024, 1:23:45 PM)

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=1&annotation=8IFF6KH2) “In recent years, there has been remarkable progress in the development of smart vehicles. Today’s vehicles resemble interconnected networks on wheels, with numerous embedded computers, called Electronic Control Units (ECUs), linked through various types of networks, hosting an extensive number of software components totaling over a hundred million lines of code. Moreover, these networks incorporate various intelligent sensors (such as cameras, LiDAR, radar, etc.) and different connectivity technologies that enhance the vehicle’s ability to perceive and interact with the surrounding environment, thus bolstering autonomy and minimizing the reliance on human intervention. However, with the rise of connectivity and the softwarization of vehicles, the vulnerability to cyberattacks targeting these systems has also escalated [66].” ([Hamad et al., 2024, p. 1](zotero://select/library/items/KEPFDUEX)) 

Vulnerabilities, ECU, LiDAR, Sensors, Code

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=1&annotation=FF8UIG2E) “Recently, there has been a growing interest in addressing the security threats that may target smart vehicles. For instance, the ISO 21434 [34] standard has been introduced, with a significant portion dedicated to the development of threat analysis and risk assessment methodologies.” ([Hamad et al., 2024, p. 1](zotero://select/library/items/KEPFDUEX)) 

ISO, ISO21434

![](XC6ZP3SZ.png)  
>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=2&annotation=XC6ZP3SZ)  
([Hamad et al., 2024, p. 2](zotero://select/library/items/KEPFDUEX)) 

VSOC

![](36269UXE.png)  
>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=2&annotation=36269UXE)  
([Hamad et al., 2024, p. 2](zotero://select/library/items/KEPFDUEX)) 

REACT

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=2&annotation=A4F4IQS6) “Finally, and more importantly, there is a need to ensure a near-real-time response to security attacks. Taking into account the need for a human in the loop, as well as the latency introduced by high-volume shared data and communication between the vehicles and the VSOC, achieving a near-real-time response seems unrealistic. This perspective is supported by the European Union Agency for Cybersecurity (ENISA), which has cautioned that responding to high-criticality attacks could potentially take days or even weeks [15]. The scenario of extended waiting presents a dilemma, with two options, each having its own disadvantages. Allowing a vehicle to operate with a compromised component due to extended waiting for a security update is far from the ideal situation. Alternatively, suspending the compromised component until the security update is received might not be the best course of action either, particularly if the component plays a crucial role in operations.” ([Hamad et al., 2024, p. 2](zotero://select/library/items/KEPFDUEX)) 

ENISA

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=3&annotation=ISPBTLJR) “It is notable that a modern vehicle includes highly interconnected subsystems. The figure also shows how modern vehicles have many embedded devices, known as ECUs, which are distributed allover the vehicle, communicating among themselves via different types of networks such as CAN, Flexray and Ethernet. These ECUs are grouped in different domains or zones based on the functionality such as infotainment, Advanced Driver Assistance Systems (ADAS), powertrains, etc.” ([Hamad et al., 2024, p. 3](zotero://select/library/items/KEPFDUEX)) 

CAN, FLexray, Ethernet. ADAS

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=3&annotation=MZCM3SDG) “Besides ECUs, modern vehicles are equipped with many sensors (e.g., cameras, LiDAR, etc.), advanced communication technology for connecting with the external world, and diagnostic ports (e.g., OBD-II) that collectively form a significant attack surface for different types of attacks and threats [11]. The unrestricted or/and uncontrolled interaction among all those components puts the whole system in danger. Attackers could launch a stepping-stone attack [65], where they compromise a non-critical ECU with weaker security (e.g., the infotainment system), in order to gain control of a more crucial one (e.g., engine control).” ([Hamad et al., 2024, p. 3](zotero://select/library/items/KEPFDUEX)) 

LiDAR, Camera, SteppingStone, Privilege Escalataion

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=3&annotation=PX7KMDAX) “Threat Analysis and Risk Assessment (TARA), an essential component of ISO 21434, is employed as a systematic way to identify and assess cybersecurity threats and risks in the automotive industry, facilitating the implementation of effective mitigation strategies. Since TARA does not dictate a specific method to identify threats, various methods have been proposed, such as STRIDE [37], SAVTA [21], attack trees [26, 20], and many others [45].” ([Hamad et al., 2024, p. 3](zotero://select/library/items/KEPFDUEX)) 

TARA, STRIDE, SAVTA

![](KCCXZKEF.png)  
>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=3&annotation=KCCXZKEF)  
([Hamad et al., 2024, p. 3](zotero://select/library/items/KEPFDUEX)) 

AttackSurfaces

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=3&annotation=PS5PTSN9) “Using the list of threats and attacks to create a response for each of them seems to be not ideal due to several challenges, including the large number of attacks and the requirements for precise information about each attack, which must be provided by the Intrusion Detection System (IDS). This challenge becomes evident when considering Zero-Day attacks, where information about such attacks may not be available to the IRS at the time of detection by the IDS. Even if an anomaly-based IDS shares some information about the attack pattern with the IRS, a response solely based on known attack patterns may not sufficiently react to these Zero-Day attacks. Therefore, the most effective approach is to enable the IRS to understand the situation it aims to respond to. This involves focusing on the impact or outcome of different attacks rather than solely on the attacks themselves.” ([Hamad et al., 2024, p. 3](zotero://select/library/items/KEPFDUEX)) 

IRS

![](SXEU8MAK.png)  
>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=4&annotation=SXEU8MAK)  
([Hamad et al., 2024, p. 4](zotero://select/library/items/KEPFDUEX)) 

Intrusions

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=17&annotation=HAS92F29) “Modern vehicles’ intricate architecture and advanced connectivity present unique intrusion challenges. While automotive security research has traditionally emphasized IDSs as a secondary defense layer, the development of vehicle IRS is in its early stages, drawing inspiration from related industries. To delve into the development of an automotive IRS, we sought answers to three key questions: defining potential responses, outlining response evaluation criteria, and optimizing response selection. Initially, we categorized automotive intrusions and stepping-stone attacks into five distinct categories to create a more versatile intrusion model.” ([Hamad et al., 2024, p. 17](zotero://select/library/items/KEPFDUEX)) 

IRS, IDS

>[Go to annotation](zotero://open-pdf/library/items/67JKRAE2?page=17&annotation=QB47D5HJ) “With respect to the secure communication of intrusions and responses, further research and standardization needs to be performed in order to ensure that the developed IRS does not only reply in an adequate manner, but also distributes its responses. The modular architecture of REACT allows an easy extension towards more complex vehicle architectures and new intrusions or responses. Additionally it allows the integration of new selection algorithms in the future to adapt to possible changed needs.” ([Hamad et al., 2024, p. 17](zotero://select/library/items/KEPFDUEX)) 

REACT