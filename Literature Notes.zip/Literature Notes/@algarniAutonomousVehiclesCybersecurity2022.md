---
title: "Autonomous Vehicles: The Cybersecurity Vulnerabilities and Countermeasures for Big Data Communication"
authors: Abdullah Algarni, Vijey Thayananthan
year: 2022
---

# Autonomous Vehicles: The Cybersecurity Vulnerabilities and Countermeasures for Big Data Communication
##### Abdullah Algarni, Vijey Thayananthan (2022)
[Zotero-Link](zotero://select/items/@algarniAutonomousVehiclesCybersecurity2022)

Tags: #Optimism #Vulnerabilities #Theft #Robbery #Countermeassures #VANET #CABV #IoAV #Spoofing #Awareness #AI #Blockchain #Perception #Decision #Planning #Modules #Chassis #Architecture #AttackSurfaces #BigData #Einstein #Sustainability #AttackTypes #MITM #V2X #OBD #GPS #KeyFob #DCAV #Energy #Detection #Ressources #AVN #Future #Challenges #Encryption 

>[!ABSTRACT]-
>The possible applications of communication based on big data have steadily increased in several industries, such as the autonomous vehicle industry, with a corresponding increase in security challenges, including cybersecurity vulnerabilities (CVs). The cybersecurity-related symmetry of big data communication systems used in autonomous vehicles may raise more vulnerabilities in the data communication process between these vehicles and IoT devices. The data involved in the CVs may be encrypted using an asymmetric and symmetric algorithm. Autonomous vehicles with proactive cybersecurity solutions, power-based cyberattacks, and dynamic countermeasures are the modern issues/developments with emerging technology and evolving attacks. Research on big data has been primarily focused on mitigating CVs and minimizing big data breaches using appropriate countermeasures known as security solutions. In the future, CVs in data communication between autonomous vehicles (DCAV), the weaknesses of autonomous vehicular networks (AVN), and cyber threats to network functions form the primary security issues in big data communication, AVN, and DCAV. Therefore, efficient countermeasure models and security algorithms are required to minimize CVs and data breaches. As a technique, policies and rules of CVs with proxy and demilitarized zone (DMZ) servers were combined to enhance the efficiency of the countermeasure. In this study, we propose an information security approach that depends on the increasing energy levels of attacks and CVs by identifying the energy levels of each attack. To show the results of the performance of our proposed countermeasure, CV and energy consumption are compared with different attacks. Thus, the countermeasures can secure big data communication and DCAV using security algorithms related to cybersecurity and effectively prevent CVs and big data breaches during data communication.


---

# Summary

- The paper explores the **cybersecurity vulnerabilities (CVs)** in autonomous vehicles (AVs), focusing on **big data communication** between vehicles and IoT devices, and the vehicular networks (AVN). It discusses various types of cyber threats, including those affecting **network traffic, data integrity**, and **power-based attacks** that compromise AV components.
- The authors propose a model for securing AV networks, leveraging **energy-efficient algorithms** and **security protocols**. This model aims to proactively detect and mitigate vulnerabilities by monitoring energy variations during cyber-attacks.
- The study also introduces a framework integrating various layers of security mechanisms, such as **digital signatures** and **encryption techniques**, to secure communication channels in AVs.

# Relevancy

- **Covers Big Data Communication Vulnerabilities**: The focus on vulnerabilities in big data communication and network traffic aligns well with your goal of understanding and manipulating CAN traffic in simulations like CARLA.
- **Presents Countermeasures**: The paper provides insights into countermeasures such as **energy-efficient detection systems** and **encryption techniques**, which can be relevant for your experiments involving CAN traffic manipulation and security testing.
- **Integrates Multi-Layer Security Approaches**: The proposed framework's integration of multiple security protocols offers a structured approach that could inform your testing methodology in simulated environments.

# Notable Sections and Pages

- **Section 2.1: Vulnerabilities in the AVN and DCAV (Pages 4-5)**: Details the various vulnerabilities in autonomous vehicle networks, including attacks on CAN systems and data communication. This section is crucial for the theoretical background of your thesis.
- **Section 3: Proposed Model (Pages 8-10)**: Describes the energy-efficient security algorithms and countermeasure frameworks designed for AVNs, providing insights into implementing similar methods in CARLA simulations.
- **Section 5: Discussions and Analysis (Pages 12-14)**: Discusses the results of the proposed model and its application to real-world scenarios, relevant for understanding how theoretical models can be translated into simulation-based testing.

# Recommendations

This paper is a valuable addition to your thesis literature as it offers a comprehensive look at the cybersecurity vulnerabilities in AVs and provides structured countermeasures that could be tested and validated using simulation tools like CARLA. I recommend citing it for its detailed approach to securing AV networks and its integration of big data analysis techniques.

---

# Annotations  
(11/1/2024, 12:32:00 PM)

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=2&annotation=IHL8EUWV) “Society will be extremely safe if its use of autonomous vehicles is protected against cybersecurity vulnerabilities. Threats to the cybersecurity of a fleet of autonomous vehicles are conceivable; stealing a fleet of autonomous vehicles could represent a new type of car theft [1]. Such vehicles could be compromised by a lack of security measures [2], e.g., an autonomous vehicle operating system might be compromised, exposing private data on other linked devices. The hacked automobiles can then be diverted to a location where a robbery or assault is intended to take place. In addition, IoT gadgets in homes could be controlled by connected cars, providing hackers access to people’s personal computer networks.” ([Algarni and Thayananthan, 2022, p. 2](zotero://select/library/items/8BHML346)) 

Optimism, vulnerabitliites, theft, robbery

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=2&annotation=Q8X4HZTQ) “In the future, autonomous systems should be able to proactively detect CVs. The strong countermeasures proposed in this study aim to develop attack-free autonomous systems and minimize global warming and carbon footprints. However, the appropriate countermeasures will maximize energy consumption because strong security systems use highly complex designs and algorithms. Therefore, researchers are attempting to improve the security of AVs using simple countermeasures.” ([Algarni and Thayananthan, 2022, p. 2](zotero://select/library/items/8BHML346)) 

Countermassures

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=3&annotation=MAKRWRUI) “To secure the message transfer between wirelessly connected vehicles, a fast and selective authentication of VANETs using digital signatures was analyzed [4]. In addition, the study demonstrated that context-adaptive beacon verification (CABV) with a particle filter could detect and prevent spoofed attacks while reducing computational overhead. The authors of [5] proposed the Internet of Autonomous Vehicles (IoAV) architecture. They illustrated its layered architecture that included key features such as safe navigation and efficient traffic management in addition to bringing people to their destinations. The performance of IoAV was evaluated based on the transmission time and energy consumption.” ([Algarni and Thayananthan, 2022, p. 3](zotero://select/library/items/8BHML346)) 

VANET, CABV, IoAV, Spoofing

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=4&annotation=ZICVJCX9) “Key automotive cyber-attacks, their impact, and corresponding solutions that utilize artificial intelligence (AI)-based deep learning models have also been discussed in depth. One study proposed a roadmap to establish efficient intrusion detection systems for secure AVs and address major challenges [8]. In addition, the vulnerability of AV systems to cyberattacks was examined [9]. The authors investigated attack mechanisms on AVs to raise awareness about cybersecurity threats. In another study, the security vulnerabilities of AVs, cyberattack detection, and mitigation strategies were described [10]. Some emerging technologies, such as AI and blockchain, have been used as security solutions against threats to the transportation infrastructure. An in-depth survey and analysis of the historical evolution, recent research directions, and cybersecurity (threats, vulnerabilities, and attack modeling) of autonomous systems were conducted [11].” ([Algarni and Thayananthan, 2022, p. 4](zotero://select/library/items/8BHML346)) 

Awareness, AI, blockchain

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=6&annotation=SQ8CBJGX) “The protocol of the system architecture, illustrated in Figure 1, comprises four main stages: perception, decision and planning, control, and chassis [36]. In this architecture, data fusion enables the sensor and recognition modules to dynamically make accurate decisions and plans once the security features and solutions are enhanced in the full AVs. Accordingly, the design of these modules, interfaces, and functionalities should enable the integration of security algorithms and main sensors to protect the system from cyber-attacks and CVs.” ([Algarni and Thayananthan, 2022, p. 6](zotero://select/library/items/8BHML346)) 

Perception, desicion and planning, control and chassis

![](Q5C2NB7U.png)  
>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=6&annotation=Q5C2NB7U)  
([Algarni and Thayananthan, 2022, p. 6](zotero://select/library/items/8BHML346)) 

Architecture

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=6&annotation=TXBZCWCL) “CVs generally affect the data traffic of vehicular communication networks, and countermeasures for big data communication depend on the data sources used in transportation services. Autonomous services face several types of attacks, such as jamming. However, big data analytics for anti-jamming applications in AVN enable researchers to secure autonomous services in vehicular ad-hoc networks [37]. Improving big data clustering for jamming detection in smart mobility [38] and automobile systems can also be considered while developing countermeasures. Most jamming attacks damage the physical components of autonomous systems, such as AVs.” ([Algarni and Thayananthan, 2022, p. 6](zotero://select/library/items/8BHML346))


![](P8ZUTNBX.png)  
>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=7&annotation=P8ZUTNBX)  
([Algarni and Thayananthan, 2022, p. 7](zotero://select/library/items/8BHML346)) 

Attack surfaces

![](ZFH28NBL.png)  
>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=7&annotation=ZFH28NBL)  
([Algarni and Thayananthan, 2022, p. 7](zotero://select/library/items/8BHML346)) 

Big data

![](PMLIMJTS.png)  
>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=9&annotation=PMLIMJTS)  
([Algarni and Thayananthan, 2022, p. 9](zotero://select/library/items/8BHML346)) 

model for secure big data

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=9&annotation=KVCV4FVI) “Layer (L1) collects all data, including big data considered in DCAV, RSU, and smart devices, to identify cyberattacks. The countermeasure with the safety zone set in layer (L2) receives all data from L1, including the cyberattack database. Layer (L3) provides the necessary policies and rules for CVs along with countermeasure detection steps. Here, RSUs manage the DCAV and collect all big data communications to detect CVs. Layer (L4) sends the collected data from all allocated web servers for analysis and detection. Consequently, CVs are prevented, and the security framework in DCAV and AVN can be updated.” ([Algarni and Thayananthan, 2022, p. 9](zotero://select/library/items/8BHML346)) 

Secure Big data model

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=9&annotation=LNIR4AYI) “According to [40], Einstein challenged and developed a theory of Brownian motion based on Brownian particle theory, which allowed him to find a physical and mathematical solution for many potential problems. His challenges extend from fundamental physics to the very dynamics of securing financial markets and autonomous vehicles in modernity. Thus, Einstein’s concept allows us to formulate Equation (1) for measuring displacement D of the particles in molecular communication. D= √ kBTπηRt 6 (1) where kB is Boltzmann’s constant, T is the temperature of molecular communication, and h is the viscosity of the liquid used in molecular communication applications. In our study, CV is proportional to η, which affects data communication obtained from smooth and secure data traffic and management. In big data communication, R is the size of the original and clean data, and t is the time. In this theoretical model, energy levels are proportional to CV; therefore, minimizing energy consumption is also important when an attack-detecting device is designed for analyzing countermeasures. In (1), the displacement of the abnormal data bits may be smaller than that of the normal data because the concentration or density of the data must be higher than that of the normal or pure data. From (1), the kinetic energy of the molecules can be shown to depend on the temperature, which affects the energy levels when the components in the AV become heated. AV sensors collect the average energy of the CV at various points of data communication between the AVs and RSU. Albert Einstein’s famous formula, given by (2), can be used as a theory that formulates and enables us to analyze the energy levels when CV affects AVN and DCAV. Using countermeasures in our proposed theoretical model enhances the accuracy of measuring CV levels in data communication. E = mc2 (2) where E, m, and c are energy, mass, and the speed of light, respectively. In each communication channel, the volume of big data traffic (v) of clean data can be measured using (3). m = dv (3) where d is the density of the clean data. If the data comprise CVs, the density of data in the communicating channel will be high. Therefore, the mass will increase, and the energy of the clean and attacked data is calculated using (4). E = dvc2 (4) This proposed model can effectively counteract the changing energy levels by using dedicated sensors allocated for monitoring CV that measure the energy levels before and after cyberattacks. If the energy level exceeds the threshold limit, the CV level is considered high. Otherwise, the CV level is considered normal. Here, the rate of data communication can also be considered using time-dependent data and information. In (1), displacement D depends on the density of the data, which allows us to calculate the energy using (4). In this model, (1) provides the CV of the data communication when the channel is exposed to man-made attacks or exhibits abnormal behavior. The proposed model can resolve all such dynamic and static attacks, provided it employs efficient tools and stronger countermeasure algorithms. Using (2), energy can be compared with the threshold limit, which allows users to analyze the CV values. The energy is proportional to the mass of the data. Ea ET = ma mT (5) In this experiment, the threshold value is set for the pure data (mT), which is the size of the data assumed as a mass of the data. Also, the threshold energy of the pure data is set” ([Algarni and Thayananthan, 2022, p. 9](zotero://select/library/items/8BHML346)) 

Einstein

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=11&annotation=6TRSIUQM) “as ET. When attacked data size (ma) is known, the energy of the attacked data is measured from (5). Ea ET = da dT (6) Assume that volume of attacked and pure data is the same. Here, energy is proportional to the density of the data. When the density of the attacked data (da) and pure data (dT) are known, and the energy of the attacked data is measured from (6).” ([Algarni and Thayananthan, 2022, p. 11](zotero://select/library/items/8BHML346)) 

einstein2

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=11&annotation=2BLKS3UL) “According to the research, theoretical findings, and analysis, the big data communication of autonomous vehicles will be secured with the minimum energy consumption. Therefore, when society uses autonomous vehicles, there will be a secure environment with low energy costs.” ([Algarni and Thayananthan, 2022, p. 11](zotero://select/library/items/8BHML346)) 

sustainable

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=11&annotation=KKP6IRTD) “Strong threats: These threats damage the DCAV and AVN configurations, where specific onboard diagnostics (OBD) hacks prevent interior features from functioning. In AVs, V2V hacks, V2I hacks, OBD, GPS spoofing, and MITM increase the strength of threats and CVs. 2. Mild threats: These threats weaken and slow down the interior and exterior systems of AVs. In autonomous services, key fob hacking, attacks on the control area network (CAN) bus, and entertainment system hacking limit the efficiency of the services. 3. Light threats: Selected components such as airbags and brakes are hacked when AVs are on the move because DCAV and AVN depend on all features and services used in the AVs.” ([Algarni and Thayananthan, 2022, p. 11](zotero://select/library/items/8BHML346)) 

attacktypes, MITM, V2V, OBD, GPS, Spoofing, Key fob, theft, dcav

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=13&annotation=S3EU6NDW) “When developing countermeasures, measuring and analyzing the energy levels of each component in AVs exposed to cyberattacks is important. Based on the measurement results, the following parameters were considered. Types of CVs induced by cyberattacks, energy levels of each cyberattack, and the detecting conditions and abilities of the countermeasures. More than 90% of automotive innovations contribute to making transport autonomous, such as regular transportation services that depend on software-driven electronic components. However, security risks and CVs created by faulty components increase the safety and security costs incurred by AVs. Purposed attacks are also increasing with the growing number of hackers working to obtain financial benefits or enter the competition. Nevertheless, the energy levels of each attack are different; therefore, the countermeasure integrated with the proposed approach detects the abnormal traffic associated with big data communication. The energy levels of normal and abnormal data can be compared dynamically, and setting the energy level threshold enables the system to detect abnormal behavior more efficiently and proactively.” ([Algarni and Thayananthan, 2022, p. 13](zotero://select/library/items/8BHML346)) 

Energy, Detection, Ressources

![](RYYEJHEQ.png)  

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=14&annotation=RYYEJHEQ)  
([Algarni and Thayananthan, 2022, p. 14](zotero://select/library/items/8BHML346)) 

attacks and countermeassures

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=16&annotation=SCKWRK5B) “Cyberattacks influence sudden changes in energy levels which could damage the communication devices used in autonomous systems and vehicles. In the future, hydrogen-based energy can be used for power transmission and communication, which might be attacked when the level of energy is exceeded suddenly during the operation of autonomous systems.” ([Algarni and Thayananthan, 2022, p. 16](zotero://select/library/items/8BHML346)) 

energy

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=16&annotation=CDSXX5UZ) “The basic and luxury features of AVs also affect the latest gadgets, such as the remote keyless entry (RKE) system. Although cryptographic algorithms are applied in RKE development, the rolling codes used in RKE systems are vulnerable to all cyberattacks, including eavesdropping and RKE cloning. Therefore, countermeasures must include strong encrypted rolling codes and clone-resistant methods. Also, quantum-safe algorithms may be employed based on Symmetric Key and Asymmetric Key Encryption methods [45].” ([Algarni and Thayananthan, 2022, p. 16](zotero://select/library/items/8BHML346)) 

key fob, theft

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=16&annotation=FFLLAZ3C) “Intelligent features and proactive cybersecurity solutions can be obtained only by securing big data communication through artificial intelligence (AI) integrated with AVN. Although it is difficult to implement, AI can effectively secure AVs and AVN, where intelligence approaches are considered in cybersecurity solutions, countermeasures, and threat intelligence. This is because AI enhances the capacity of the detection techniques used in the countermeasures and facilitates automated remediation, which supports proactive cybersecurity solutions.” ([Algarni and Thayananthan, 2022, p. 16](zotero://select/library/items/8BHML346)) 

AI, AVN

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=16&annotation=W6ECGKS3) “The proposed model primarily focuses on the security challenges of data communications. Other challenges, such as cryptography with AI, network security with low complexity, software vulnerability detection, and malware detection, need to be addressed in future work. Furthermore, the reliability of AVs requires further investigation.” ([Algarni and Thayananthan, 2022, p. 16](zotero://select/library/items/8BHML346)) 

future, challenges

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=17&annotation=DPH2TVG2) “Regarding the study of security analysis, asymmetric key encryption will be better for the security solution of countermeasure because asymmetric key encryption is far more secure than symmetric key encryption.” ([Algarni and Thayananthan, 2022, p. 17](zotero://select/library/items/8BHML346)) 

Encryption

>[Go to annotation](zotero://open-pdf/library/items/XZZFYVJZ?page=17&annotation=JDHZ2RH2) “Furthermore, this study proves that the level of cybersecurity solutions directly influences the energy levels that are accidentally created during abnormal operations and cyberattacks. The analytical approach of energy measurements is presented that energy consumption increases when cyberattacks occur in the AVN and big data communication.” ([Algarni and Thayananthan, 2022, p. 17](zotero://select/library/items/8BHML346)) 

Energy
