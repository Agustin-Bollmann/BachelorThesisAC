---
title: Advanced IDPS Architecture for Connected and Autonomous Vehicles
authors: Sherin Kalli Valappil, Lars Vogel, Mohammad Hamad, Sebastian Steinhorst
year: 2024
---

# Advanced IDPS Architecture for Connected and Autonomous Vehicles
##### Sherin Kalli Valappil, Lars Vogel, Mohammad Hamad, Sebastian Steinhorst (2024)
[Zotero-Link](zotero://select/items/@valappilAdvancedIDPSArchitecture2024)

Tags: #IDPS #Vulnerabilities #UNR155 #AUTOSAR #IDsM #ECU #TARA #APT #MITRE #CAN #Ethernet #Flexray #VSOC #EE #SecureBoot #Authentication #SecOC #HSM #STRIDE 

>[!ABSTRACT]-
>Highly connected and automated driving technologies have ushered digital transformation and flexibility to modern cars. However, the vehicle’s attack surface has significantly expanded due to increased connectivity. To address this problem, automotive manufacturers are adopting more secure practices driven by standards and regulations. In addition to the deployed cryptographically strong security measures in automotive, we need an Intrusion Detection and Prevention System (IDPS) that actively monitors the vehicle for intrusions, prevents them, and provides notification, as required by UN Regulation No. 155. In this work, we aim to identify the current limitations of the existing automotive approaches and contribute to an advanced IDPS solution. We propose architectural changes that improve reliability and form a framework to propose reactions in a safety-related automotive context. We evaluate our proposed architecture with regard to performance and security design. With the proposed changes to the IDPS architecture, our aim is to integrate a dynamic and adaptive strategy for IDPS, enhancing resilience against emerging threats and vulnerabilities.


---

# Summary

- The paper proposes an **advanced Intrusion Detection and Prevention System (IDPS)** architecture specifically for connected and autonomous vehicles (CAVs). The authors highlight the expanded attack surface in modern vehicles due to increased connectivity and the need for more dynamic and adaptive IDPS solutions.
- The proposed architecture integrates various components, such as a **Trusted Execution Environment (TEE)**, **Hardware Security Module (HSM)**, and **Virtual Machines (VMs)** within a System-on-Chip (SoC) framework. These elements work together to secure ECUs and maintain the integrity of communication, even in the event of an ECU compromise.
- The study evaluates the architecture’s effectiveness using a **STRIDE-per-interaction** approach and a **virtualized Linux environment**, testing different detection and mitigation strategies. The results show that while these methods can enhance security, they also introduce performance overhead.

# Relevancy

- **Focuses on Automotive Security Architecture**: The discussion of IDPS architecture tailored for CAVs aligns directly with your goal of testing CAN traffic manipulation and exploring vulnerabilities in autonomous vehicle systems.
- **Integrates Advanced Security Components**: The use of TEE, HSM, and VMs for securing ECUs and communication offers a structured approach that can inform your simulation experiments using tools like CARLA.
- **Emphasizes Evaluation Techniques**: The STRIDE threat modeling and real-world testing methods presented in the paper provide insights into validating your own testing setup and strategies.

# Notable Sections and Pages

- **Section II: System and Attacker Model (Pages 3-5)**: Describes the system architecture and potential attack vectors, offering a foundation for understanding how the IDPS architecture addresses CAN traffic manipulation threats.
- **Section IV: Proposed Architecture (Pages 6-8)**: Details the advanced IDPS framework, including the integration of TEE and HSM, relevant for designing secure testing setups in CARLA.
- **Section V: Evaluation (Pages 9-12)**: Discusses the performance evaluation of the proposed IDPS system, providing insights into the effectiveness of various components and their impact on system performance.

# Recommendations

This paper is an essential addition to your thesis literature. It provides a comprehensive examination of advanced IDPS architectures and their application in connected and autonomous vehicles, offering both theoretical insights and practical examples relevant to your work on CAN traffic testing. I recommend citing it for its detailed explanation of security mechanisms and evaluation methodologies.

---

# Annotations  
(11/3/2024, 6:45:28 PM)

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=1&annotation=W63UVNLJ) “To address this problem, automotive manufacturers are adopting more secure practices driven by standards and regulations. In addition to the deployed cryptographically strong security measures in automotive, we need an Intrusion Detection and Prevention System (IDPS) that actively monitors the vehicle for intrusions, prevents them, and provides notification, as required by UN Regulation No. 155.” ([Valappil et al., 2024, p. 1](zotero://select/library/items/5H5NUHWQ)) 

IDPS

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=1&annotation=KD3ISWNM) “Advanced technologies in today’s highly connected and autonomous vehicles have increased their susceptibility to numerous cyberattacks. Detecting intrusions and responding to these cyber threats has become both critical and challenging [1]. In response to this concern, the recent UN Regulation 155 [2] mandates manufacturers to establish strong cybersecurity management systems, conduct risk assessments, and enforce stringent security measures.” ([Valappil et al., 2024, p. 1](zotero://select/library/items/5H5NUHWQ)) 

Vulnerabilities, UNR155

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=1&annotation=4UU992KW) “The AUTOSAR Intrusion Detection System Manager (IdsM) [3], a standard introduced by AUTOSAR, provides a systematic approach to standardizing the IDPS for automotive applications on classic platforms. While the AUTOSAR IdsM effectively manages the buffering and filtering of security events reported by software applications, it does not have the capability to definitively confirm the presence of an intruder. Moreover, the existing AUTOSAR architecture does not provide isolation between the IdsM and other applications hosted on the same Electronic Control Unit (ECU). As a result, the integrity of the co-hosted IDPS could be at risk if any of these applications are compromised. In safety-critical environments like connected and autonomous vehicles, the brief time available to respond to an attack and secure the system highlights the need for reliably identifying an intruder’s presence within the ECU. This requires comprehensive offline analysis and the ability to respond to intrusions within the” ([Valappil et al., 2024, p. 1](zotero://select/library/items/5H5NUHWQ)) 

AUTOSAR, IDsM, ECU

![](QJ4GJ2L6.png)  
>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=1&annotation=QJ4GJ2L6)  
([Valappil et al., 2024, p. 1](zotero://select/library/items/5H5NUHWQ))

IDPS

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=1&annotation=UKAA8Z43) “limited time frame. Neglecting these challenges may have severe consequences, jeopardizing vehicle safety.” ([Valappil et al., 2024, p. 1](zotero://select/library/items/5H5NUHWQ))

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=1&annotation=UJXF3EM9) “To tackle these challenges, our paper explores strategies to elevate the standard of automotive IDPS solutions. Firstly, we propose an architecture, depicted in Fig. 1, designed to uphold IDPS reliability, even in the event of an ECU compromise. Secondly, we present an approach to enhance attack detection and confirmation by analyzing patterns derived from reported security events. To this end, we suggest tailoring MITRE frameworks for a comprehensive threat model that surpasses the constraints of the traditional Threat Assessment and Risk Analysis (TARA) approach. While TARA addresses external threats, our proposed approach broadens the scope to include internal threats. Additionally, our solution’s dynamic nature addresses Advanced Persistent Threat (APT), contrasting the static analysis provided by conventional automotive threat models. This dynamic methodology enhances the capability to analyze evolving threats in the automotive domain, thereby fortifying cyber resilience.” ([Valappil et al., 2024, p. 1](zotero://select/library/items/5H5NUHWQ)) 

IDPS, TARA, APT, MITRE

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=2&annotation=ZBT9YBCS) “System Model: The automotive Electric and Electronic (E/E) architecture consists of numerous ECUs interconnected through diverse networks like CAN, Ethernet, and FlexRay. These ECUs vary in safety integrity levels. With some of the ECUs adhere to AUTOSAR standards for safety-critical functions, while others, particularly microprocessor-based ECUs utilize POSIX-based Operating Systems (OSs). This work focuses on microprocessor-based ECUs known for their complex implementation and vulnerabilities as potential attack points due to their connectivity to the external environment. Despite the diversity in OSs, our work proposes a standardized communication protocol aligned with the frame format of the IdsM protocol as defined by AUTOSAR [4]. In our system model, a designated ECU establishes the communication with the Vehicle Security Operations Center (VSOC), facilitating data exchange within the automotive E/E architecture [5].” ([Valappil et al., 2024, p. 2](zotero://select/library/items/5H5NUHWQ)) 

CAN, Ethernet, Flexray, AUTOSAR, VSOC, EE

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=2&annotation=YWNUCT3K) “Attacker Model: This section provides an overview of our considered attacker model. We assume that each ECU has state-of-the-art security mechanisms in place, including Secure Boot, Message authentication for communication via Secure Onboard Communication (SecOC) [6], software signature verification before flashing, secure access to memory and diagnosis, sensitive and key material protection, and usage of Hardware Security Module (HSM) for tamper-resistant storage and cryptographic computations [7].” ([Valappil et al., 2024, p. 2](zotero://select/library/items/5H5NUHWQ)) 

Secure Boot, Authentication, SecOC. HSM

[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=2&annotation=NWIRW5A3) “Attackers can also exploit ECUs for lateral movements and pivoting attacks, navigating within an ECU and extending to other ECUs. This was demonstrated by the Tesla Free-Fall attack [9], which compromised one or more ECUs, leading to a loss of control and safety.” ([Valappil et al., 2024, p. 2](zotero://select/library/items/5H5NUHWQ))

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=2&annotation=DZ67TNHK) “The MITRE ATT&CK framework offers a comprehensive examination of the attack lifecycle based on the attacker’s tactics to identify IoCs. Compared to CKC, the MITRE framework provides a more detailed breakdown of attack stages, offering finer granularity that is beneficial for IDPS threat modeling and covering a broader threat landscape. MITRE ATT&CK is a behavior-based approach, categorizing tactics as the ’why’ (reason an attacker performs a specific action in threat modeling) and techniques as the ’how’ (method by which an action was performed). By combining these techniques and tactics with the target, we can deduce “what”-was performed on the target [12].” ([Valappil et al., 2024, p. 2](zotero://select/library/items/5H5NUHWQ)) 

MITRE

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=2&annotation=PZHF58DT) “We analyze automotive MITRE ATT&CK techniques along with their corresponding entries in D3FEND to support the design of the IDPS. This involves examining various security attacks that have targeted automotive systems [8], [9], [15], [16], including a notable example - the Tesla Free-Fall WiFi attack [9]. This real-world incident emphasizes the need for indepth detection and mitigation strategies in our proposed IDPS” ([Valappil et al., 2024, p. 2](zotero://select/library/items/5H5NUHWQ))

![](M2MQV7ET.png)  
>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=3&annotation=M2MQV7ET)  
([Valappil et al., 2024, p. 3](zotero://select/library/items/5H5NUHWQ)) 

MITRE

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=3&annotation=FWU3W9AR) “design. The attack unfolded in progressive stages, starting with vulnerability analysis and culminating in the complete compromise of vehicle control or safety” ([Valappil et al., 2024, p. 3](zotero://select/library/items/5H5NUHWQ))

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=6&annotation=KFEV5TAC) “In this work, we analyzed the critical aspects of automotive IDPS and the improvements in the current AUTOSAR standard for intrusion detection. We proposed using an in-depth threat analysis approach, such as MITRE, in conjunction with TARA to address both insider and outsider threats, thereby enhancing the resilience of ECUs. We proposed an architecture for IDPS that enables communication of the health status of the ECUs with other ECUs and to VSOC, even if the host of the ECU is compromised. This allows the VSOC to propose a reaction strategy, and the other ECUs to respond accordingly with the intrusion status received from the compromised ECU. We evaluated some proposed mitigation strategies in a virtualized environment and observed that employing sensors introduces additional overhead. We additionally evaluated the proposed architecture using STRIDE-per-interaction to identify crucial design decisions to enhance resilience of our architecture.” ([Valappil et al., 2024, p. 6](zotero://select/library/items/5H5NUHWQ)) 

STRIDE

>[Go to annotation](zotero://open-pdf/library/items/8UYKYQUC?page=7&annotation=EWBCKXFX) “Furthermore, the forensic unit represents a crucial next step in our work. Depending on the state of the vehicle and the stage of the attack, the severity of the intrusion may vary. By integrating it with the safety context of the vehicle, a reaction can be proposed within the vehicle, addressing the available time window. This facilitates an internal reaction strategy, eliminating the necessity for reactions from the VSOC. A manin-the-middle attack can disrupt communication between the VSOC and ECU, thereby halting the reaction process. Such vulnerabilities can be mitigated by establishing an internal reaction system.” ([Valappil et al., 2024, p. 7](zotero://select/library/items/5H5NUHWQ))