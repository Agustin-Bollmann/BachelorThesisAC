---
title: Quantitative Cybersecurity Risk Management for Autonomous Vehicle Systems
authors: David Bailey
year: 2018
---

# Quantitative Cybersecurity Risk Management for Autonomous Vehicle Systems
##### David Bailey (2018)
[Zotero-Link](zotero://select/items/@baileyQuantitativeCybersecurityRisk2018)

Tags: #SAELevels #Attackers #Asimov #SystemStructure #RiskManagement #RealAttacks

>[!ABSTRACT]-
>


---

# Summary

- The thesis presents a **quantitative risk management framework** tailored for autonomous vehicle systems, adapting the National Institute of Standards and Technology (NIST) guidelines to measure cybersecurity risks.
- It highlights the use of **Monte Carlo simulations** and other quantitative methods to evaluate the impact and likelihood of various threats, providing a more precise assessment than traditional qualitative methods.
- The paper discusses the **optimization of security controls** and the calculation of **annual expected losses** in autonomous vehicle systems to determine cost-effective measures for reducing risks.

# Relevancy

- **Provides a Quantitative Approach**: The quantitative methodology is suitable for evaluating risks and vulnerabilities in autonomous vehicles, aligning well with your interest in assessing CAN traffic manipulation risks.
- **Focuses on Vehicle Systems and Controls**: It discusses threats to vehicle control systems and suggests mitigation measures, which could directly apply to your work with CARLA and Autoware.
- **Details Simulation Use**: The use of simulations (e.g., Monte Carlo) parallels your experimental approach, offering valuable methods and frameworks that you can integrate into your simulations for testing CAN vulnerabilities.


# Notable Sections and Pages

- **Section 2.1: Prepare for Assessment (Pages 29-30)**: This section outlines the risk assessment framework setup, including identifying threat sources and vulnerabilities. It’s useful for structuring your CAN traffic manipulation experiments.
- **Section 3.1: Risk Assessment Results (Pages 37-40)**: Demonstrates the application of the risk model, which could be adapted for your thesis when testing different CAN manipulation scenarios and assessing their risks.
- **Section 2.2.5: Determine Risk (Pages 34-35)**: Provides details on calculating risks using stochastic and deterministic methods, applicable for assessing the effectiveness of controls you implement in your simulated environment.

# Recommendations

This thesis is a valuable source for your literature review and methodology development. It offers robust models and calculations that can enhance your experimental design in simulating and evaluating CAN traffic manipulation. I recommend citing it, particularly for its detailed quantitative framework and risk assessment approach.

---

# Annotations  
(10/28/2024, 5:35:13 PM)

![](9WFT37F7.png)  
>[Go to annotation](zotero://open-pdf/library/items/W4JUMJ6N?page=12&annotation=9WFT37F7)  
([Bailey, 2018, p. 12](zotero://select/library/items/FIN6WK3S)) 

AV Levels

![](JAFHSZLK.png)  
>[Go to annotation](zotero://open-pdf/library/items/W4JUMJ6N?page=13&annotation=JAFHSZLK)  
([Bailey, 2018, p. 13](zotero://select/library/items/FIN6WK3S)) 

Sense, Plan, Act

>[Go to annotation](zotero://open-pdf/library/items/W4JUMJ6N?page=18&annotation=LXRT4UUX) “However, no non-research vehicle security attacks have been publicly disclosed. The lack of attacks indicates the advanced skills required for these attacks. However, as the prevalence of autonomous vehicles grows, the motivation to conduct attacks will increase, and therefore the likelihood of attacks will increase.” ([Bailey, 2018, p. 18](zotero://select/library/items/FIN6WK3S)) 

Increase of Attacks

![](K5ADUHB8.png)  
>[Go to annotation](zotero://open-pdf/library/items/W4JUMJ6N?page=29&annotation=K5ADUHB8)  
([Bailey, 2018, p. 29](zotero://select/library/items/FIN6WK3S)) 

3 Laws of Robotics

![](CCW8YLYG.png)  
>[Go to annotation](zotero://open-pdf/library/items/W4JUMJ6N?page=38&annotation=CCW8YLYG)  
([Bailey, 2018, p. 38](zotero://select/library/items/FIN6WK3S)) 

AV System

>[Go to annotation](zotero://open-pdf/library/items/W4JUMJ6N?page=55&annotation=BE6UZP8G) “As Heidi King, Deputy Administrator of the National Highway Traffic Safety Administration said ”we should together build and support a cyber security risk management culture for the automotive industry that can serve as a role model to others. Our national automotive safety depends on it” (King, 2018).” ([Bailey, 2018, p. 55](zotero://select/library/items/FIN6WK3S)) 

Risk management culture for automotive industry
