---
title: Simutack - An Attack Simulation Framework for Connected and Autonomous Vehicles
authors: Andreas Finkenzeller, Anshu Mathur, Jan Lauinger, Mohammad Hamad, Sebastian Steinhorst
year: 2023
---

# Simutack - An Attack Simulation Framework for Connected and Autonomous Vehicles
##### Andreas Finkenzeller, Anshu Mathur, Jan Lauinger, Mohammad Hamad, Sebastian Steinhorst (2023)
[Zotero-Link](zotero://select/items/@finkenzellerSimutackAttackSimulation2023)

Tags: #V2X #CommonAttacks #Simutack #CAN #Vulnerabilities #CARLA #IMU #GNSS #RADAR #LiDAR #Sensor #Jamming #Spoofing #DoS #EclipseMOSAIC #SUMO #OMNeT

>[!ABSTRACT]-
>With the ongoing efforts toward autonomous driving, modern vehicles become increasingly digital and smart. Hence, the vehicle architecture including smart sensors, ECUs, and in-vehicle communication also faces new challenges to satisfy the ever-changing safety and security requirements. The complexity of the system naturally exposes many attack surfaces that demand for sound security solutions to protect the vehicle from potential intrusions. State-of-the-art approaches such as intrusion detection and intrusion response systems require lots of training and testing against various attack scenarios. However, implementing such attacks in real environments is difficult, expensive, and involves many legal and safety considerations. With Simutack, we present an open-source attack simulation framework that is capable of generating realistic attack scenarios for comprehensive security testing in the automotive development process. The framework integrates several classes of attacks, for instance, smart sensor attacks, V2X attacks, and attacks targeting the in-vehicle networks, which are all among the most commonly exploited attack vectors. We evaluate three common attack scenarios that showcase the applicability and capabilities of our work. In each scenario, the generated attack data is processed and returned to the simulation to visualize the attack’s effect on the vehicle and its environment. Furthermore, a custom autopilot application demonstrates the attack’s impact on autonomous driving systems.


---

# Summary

- The paper presents **Simutack**, an open-source attack simulation framework for testing security in Connected Autonomous Vehicles (CAVs). It integrates several simulators, including **CARLA**, **SUMO**, and **OMNeT++**, to create a comprehensive environment for generating realistic attack scenarios targeting various components like sensors, ECUs, and V2X communication.
- Simutack supports multiple attack types, such as **sensor spoofing**, **ECU manipulation**, and **network attacks**. It processes and returns the attack data to visualize its effect on the vehicle and its behavior within the simulation environment.
- The framework offers a **modular architecture**, allowing flexibility and easy addition of new attack vectors or sensors. It also provides several use cases demonstrating its capability, including **GNSS spoofing**, **camera blinding**, and **V2X message falsification**.

# Relevancy

- **Focuses on Simulation-Based Security Testing**: The use of Simutack with simulators like CARLA aligns perfectly with your objective of testing CAN traffic manipulation and other vulnerabilities in simulated environments.
- **Covers a Variety of Attack Vectors**: The different attack scenarios (e.g., sensor spoofing, ECU manipulation) provide methodologies directly applicable to your experiments with CAN traffic manipulation.
- **Emphasizes Modular and Flexible Architecture**: The framework’s flexibility to integrate various attack types and simulation components offers insights into building a similar setup for your testing purposes.

# Notable Sections and Pages

- **Section II: System Architecture (Pages 2-4)**: Describes Simutack’s modular architecture and the integration of CARLA and other simulators, providing foundational knowledge for developing your simulation environment.
- **Section III: Attack Implementation (Pages 5-7)**: Details various attack scenarios, including network and sensor attacks, directly relevant for planning and executing similar tests in your thesis.
- **Section IV: Evaluation (Pages 8-10)**: Provides case studies, such as the GNSS spoofing and V2X message falsification scenarios, offering examples for validating and analyzing CAN traffic manipulation in simulations.

# Recommendations

This paper is a crucial addition to your thesis literature as it provides a comprehensive framework for simulating and testing security in CAVs using environments like CARLA. I recommend citing it for its structured approach to simulating adversarial attacks and its detailed examples of real-world attack scenarios.

---

# Annotations  
(11/2/2024, 5:31:38 PM)

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=1&annotation=Y8YBG66A) “The framework integrates several classes of attacks, for instance, smart sensor attacks, V2X attacks, and attacks targeting the in-vehicle networks, which are all among the most commonly exploited attack vectors.” ([Finkenzeller et al., 2023, p. 1](zotero://select/library/items/EHFYYZR2)) 

V2X, Common

![](7DNPP4T9.png)  
>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=1&annotation=7DNPP4T9)  
([Finkenzeller et al., 2023, p. 1](zotero://select/library/items/EHFYYZR2)) 

Simutack

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=1&annotation=7V7UX3IH) “Connected and Autonomous Vehicles (CAVs), nonetheless, are very complex systems which comprise various components such as sensors, Electronic Control Units (ECUs), and communication interfaces. These components all expose many attack surfaces and are, thus, potential attack targets which need to be properly secured. Consequently, there is a great need for appropriate testing environments which safely generate realistic attack data for all required components.” ([Finkenzeller et al., 2023, p. 1](zotero://select/library/items/EHFYYZR2)) 

CAN, Vulnerabilities

![](DXLH9X8Q.png)  
>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=2&annotation=DXLH9X8Q)  
([Finkenzeller et al., 2023, p. 2](zotero://select/library/items/EHFYYZR2))

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=2&annotation=6I8EP6K4) “The CARLA simulator [4], which is based on Unreal Engine 4, is a comprehensive simulation environment that was specifically designed for that purpose. It is widely used in research and supports all common automotive sensors, for example, camera, Inertial Measurement Unit (IMU), Global Navigation Satellite Systems (GNSS), Radar, and Lidar. CARLA is not directly integrated in Simutack to maintain the flexibility of leveraging also other data sources in the future. Therefore, Simutack rather uses a general abstract sensor model with an additional CARLA-specific interface implementation. Another benefit of this abstraction is a possible categorization of all sensors based on their output data type, i.e., whether the sensor produces scalar values, vector outputs, or some more complex data structures. This makes the framework very generic, especially regarding the addition of new sensors and attacks.” ([Finkenzeller et al., 2023, p. 2](zotero://select/library/items/EHFYYZR2)) 

CARLA, IMU, GNSS, RADAR, LiDAR

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=3&annotation=IWHCDYEP) “Sensor attacks aim to affect the sensor’s perception of the physical world in a malicious way. Typical examples are jamming and spoofing which either prevent any perception at all or generate bogus sensor readings, respectively [8].” ([Finkenzeller et al., 2023, p. 3](zotero://select/library/items/EHFYYZR2)) 

Sensor, Jamming, Spoofing

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=3&annotation=AHVT5U7M) “A sensor jam, for example, results in either no output at all or a default value outside the reasonable measurement range dependent on the sensor. Constant offsets to the data can simulate systematic measurement errors that may arise from additive noise.” ([Finkenzeller et al., 2023, p. 3](zotero://select/library/items/EHFYYZR2))

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=3&annotation=8B8MG55T) “Spoofed input signals result in arbitrary sensor readings within the defined perception scope. In addition to these rather general relationships, Simutack supports also the simulation of more specific attacks, for instance, the camera blinding attack discussed in [3]. By pointing some light source toward the camera, the auto exposure mechanism is disturbed and too much light is perceived by the camera chip, appearing as white pixels in the final image.” ([Finkenzeller et al., 2023, p. 3](zotero://select/library/items/EHFYYZR2))

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=3&annotation=THMQU5XK) “Common network attacks comprise Denial-of-Service (DoS), message falsification, and message spoofing attacks. The first attack category essentially has similar repercussions as sensor jamming attacks, i.e., no (meaningful) data reaches the destination due to packet drops. The second category enables arbitrary message modifications including transmission-related bit errors.” ([Finkenzeller et al., 2023, p. 3](zotero://select/library/items/EHFYYZR2)) 

DoS

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=4&annotation=9K4JKBG8) “When spoofing messages, the attacker injects bogus packets with forged origins to trick the recipient into erroneous actions or decisions. The mentioned attacks, thereby, apply equally to in-vehicle communication and external V2X communication, respectively. Due to the high similarities and the comparable effect on the output data, in most cases, sensor and network attacks can be jointly implemented, especially when the data is used as input to test ECUs and related algorithms.” ([Finkenzeller et al., 2023, p. 4](zotero://select/library/items/EHFYYZR2)) 

V2X

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=4&annotation=8FZ7D433) “In the first scenario, we perform a DoS attack against the GNSS sensor. The previously introduced autopilot application uses this sensor to obtain information about the vehicle’s current position. Based on the current position and the given target position, the controller computes a target vector that represents the ideal driving direction towards the target. The difference of this direction and the vehicle’s current orientation, which can be acquired from the IMU sensor, is the error term that the lateral PID controller uses for its steering control. In the default case, the target direction is correctly determined which lets the vehicle properly take the curve to follow the ideal path (green line) as shown in Fig. 4a. In case of the DoS attack, the position updates from the sensor stop. Hence, the target direction cannot be properly computed anymore resulting in incorrect steering behavior visualized by the red line. Fig. 5 depicts the vehicle’s orientation over time captured by the GNSS sensor in both the normal and attack case to further elucidate the impact of the attack.” ([Finkenzeller et al., 2023, p. 4](zotero://select/library/items/EHFYYZR2)) 

GNSS

>[Go to annotation](zotero://open-pdf/library/items/VQ4GW8G4?page=6&annotation=97WBWHP8) “In [17], the authors extended the CARLA driving simulator to implement security attacks against GNSS sensors. In [18], Nesti et al. utilized CARLA in order to implement and evaluate Adversarial Patch Attacks. Finally, Iqbal et al. proposed a methodology for generating attack data for V2X communication using the Eclipse MOSAIC simulation framework [19]. This framework uses two vehicular simulation tools, namely OMNeT++ and SUMO, to simulate the attack and visualize it in 2D.” ([Finkenzeller et al., 2023, p. 6](zotero://select/library/items/EHFYYZR2)) 

CARLA, Eclipse MOSAIC, SUMO, OMNeT++,