---
title: "Car Hacking: For Poories a.k.a. Car Hacking Too: Electric Boogaloo"
authors: Dr Charlie Miller, Chris Valasek
year: 2014
---

# Car Hacking: For Poories a.k.a. Car Hacking Too: Electric Boogaloo
##### Charlie Miller, Chris Valasek (2014)
[Zotero-Link](zotero://select/items/@millerCarHackingPoories2014)

Tags: #CAN #Injection #TPMS #ECU #BrakeAttack #ABS 

>[!ABSTRACT]-
>


---

# Summary

- The authors aim to lower the entry barrier for automotive security research by providing instructions on how to set up ECUs without needing a full vehicle. They demonstrate how to power up and test ECUs using a simple setup involving a **bench environment** and commonly available tools like the **ECOM cable** and **ECOMCat** software.
- The paper covers various techniques for simulating automotive environments, including hooking up sensors, faking sensor signals, and configuring multiple ECUs to function as they would in a car. They also discuss **CAN message injection** attacks, showing how these can be tested in a controlled setup.
- To simulate a moving vehicle without a real car, they demonstrate how to use a **go-cart** as a test platform. This allows researchers to validate attacks and test steering and braking controls in motion while avoiding the costs associated with a full vehicle setup.

# Relevancy

- **Focuses on CAN Message Injection**: The techniques for injecting and manipulating CAN messages directly support your work on testing CAN traffic manipulation using simulation environments like CARLA.
- **Emphasizes Cost-Effective Testing**: The use of a bench setup and a go-cart provides practical alternatives for testing CAN manipulation without needing a full-scale vehicle, aligning with your goals of setting up and experimenting in a controlled environment.
- **Offers Practical Tools and Methods**: The description of tools like ECOMCat and methods for configuring ECUs is directly applicable for developing and testing your own CAN traffic manipulation techniques.

# Notable Sections and Pages

- **Putting ECUs on the Bench (Pages 4-15)**: Explains the setup process for ECUs on a bench, critical for understanding how to replicate vehicle systems in your experiments.
- **CAN Message Injection Attacks (Pages 20-23)**: Details various CAN message injection techniques, which are directly relevant for planning and executing CAN manipulation tests in CARLA.
- **Mobile Testing Platform (Pages 23-26)**: Discusses the use of a go-cart as a testing platform, providing an innovative and cost-effective way to simulate vehicle movement.

# Recommendations

This paper is a crucial addition to your thesis literature. It provides practical, hands-on methods for testing and manipulating CAN traffic without a full vehicle, making it directly applicable to your work. I recommend citing it for its detailed explanations and innovative approach to automotive security testing.

---

# Annotations  
(11/5/2024, 4:33:18 PM)

>[Go to annotation](zotero://open-pdf/library/items/LLBZV8HN?page=20&annotation=KVRRBC5B) “Many of the attacks outlined in our previous paper [1] are possible on the ECUs setup on the bench, in one form or another. These attacks were all carried out by injecting CAN messages onto the proper CAN bus. Messages can be injected onto the bench CAN bus as well. For example, the attacks which allowed controlling the steering, speedometer, on board navigation, odometer, etc are all possible on the bench. Likewise, attacks to control the seat belts and fuel gauge are also possible on the bench. You can also investigate and craft remote exploits against things like the Bluetooth stack and the tire pressure monitoring system (TPMS), see Figure below to see the telematics unit running on the bench.” ([Miller and Valasek, 2014, p. 20](zotero://select/library/items/7Y84BSXR)) 

CAN, Injection, TPMS, ECU

>[Go to annotation](zotero://open-pdf/library/items/LLBZV8HN?page=21&annotation=UTLUWPVP) “Attacks that rely on having a complete sub-system that is difficult to remove from the vehicle consist of a final set of attacks that are possible but difficult to evaluate on the bench. For example, consider attacks against the braking system. Specifically, on the Ford, there were two separate attacks against the ABS ECU. One locked the brakes while another bled the brakes (causing them not to stop the vehicle during the process). You can carry out both of these attacks against the ABS on the bench. However, since you likely don’t have the actual brakes on the bench, it’s hard to tell what is going on. For the one where the brakes lock, you can only hear the ABS make a humming sound. For the bleeding the brakes attack, you can hear the ABS make a loud pumping sound and if there is any residual liquid inside the ABS ECU, it will pump it out. Either way, you basically know you did something, but you don’t necessarily know if it was dangerous to a driver.” ([Miller and Valasek, 2014, p. 21](zotero://select/library/items/7Y84BSXR)) 

ABS, Brake attack, Brake bleed