---
title: A Process to Facilitate Automated Automotive Cybersecurity Testing
authors: Stefan Marksteiner, Nadja Marko, Andre Smulders, Stelios Karagiannis, Florian Stahl, Hayk Hamazaryan, Rupert Schlick, Stefan Kraxberger, Alexandr Vasenev
year: 2021
---

# A Process to Facilitate Automated Automotive Cybersecurity Testing
##### Stefan Marksteiner, Nadja Marko, Andre Smulders, Stelios Karagiannis, Florian Stahl, Hayk Hamazaryan, Rupert Schlick, Stefan Kraxberger, Alexandr Vasenev (2021)
[Zotero-Link](zotero://select/items/@marksteinerProcessFacilitateAutomated2021)

Tags: #V2X #ADAS #ISO #SAE #Vulnerabilities #ISO21434 #CAN #ECU #Fuzzing #Pentesting 

>[!ABSTRACT]-
>


---

# Summary

- The paper proposes a standardized process for **automated cybersecurity testing** of automotive systems to address the growing complexity and regulatory requirements in the industry. It emphasizes the need for efficiency and consistency in testing, aligning with industry standards and regulations such as ISO/SAE DIS 21434 and UNECE requirements.
- The process includes steps like **risk and threat analysis**, **defining test scenarios**, and developing **test cases** for penetration testing, fuzz testing, and vulnerability scanning. It integrates various testing methods, such as hardware-in-the-loop (HIL) and software-in-the-loop (SIL) setups, to validate the security of systems under test (SUTs).
- The authors illustrate how the process can be applied using **automated tools** and frameworks to reduce manual efforts and ensure reproducibility. They provide a detailed breakdown of the test planning, script development, and test case execution, demonstrating how automation can streamline the entire cybersecurity testing lifecycle.

# Relevancy

- **Aligns with Industry Standards**: The emphasis on ISO/SAE DIS 21434 and UNECE standards supports your objective of structuring experiments that align with industry requirements.
- **Covers Comprehensive Testing Approaches**: The detailed methodology for developing and executing automated tests (e.g., fuzz testing, penetration testing) provides a solid framework for your thesis on manipulating CAN traffic and testing vulnerabilities.
- **Demonstrates the Integration of Automated Tools**: The integration of automated frameworks and testing tools is directly applicable to your experiments in simulation environments like CARLA.

# Notable Sections and Pages

- **Introduction (Pages 1-2)**: Discusses the need for standardized and automated cybersecurity testing, setting the context for automotive system testing.
- **Testing Methodology (Pages 5-7)**: Details the testing process steps, including defining penetration test scenarios and developing fuzz testing scripts, which are essential for structuring your experiments.
- **Application of Automated Testing (Pages 8-10)**: Explains the implementation of automated tools and frameworks, providing insights into efficient test case generation and execution.

# Recommendations

This paper is a valuable addition to your thesis literature. It offers a comprehensive and structured approach to automating the testing of automotive systems, providing relevant methodologies and tools for your research. I recommend citing it for its detailed testing framework and application of automated cybersecurity techniques.

----

# Annotations  
(11/7/2024, 10:50:34 PM)

>[Go to annotation](zotero://open-pdf/library/items/PBSSYBWL?page=1&annotation=GHNM39PQ) “The rising complexity of modern automotive systems make it increasingly difficult to assure their cyberse curity. This is especially true due to the utilization of advanced driving assistance systems (ADAS) and au tonomous driving (AD) and the exposure to the outside by to vehicle-to-x (V2X) functions. This usage of new technology is likely to accelerate even more; also market leading manufacturers are beginning to equip their most selling model with V2X off-the-shelf [1]. These devel opments facilitate cybersecurity incidents (e.g. [2], [3]). Furthermore, an exponential rise of events and an acceleratingly adverse ratio between criminal activities versus benevolent security research results can be observed [4]. This has also been recognized by standardization bodies - currently, the most important standardization effort is ISO/SAE DIS 21434 [5]. Also, regulators be gin to take cybersecurity considerations into account; the most prominent example being a recent regulation by the United Nations [6]. The rising incidents and the regulators' requirements demand a substantially higher amount of cybersecurity engineering and testing of automotive systems. This also creates the need for higher efficiency which makes a standardized method of automotive cybersecurity testing necessary. Currently, automotive cybersecurity testing is mostly not holistic, unstructured, non-reproducible and more art than crafts. An approach to giving a standardized and industrial grade testing process is therefore necessary to cope with these upcoming challenges and will also be a prerequisite to automate steps of testing in this domain. This paper therefore presents an approach to such a standardized testing process.” ([Marksteiner et al., 2021, p. 1](zotero://select/library/items/HSLRCYCN)) 

V2X, ADAS, ISO, SAE, Vulnerabilities, ISO 21434

>[Go to annotation](zotero://open-pdf/library/items/PBSSYBWL?page=1&annotation=DQD76845) “The importance of creating generic testing frameworks or security testbeds to conduct automated security tests in automotive has already been highlighted in the past. More specifically, fuzz testing methods in accordance to industry-specific technologies such as the Controller Area Network (CAN bus) and the vehicle's electronic control unit (ECU) [7], [8], [9], [10] have been created. Similarly, there are frameworks that address system atic methods of security testing for automotive Blue tooth, Vehicular Ad Hoc Networks (VANETS) in Intelli gent Transportation Systems (ITS) and road services [11], © 2021 IEEE. Personal use of this material is permitted. Permission from IEEE must be obtained for all other uses, in any current or future media, including reprinting/republishing this material for advertising or promotional purposes,creating new collective works, for resale or redistribution to servers or lists, or reuse of any copyrighted component of this work in other works. [12], [13]. Finally there are integrated security testing frameworks that improve the standardized methods [9], [14], [15], [16], [17]. All of these works, however, do not encompass a defined process for automated security testing of complete automotive systems in a holistic manner. This work therefore complements the standards with a structured testing approach and underpins the technical testing solutions with a structured workflow method. As the upcoming ISO/SAE 21434 [5] is regarded to become the most important guideline, the process aligns to it (see V). There is a supplement to the ISO standard regarding testing (ISO/WO PAS 5112), which, however, is in a larval state.” ([Marksteiner et al., 2021, p. 1](zotero://select/library/items/HSLRCYCN)) 

CAN, ECU, Fuzzing

>[Go to annotation](zotero://open-pdf/library/items/PBSSYBWL?page=4&annotation=ZUFF4MNP) “Penetration testing is the legal and authorized process of exploiting systems in order to retrieve information which is important for enhancing security of the system. Penetration tests focus on specific aspects of security and are deployed manually or semi-automatic. To extend the capabilities, global-based adversarial activities must be deployed to maintain a holistic view of the system and deploy se curity tests from the adversary's perspective. The above methods are called red team assessments which usually include penetration tests; however, such methods extend the whole process [28]. A successful penetration testing methodology will discover functional weaknesses, de sign flaws and provide recommendations for security improvement [29]. To deploy penetration test scenarios, the scope and the context for deployment of appropriate attack strategies with respect to the system's potential weaknesses must be defined. In penetration testing, it is possible to attack vehicles without in-depth knowledge (black box) or from the inside (white box - meaning that some or full information is available to the red team). The process suggests cyber kill chain [30] and attack trees [31], where the latter approach allows for automated decision making for generating attack vectors.” ([Marksteiner et al., 2021, p. 4](zotero://select/library/items/HSLRCYCN)) 

Pentesting

>[Go to annotation](zotero://open-pdf/library/items/PBSSYBWL?page=6&annotation=PWMFXBSM) “This paper outlined a process for testing the cyber security of (particularly automotive) systems to fill the gap between existing standards for automotive security engineering and their hands-on, actual-system testing. The process provides a comprehensive, automatable ap proach for system testing based on ISO/SAE DIS 21343. Due to rising complexity and regulators' requirements this is necessary as it facilitates a conceivable need for industrializing automotive cybersecurity testing. The process itself is arranged generically in order to allow for using already existing procedures (e.g. a present risk assessment process) not mandating any specific method. Future work will therefore involve a reference implementation on both processual and technical level.” ([Marksteiner et al., 2021, p. 6](zotero://select/library/items/HSLRCYCN))