---
title: "Cybersecurity and Forensics in Connected Autonomous Vehicles: A Review of the State-of-the-Art"
and Forensics in Connected Autonomous Vehicles: A Review of the State-of-the-Art
authors: Prinkle Sharma, James Gillanders
year: 2022
---

# Cybersecurity and Forensics in Connected Autonomous Vehicles: A Review of the State-of-the-Art
##### Prinkle Sharma, James Gillanders (2022)
[Zotero-Link](zotero://select/items/@sharmaCybersecurityForensicsConnected2022)

Tags: #LiDAR #Sensors #Collision #RealAccident #Vulnerabilities #Forensics #Infrastructure #SAELevels #Camera #LiDAR #RADAR #Ultrasonic #GNNS #GPS #Actuation #DSRC #V2V #V2I #V2X #V2P #ITS #Spoofing #Jamming #Tampering #PhysicalAttack #RemoteAttack #Malware #Impersonation #DataFalsified #MITM #Blackhole #Piggyback #SupplyChain #CPS #Pentesting #MachineLearning #AI #SafetySecurity #RealAccident #DataStorage 

>[!ABSTRACT]-
>Connected Autonomous Vehicles (CAVs) are transformational technologies that have demonstrated significant potential for shaping the future of transportation systems. CAV research has been conducted extensively, both in academic and industrial pursuits. The intention was to put CAVs on the road, but the safety and efficiency of CAVs must be prioritized for this purpose to come to fruition. This technology is built upon sensors, and network communications have the potential to improve automotive infrastructure, reduce traffic and accidents, and facilitate a unified transportation system. Although the auspiciousness of these vehicles is clear, persistent threats exist in terms of cybersecurity attacks, which jeopardize the safety and effectiveness of CAVs. Our study provides a comprehensive dissection of cyberattacks and digital forensics on CAVs. We begin by discussing each element of a standard CAV network and then illustrate the current security. The three main components of CAVs– sensors, communication networks, and actuatorswere analyzed in detail. The expansion of cybersecurity and forensic issues is presented with additional investigations into traditional and artificial intelligence-based cyber-defense techniques. Our work concludes by discussing the open challenges and potential research areas for developing robust cybersecurity and forensic solutions exclusively for CAVs.


---

# Summary

- The paper provides a comprehensive review of the cybersecurity and forensics landscape in Connected Autonomous Vehicles (CAVs). It covers the architecture of CAV networks, the roles of sensors, communication networks, and actuators, and the existing and potential cyber threats targeting each component.
- The authors discuss traditional and AI-based defense mechanisms, integrating both proactive and reactive approaches for CAV security. The paper highlights the need for robust forensics capabilities, outlining how these can be integrated with existing security measures to enhance resilience against attacks.
- The review also identifies open challenges and future research directions, including the integration of AI for intrusion detection, the development of comprehensive standards, and ensuring the privacy and integrity of data in CAV systems.

# Relevancy

- **Explores Cybersecurity Threats and Defenses**: The detailed analysis of CAN bus vulnerabilities and AI-based security techniques aligns closely with your focus on manipulating CAN traffic and testing vulnerabilities in CARLA.
- **Discusses Forensics Integration**: The emphasis on integrating forensics into AV systems for both detection and investigation offers valuable insights for structuring your experiments and evaluating security measures in simulation.
- **Identifies Open Challenges**: The review's discussion on current gaps and research opportunities can inform your thesis direction, especially in designing and testing innovative solutions in simulated environments.

# Notable Sections and Pages

- **Section III: CAV Architecture (Pages 3-5)**: Describes the architecture and components of CAV networks, including CAN systems, providing a foundation for understanding attack surfaces relevant to your thesis.
- **Section IV: Cybersecurity Standards (Pages 6-8)**: Reviews standards such as ISO/SAE 21434 and WP.29, relevant for aligning your simulation experiments with industry standards.
- **Section V: Challenges in CAV Cybersecurity (Pages 10-12)**: Highlights existing challenges in protecting CAVs, including gaps in CAN traffic security, offering insights for structuring your manipulation tests.
- **Section VI: Future Directions and Research (Pages 13-15)**: Discusses potential research areas, particularly the integration of AI in security protocols, which could guide your exploration of AI-based solutions in CAN manipulation experiments.

# Recommendations

This paper is a crucial addition to your thesis literature. It offers a detailed examination of CAV cybersecurity, including specific CAN vulnerabilities and solutions, which is directly applicable to your work. I recommend citing it for its thorough review of state-of-the-art cybersecurity measures and its integration of AI and forensics into AV systems.

---

# Annotations  
(11/2/2024, 10:41:49 AM)

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108979&annotation=BNKZSQWV) “CAVs rely on several sensors, such as radar, LiDAR, and cameras, to survey the driving environment in real-time and notify the occupant of any immediate threat or hazard. CAV actuators, such as throttle, steering, and braking, enable the system to react accordingly after receiving information from the sensors. For example, the radar senThe associate editor coordinating the review of this manuscript and approving it for publication was Lorenzo Mucchi . sor notices an object on the road, prompting the vehicle to switch lanes and avoid collisions.” ([Sharma and Gillanders, 2022, p. 108979](zotero://select/library/items/HL9J4F8K)) 

LiDAR, Sensors, Collision

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108979&annotation=2SZHB9XW) “With the rapid advancement of CAV technologies, the transportation industry is inching toward an era of full autonomy, as defined in SAE J3016 [3]. Original equipment manufacturers s (OEM) optimizes their vehicle’s software with updates to keep their systems up to date. Many current CAVs offer level 2 autonomous vehicle features, including automatic cruise control, hazard warnings, and emergency braking.” ([Sharma and Gillanders, 2022, p. 108979](zotero://select/library/items/HL9J4F8K)) 

SAELevels, OEMs, CAVs

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108979&annotation=MZZRHURW) “Despite e these technological improvements, cyber-attacks have become a major threat to the intelligent transportation systems (ITS) of CAVs [4]. Although millions of investments are being made to improve CAV robustness and safety, security compromises continue to increase. There have been several real instances, such as the death of two passengers driving a Tesla by hitting a semi-truck in Florida in July 2022 [5], and the death of a bicycle on the road at night in Arizona when hit by an Uber self-driving car [6]. These incidents indicate that CAV manufacturers and systems have a long way to go before earning the trust they desperately need.” ([Sharma and Gillanders, 2022, p. 108979](zotero://select/library/items/HL9J4F8K)) 

Real Accidents, Vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108980&annotation=6L487AUH) “This study primarily focuses on discussing cybersecurity, forensics, and defense mechanisms of CAVs. Cybersecurity and forensics in CAVs as two essential sides of the same coin - the work they do is very similar but differs in a few key ways. Cybersecurity is a preventive function, and forensics is a detective function; in other words: the cybersecurity team works to implement and maintain a robust information security system, to defend the systems from cyber-attacks; in the case that their efforts fail, and an attack is made, the forensics team works to identify the hack, understand the source, and recover compromised data by tracing the digital footprints of the attacker.” ([Sharma and Gillanders, 2022, p. 108980](zotero://select/library/items/HL9J4F8K)) 

Forensics

![](4THQXUUI.png)  
>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108980&annotation=4THQXUUI)  
([Sharma and Gillanders, 2022, p. 108980](zotero://select/library/items/HL9J4F8K)) 

SAELevels

![](DPVHVN98.png)  
>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108981&annotation=DPVHVN98)  
([Sharma and Gillanders, 2022, p. 108981](zotero://select/library/items/HL9J4F8K)) 

Infrastructure

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108981&annotation=UPSCVVYU) “Driver Assistance (Level 1): Minor driving tasks performed by automation such as adaptive cruise control 3) Partial Automation (Level 2): The driver must stay alert and actively supervise the driving via the Advanced Driving System and should be able to take over steering, acceleration, and braking in specific driving scenarios. 4) Conditional Automation (Level 3): The driver does not need to be fully alert and oversee driving tasks, meaning they can engage in other activities. However, the driver must be ready to perform manual control in an emergency. Technologies such as traffic jam assistance are present at this level of automation. 5) High Automation (Level 4): Drivers are not required for specific use cases. In such scenarios, the vehicle may not have a steering wheel and pedals but will be restricted to particular geographic boundaries using geofencing technology. Certain conditions, such as severe weather, may temporarily limit or cancel the vehicle operation. For example, driverless taxis and public transportation are at this level of automation. 6) Full Automation (Level 5): The highest level of automation in vehicles where no human interaction is required, and a car can drive itself everywhere in all conditions.” ([Sharma and Gillanders, 2022, p. 108981](zotero://select/library/items/HL9J4F8K)) 

SAELevels

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108981&annotation=GRG6B4MP) “An external sensor is a perceptual sensor that manages the external state of a vehicle by sensing its external environment. The Internal sensor is more analytical, mainly containing the internal states of the car, and it processes the data received by the vehicle. The operation of each sensor is discussed below:” ([Sharma and Gillanders, 2022, p. 108981](zotero://select/library/items/HL9J4F8K)) 

Sensors

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108981&annotation=HYF5BN46) “The most widely adopted sensor technology for Autonomous Driving Systems, which boasts the ability to distinguish various environments and targets, cameras are becoming widely implemented even in manually controlled vehicles. Several cameras have been integrated with sensory technology, such as depth-of-field, RGB, DVS, and optical flow. Cameras and vehicle-incorporated software can detect both moving and static obstacles, including road signs, emergency vehicles, traffic lights, pedestrians, and other visual stimuli that a human can identify. CAV cameras operate based on the landing light emitted from objects on a photosensitive surface through a lens [15]. There are many types of cameras depending on the lens type (i.e., wide-angle for near-field and narrow-angle for far-field applications) or the parts of the spectrum they cover, such as night vision (NV) or specialty chips such as High Dynamic Range (HDR) which are extremely sensitive to light. High-resolution cameras, such as infrared cameras, outperform human eyes because they can detect specific wavelengths in the spectral range of 0.91.7 microns. Cameras are essential for automated vehicles. However, they are heavily affected by low-light weather conditions and require extensive computational processing to extract the data.” ([Sharma and Gillanders, 2022, p. 108981](zotero://select/library/items/HL9J4F8K)) 

Camera

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108982&annotation=894G6V3W) “Light Detection and Ranging (LiDAR) technology is used to locate objects on roads and measure their distance. It operates based on the principle of emitting laser light pulses that reflect from a target object. The time interval between the emission and reception of the light pulse back to the sensor is used to calculate the distance [16]. Using shorter-wavelength laser light helps achieve a higher measurement accuracy and spatial resolution. The distance was estimated at a clocking speed of 150 kHz, and the ability to chart the navigational environment using LiDAR was instantaneous. LiDAR scans its surroundings and generates a three-dimensional (3D) representation of the scene as a point cloud. Currently, 3D spinning LiDARs are more commonly used to ensure reliable perception under any light condition (day or night) [16]. Issues with LiDAR technology include high manufacturing costs and vulnerability to cyberattacks; however, newly optical phased array LiDAR technology [17] has demonstrated success in meeting the performance and cost requirements of the AV market. Additionally, unlike cameras, LiDAR sensors do not generate information about their surroundings in color and require data fusion with other sensors to make decisions.” ([Sharma and Gillanders, 2022, p. 108982](zotero://select/library/items/HL9J4F8K)) 

LiDAR

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108982&annotation=KH3YL9PC) “or Radio detection and ranging, is used to detect objects at a distance and gauge their speed and characteristics. It consists of a transmitter, receiver, receiving antenna, processor, and radio-wave transmission and reflection techniques to estimate the distance from the target object. The time required for a radio wave to travel forward and backward is determined by the distance between the radio wave source and the target object that reflects the radio waves, similar to LiDAR. Although some differences between radar and LiDAR devices are that radar uses radio waves with an antenna, while LiDAR devices have specialized optics and lasers for receiving and transmitting. Second, the radar can detect the distance of a target object rather than its actual appearance, as opposed to LiDAR, which can detect and locate a target object. Lastly, (iii) radar works in overcast weather conditions and at night, but neither LiDAR nor camera offers these features on their own.” ([Sharma and Gillanders, 2022, p. 108982](zotero://select/library/items/HL9J4F8K)) 

RADAR

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108982&annotation=7LV5DKYX) “Similar to certain living organisms that use echolocation, ultrasonic sensors emit sound waves to process the distance between themselves and nearby objects. Ultrasonic sensors are interior sensors that work alongside other sensors, such as radar, cameras, and LiDAR, to paint a complete picture of any surrounding vehicles. In general, ultrasonic sensors perform best when detecting proximity and slow speeds. However, they also function well under fog, severe weather, and lowlight conditions. These sensors are generally the cheapest of all the sensor types discussed thus far; however, unlike LiDAR, they do not have the resolution to detect small or multiple objects moving at high speed. These sensors best detect solid hazards such as traffic cones and barriers.” ([Sharma and Gillanders, 2022, p. 108982](zotero://select/library/items/HL9J4F8K)) 

Ultrasonic

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108982&annotation=RWMDPWDM) “The Global Navigation Satellite Units (GNSS) sensors can be used to navigate vehicles from points A to B. This sensor works along with the GPS of the CAVs to determine a location’s latitude and longitude with assistance from satellite transmissions. The user interface can emulate existing GPS systems, requiring minimal human input because the vehicle does the rest. Regarding technological aspects, a GPS tracking system uses a GNSS network to communicate with satellites. In contrast, GNSS uses microwave signals transmitted to GPS devices to provide information on location, speed, time, and direction necessary for practical, automated driving.” ([Sharma and Gillanders, 2022, p. 108982](zotero://select/library/items/HL9J4F8K)) 

GNSS, GPS

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108982&annotation=96643FHN) “Actuators are another essential component of Autonomous Driving System technology integrated into CAVs. Once the data are received from the environment via sensors, the vehicle’s Electronic Control Unit (ECU) determines the activation of the actuator. Actuators operate behind the scenes within vehicles to convert energy into reality. They perform various convenient functions, including backup cameras, blind spot monitoring, lane assistance, emergency braking, and adaptive cruise control [18]. Currently, most vehicles on the road already have actuators (described below) required for autonomous vehicles. • Throttle Actuator - Pressing or releasing the gas pedal to control the vehicle’s speed via electronic control. • Steering Actuator - Controlling the direction of the vehicle via electrically assisted power steering.” ([Sharma and Gillanders, 2022, p. 108982](zotero://select/library/items/HL9J4F8K)) 

Actuators

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108983&annotation=JVARBKAC) “Braking Actuator - Deciding when to stop a moving vehicle via electronic stability control.” ([Sharma and Gillanders, 2022, p. 108983](zotero://select/library/items/HL9J4F8K))

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108983&annotation=FVV792T9) “Connected Driving System technology connects the vehicle’s vehicle and roadside infrastructure (traffic lights, roadside units, pedestrians, drones, etc.) within the network of intelligent transportation systems. It allows them to communicate bidirectionally within a 300-meter range. The broadcast includes vehicle credentials (longitude, latitude, speed, heading, etc.), safety warnings, weather, and traffic congestion details that determine safety, mobility, and driving experience. The data within the connected network are meant to be broadcast anonymously. That is, the communicating devices cannot be tracked. This technology is based on various standards included in the DSRC protocol stack (Figure 3), which are primarily based on the IEEE 802.11p and IEEE 1609 standards. Below, we explain each criterion in detail:” ([Sharma and Gillanders, 2022, p. 108983](zotero://select/library/items/HL9J4F8K)) 

Connectefd Driving Systems

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108983&annotation=5AFQGM7X) “The V2V communication system allows data transmission between vehicles by broadcasting it in real-time. This includes exchanging information wirelessly, such as the speed, heading, and position of the surrounding cars, to avoid crashes, ease traffic congestion, and improve the driving environment. The V2V technology in vehicles communicates via Basic Safety Messages, A.K.A. BSMs, which have a range of approximately 300 meters (best-case scenarios) and promptly broadcast information at a rate of 10Hz. Information broadcasts via BSMs allow vehicles to operate safely and efficiently.” ([Sharma and Gillanders, 2022, p. 108983](zotero://select/library/items/HL9J4F8K)) 

V2V

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108984&annotation=J68ALIM6) “A vehicle for the infrastructure communication system was built to enhance vehicle safety. vehicles communicate with road infrastructure via Road Side Units (RSUs) and share/receive information such as traffic/road/weather conditions, speed limits, and accidents. Connectivity is used for bidirectional communication through hardware, software, and firmware to support systems such as lane signs, road signs, and lighting systems. This technology warns drivers of collisions, jams, fast curves, and speed. V2I technology will also enhance driver-assistance methods, such as parking and automatic toll payments, which could further assist in planning smart city traffic lanes and parking lots.” ([Sharma and Gillanders, 2022, p. 108984](zotero://select/library/items/HL9J4F8K)) 

V2I

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108984&annotation=99DELSID) “Vehicle to everything is the communication between a vehicle and any device that could be affected by the vehicle’s information on the road. The main purpose of V2X technology is to enhance safety, save energy, and make traffic on the road more efficient as part of an intelligent transportation system. The key components of the V2X technology are V2V and V2I. When V2X systems are integrated into traditional vehicles, drivers can receive essential information regarding weather patterns, nearby accidents, road conditions, road work warnings, approaching emergency vehicles, and the activities of other drivers on the same road.” ([Sharma and Gillanders, 2022, p. 108984](zotero://select/library/items/HL9J4F8K)) 

V2X

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108984&annotation=Z4JRLFBD) “Vehicle to Pedestrian communication networks provides direct communication between vehicles and pedestrians. The scope of the V2P also applies to cyclists. The signals are transmitted from the smartwatch to the onboard unit if any of the pedestrians are within the range of connected vehicles. Similar to V2V, safety messages, including speed, location, and heading information from pedestrians, are broadcast to approaching vehicles and vice-versa. Depending on the frequency of the V2P, it can send a maximum of 10 alerts per second.” ([Sharma and Gillanders, 2022, p. 108984](zotero://select/library/items/HL9J4F8K)) 

V2P

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108984&annotation=4XJLBNS3) “The ITS is an application that aims to supply services related to transportation and traffic management services to make driving smarter, safer, and more coordinated. Figure 4 shows the taxonomy of the Intelligent Transportation System. The system aims to deliver real-time information, including travel time, speed, delay, road accidents, route changes, diversions, and work zone conditions. The ITS relies heavily on data FIGURE 4. Taxonomy for ITS applications [24]. collection and analysis via sensors. Decision-making is performed after analyzing the data exchanged among vehicles, transport infrastructure, and pedestrians. Sensor deployment within the transportation network provides drivers with new services such as smart parking, electronic toll collection, and reduced pricing according to congestion levels on the road. Road sensors collect environmental data in real-time, which are then processed and analyzed to improve transportation networks and make them resilient [25]. As described in [26], sensors in ITS can be classified into two categories based on their location: intrusive and non-intrusive. Interior sensors were installed on road pavement surfaces. They have high vehicle detection accuracy but high installation and maintenance costs. Non-intrusive sensors are installed at different locations in the infrastructure (not road pavement) to detect a vehicle’s speed, direction, and lane coverage. However, they are expensive and affected by environmental conditions. Table 1 provides an overview of road sensors and their functioning in an Intelligent Transportation System. The authors recommend the reader for an in-depth study of road sensors [24]. Some applications of Intelligent Transportation Systems include the following: • Real-time Parking Management • Electronic Toll Collection • Emergency Vehicle Notification Systems • Automated Road Speed Enforcement • Speed Alerts • Collision Avoidance Systems • Dynamic Traffic Light Sequence • RFID in Freight Transportation” ([Sharma and Gillanders, 2022, p. 108984](zotero://select/library/items/HL9J4F8K)) 

ITS

![](3V8N9W27.png)  
>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108985&annotation=3V8N9W27)  
([Sharma and Gillanders, 2022, p. 108985](zotero://select/library/items/HL9J4F8K)) 

ITS Sensors

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108987&annotation=LY3T6JZM) “To drive autonomously and safely, CAVs must perceive their surroundings by using sensors. Sensors rely on computerenabled object-based detection, which helps CAVs find an object, label it, and decide its action. However, the problem is that the sensors technology has a long way to go before it can aid CAVs with decision-making to drive safely on the road. Sensor-based applications are highly vulnerable to cyberattacks and can lead to disruption, disabling, destroying, or maliciously controlling a CAV/environment, or destroying the integrity of data. The threats to the sensing layer in CAVs include (are not limited to): 1) Spoofing Attacks: Spoofing attacks are performed when an attacker pretends to be someone or something else that appears to be associated with a trusted/authorized source in the communication network. For CAVs, spoofing attacks can involve i) altering the distance between the source and receiver by injecting incorrect sensor data values. (ii) obtaining objects on the road, and (iii) injecting fake signals into the sensors. Researchers have demonstrated successful spoofing attacks using GPS, cameras, LiDAR, ultrasonic, and wheel encoder sensors in CAVs.” ([Sharma and Gillanders, 2022, p. 108987](zotero://select/library/items/HL9J4F8K)) 

Spoofing

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108987&annotation=R5G9JF3Z) “Jamming Attacks: A jamming attack is executed by an attacker in the network - to disrupt the transmission and reception of legitimate wireless signals among sensors. This type of attack can be launched by an attacker both internally and externally. The attacker uses a high-power transmitter called Jammer to interfere with the wireless network, thereby preventing the source sensor from either stopping the transmission or receiving legitimate data packets. Jamming attacks can occur on several sensors in CAVs including LiDAR [36], [37], Radar [38], Camera [36], and Ultrasonic Sensors [39].” ([Sharma and Gillanders, 2022, p. 108987](zotero://select/library/items/HL9J4F8K)) 

Jamming

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108987&annotation=H7F5DFI9) “Tampering Attacks: Tampering attacks occur when an attacker manipulates the data parameters exchanged between the sensor and the receiver without user authentication. The tampering can be performed in two ways: (i) Remotely, and (ii) Physically. Remote tampering can be performed either by placing stationary attacking equipment along the roadside unit or by manipulating the environment scenery, traffic lights, or road signs to deceive the vehicle’s sensors. However, physical tampering requires an attacker to directly access a benign vehicle. The attacker attacks by physically damaging vehicle sensors or by placing materials that interfere with the sensor and vehicle control system [40], [41].” ([Sharma and Gillanders, 2022, p. 108987](zotero://select/library/items/HL9J4F8K)) 

Tampering, phyiscal, remote

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=S3295VTB) “Adversarial Attacks: Adversarial attacks are performed using artificial intelligence techniques. The attack involves introducing adversarial examples into the sensor perception model and subtly modifying the original image such that changes are almost undetectable to the human eye. This could result in the misclassification of elements, such as road signs, and traffic lights. Several researchers have successfully performed adversarial sensor attacks on LiDAR [42], [43], cameras [44], Radar [45], and ultrasonic sensors [46].” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Adversarial, AI

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=FDPHQTTS) “Denial of Service/Distributed Denial of Service Attacks: Denial of Service or Distributed Denial of Service attacks in CAVs occur when an attacker injects an enormous number of fake objects created by jamming or spoofing attacks. When the number of injected signals is greater than the maximum number of objects that any sensor can track, the system becomes unstable and may result in life-threatening events. LiDAR [47] sensors are extremely sensitive to this type of attack.” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

DoS, DDoS

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=WWRLK6P8) “Sybil Attacks: Victim of this type of attack usually involves scenarios in which reputation is a major aspect. The attacker creates many pseudonyms identities in the system and uses them to gain maximum influence. Based on this influence, the attacker misleads other devices in the system for personal benefit, including diverting the traffic to get the road to itself, creating accidents by sending incorrect location/speed information, and creating illusion scenarios for vehicles on the road [48]. This is one of the most serious communication attacks as the attacker claims to be at a different geographical location at the same time [49].” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Sybil

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=Q4CGKSMX) “Replay Attacks: Replay attacks are performed when an attacker hijacks and records the signals transmitted by the sensor(s) without user knowledge. The attackers then conduct a replay attack by sending the recorded signals back to the sensor(s) to cause the sensor(s) to map non-existent objects. LiDAR [42], [47], [50]” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Replay

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=Y6SI6K25) “Relay Attacks: Relay attacks are an extension of replay attacks that typically involve two people working together. The attacker receives the signals transmitted by the sensor(s) and forwards them to the receiver at different locations. The receiver then re-sends the signals back to the original sensor(s), resulting in an incorrect object location map. Some successful studies on relay attacks are included in [51].” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

relay

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=QUEFFJGF) “Remote Attacks: Remote attacks refer to attacks performed in a network without any physical contact with devices. In such attacks, remote attackers search for vulnerable points in device/network security to ensure the system is remote, steal data information, and/or create accidents. In CAVs, remote attacks generally occur through a vehicle infotainment system [52]. A few previous studies demonstrating successful sensor remote attacks include [36], [53], [54], [55]” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Remote

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=YL566FII) “Malware: Malware attacks are common cyberattacks in which malware executes unauthorized actions on a victim’s system [56]. This includes the introduction of ransomware, spyware, and viruses into a network system [57].” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Malware

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=GIR28D6R) “Impersonation Attacks: In an Intelligent Transportation System, every device has a unique identification number, which helps recognize the vehicle and messages transmitted. An impersonation attack occurs when an attacker uses the identity of another vehicle to steal information or gain control over a device [58]. In the case of CAVs, the attacker can impersonate the RSUs to trick the connected devices in the network to share their authentication detail, and then use the information to perform malicious activities.” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Impersonation

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=Q7K76333) “Data Falsified Information Attacks: This type of attack occurs when an attacker broadcasts/sends incorrect information for personal gain [59]. Misleading information can create issues such as communication congestion, increased travel time, and imbalance in the usage of transportation resources.” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Data Falsified

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=IXUYI4EL) “Man-In-The-Middle Attacks: These attacks pose a serious threat to network security by either eavesdropping or altering the messages exchanged between two legitimate vehicles [60]. The exchanged information may contain sensitive and delay-intolerant information, such as emergency warnings, which could result in the dissemination of compromised and incorrect information throughout the network, thereby violating the main pillars of security and privacy requirements.” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

MITM

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108988&annotation=HRXCUE8F) “Blackhole Attacks: Dropping a data packet instead of sending it to its destination results in a black hole scenario where no data packet will move through to other devices in the network. These are also known as Routing Attacks [61]. Thus, we have Greyhole attacks in which only a small percentage of data packets are dropped to avoid detecting the attacker.” ([Sharma and Gillanders, 2022, p. 108988](zotero://select/library/items/HL9J4F8K)) 

Blackhole

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108989&annotation=ZX3TQWS8) “Sensor Fusion Attacks: Sensor fusion is the process of combining the input data from several sensors to predict a complete, correct, and dependable picture of a dynamic environment. Sensor fusion uses raw data from sensors, extracts the key features of the collected data, and then uses the information to make an informed decision. The process involves the fundamentals of machine learning models including statistical, probabilistic, knowledge-based, and reasoning-based methodologies. However, machine learning models, are vulnerable to attacks such as data poisoning, escape attacks, model stealing attacks, and model inference attacks [62].” ([Sharma and Gillanders, 2022, p. 108989](zotero://select/library/items/HL9J4F8K))

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108989&annotation=VKRG28PZ) “Piggybacking Attacks: Applications and decisionmaking mechanisms are updated and installed via human intervention and automatic prompts. An attacker can change the source of software during the installation process, leading to a modified version of the software [63]. This manipulation may affect the capability and execution of ongoing processes.” ([Sharma and Gillanders, 2022, p. 108989](zotero://select/library/items/HL9J4F8K)) 

Piggyback

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108989&annotation=ZYT6HXGV) “Supply-Chain Attacks: Applications and decisionmaking mechanisms depend on third-party software and libraries that ease the functionalities required by software [64]. Any attack that affects the dependency of the software may have a critical impact on the action engine and change many CAVs [65].” ([Sharma and Gillanders, 2022, p. 108989](zotero://select/library/items/HL9J4F8K)) 

SupplyChain

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108990&annotation=M9V8V3MJ) “Cyber Physical System (CPS) Forensics: CPSs have multiple computing components including nodes, sensors, actuators, smart devices, and software. These components are connected via wired networks and/or different types of wireless networks to control the physical environment of the system. CAVs are a subset of CPS, therefore, knowledge is directly transferable.” ([Sharma and Gillanders, 2022, p. 108990](zotero://select/library/items/HL9J4F8K)) 

CPS

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108990&annotation=69J49LA7) “Penetration Testing: Pen testing is critical for assessing the overall strength and vulnerability of IoT devices to cyber-attack.” ([Sharma and Gillanders, 2022, p. 108990](zotero://select/library/items/HL9J4F8K)) 

Pentesting

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108991&annotation=7WYASQTS) “deliberating on worthy investments, vehicle owners would want to ensure physical safety. Statistics reveal that 45% of those surveyed in the United States claim that they do not feel secure in autonomous self-driving cars [134]. Incidents such as those involving the Volvo XC90 and Tesla Model X have contributed to shaky early impressions of autonomous vehicles [135]. In the world of commercialism, the mystique of self-driving cars is vague; however, this is before these vehicles are allowed in the hands of consumers. The perception of autonomous vehicles by the general population is reliant on these limited events, and autonomous cars are comparable to niches of other technologies. In addition to cybersecurity, autonomous cars need to prove their safety features through rigorous testing and results that shed a positive light on technology. Self-driving car sensors, artificial intelligence, and machine learning must be performed through simulations and experiments using real vehicles [135]. Therefore, the first step before cybersecurity fortification is to improve the reputation of autonomous vehicles by developing and displaying their safety functionalities.” ([Sharma and Gillanders, 2022, p. 108991](zotero://select/library/items/HL9J4F8K)) 

Machine Learning, AI, Safety, RealAccidents

>[Go to annotation](zotero://open-pdf/library/items/28UEEG2D?page=108991&annotation=ERLQCGW7) “Data is the most valuable entity for automotive players, as connectivity makes its way into both vehicles and the environment. By 2023, there are expected to be 37.9 million vehicles on the road, generating 300 petabytes of data annually, with at least five TB of data generated per day. The data were obtained from onboard hardware, which included data from several sensors. Data are stored, transferred, and secured across many endpoints over various delivery networks. The biggest question here is which storage approach should be adopted to manage data. This issue becomes even more tedious as 5G approaches quickly, which requires automakers to search for the best storage choice, considering cost and performance as the principal factors.” ([Sharma and Gillanders, 2022, p. 108991](zotero://select/library/items/HL9J4F8K)) 

Data Storage