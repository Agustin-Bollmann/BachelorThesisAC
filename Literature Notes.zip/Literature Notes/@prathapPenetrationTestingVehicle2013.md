---
title: Penetration Testing of Vehicle ECUs
authors: Vijaiya Prathap, Abhishake Rachumallu
year: 2013
---

# Penetration Testing of Vehicle ECUs
##### Vijaiya Prathap, Abhishake Rachumallu (2013)
[Zotero-Link](zotero://select/items/@prathapPenetrationTestingVehicle2013)

Tags: #Abbreviations #History #Code #RSU #InternalCommunication #InterVehicle #VANET #OBU #ECU #CAN #MOST #LIN #V2V #InVehicle #CANDataRate #CSMACD #FlexRay #BusProperties #TopLevelAttack #CIA #PhysicalAttack #Intrusive #SideChannel #ReverseEngineering #AUTOSAR #Encryption #Seed #FOTA #OBD #PowerTrain #ABS #ESC #HVAC #Infotainment #TCU #Telematics #GPS #Pentesting #InternalTest #ExternalTest #PentestingProcess #PentestingPlanning #PentestingDiscovery #PentestingAttack #PentestingReporting #PentestingCleaning #WhiteBox #GreyBox #BlackBox #ECUMemory

>[!ABSTRACT]-
>The automobile industry has grown rapidly in the last few decades. The industry is moving towards electronics and software for better efficiency and results. These electronic components consist of hardware and software to control important operations like braking, engine control etc. The future automobiles will be highly sophisticated and extremely integrated with other devices like smart phones and tablets and update protocols like Firmware Update Over the Air (FOTA). It is also possible to have car to car and car to infrastructure communication which will open up for lots of security attacks on the Electronic Control Units (ECUs).


---

# Summary

- The thesis focuses on the **penetration testing of Electronic Control Units (ECUs)** in modern vehicles, detailing the structure and communication protocols (e.g., CAN, LIN, MOST, Flexray) used in in-vehicle networks. It emphasizes the vulnerabilities inherent in these systems due to the increased use of software and electronics in automobiles.
- The study discusses various attack methods, including **software attacks**, **reverse engineering**, and **brute force** techniques, and provides a framework for performing penetration tests on ECUs. It highlights the need for such tests to discover and address vulnerabilities that could compromise vehicle safety.
- The authors explore **countermeasures** such as secure software downloading, the use of **security modules**, and forensic protection mechanisms to mitigate discovered vulnerabilities.

# Relevancy

- **Details the Penetration Testing Process**: The methodology outlined aligns closely with your thesis's objective of testing CAN traffic manipulation and developing strategies for penetration testing in simulated environments like CARLA.
- **Covers CAN Protocol Vulnerabilities**: The discussion on CAN, including its weaknesses and possible attack vectors, provides foundational knowledge essential for structuring your experiments and understanding the scope of CAN manipulation.
- **Explores Defense Mechanisms**: The proposed countermeasures and security enhancements offer insights that could support the development of secure testing frameworks in your work.

# Notable Sections and Pages

- **Section 2: In-Vehicle Network (Pages 10-12)**: Provides an overview of the different protocols used in automotive networks, essential for understanding the structure of CAN traffic.
- **Section 6: Penetration Testing Methodology (Pages 25-29)**: Explains the penetration testing process, including internal vs. external testing, relevant for designing your experimental setup.
- **Section 7: Attacks on ECUs (Pages 30-32)**: Discusses specific attack methods, such as brute force and software manipulation, which can inform your experiments on CAN traffic manipulation.
- **Section 8: Countermeasures (Pages 33-36)**: Outlines security solutions for protecting ECUs, providing a reference for understanding and implementing defense strategies.

# Recommendations

This paper is a valuable addition to your thesis literature. It offers a comprehensive examination of ECU vulnerabilities and penetration testing methods, directly applicable to your experiments involving CAN traffic manipulation. I recommend citing it for its detailed explanations of attack methodologies and countermeasures.

---

# Annotations  
(11/5/2024, 2:38:56 PM)

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=6&annotation=KQ3UHQZU) “ECU Electronic control Unit FOTA Firmware updates Over The Air MOST Media Oriented System Transport CAN Control Area Network LIN Local Interconnect Network CSMA/CD Carrier Sense Multiple Access/ Collision Detection TDMA Time Division Multiple Access OBD OnBoard Diagnostics RSU Road Side Unit VANET Vehicle Addhoc Networks OBU OnBoard Unit PBL Primary Boot Loader SBL Secondary Boot Loader AUTOSAR Automotive Open System Architecture OEM Original Equipment Manufacturer PCM Powertrain control Module TCM Transmission Control Module BCM Body Control Module ABS Antilock Braking System ESC Electronic Stability Control HVAC Heating Ventilating and Cooling TCU Telematics Control Unit EBCM Electronic Brake Control Module TPM Trusted Platform Module FPGA Field Programmable Gate Array SoC System on Chip” ([Prathap and Rachumallu, 2013, p. 6](zotero://select/library/items/WNP9XBGM)) 

Abbreviations

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=8&annotation=P9CYCCBY) “It all started with invention of wheel where early humans can move heavy objects with ease. Then the invention of motors run by fuel giving birth to early cars. As the years passed the complexity of cars gets increased as the passenger comfort levels are also enhanced. In the last few decades automotive industry has seen a rapid increase of electronic components. Gradually other components such as brakes, steering etc. have started to use electronic components to increase efficiency. Today due to the excessive presence of electronic components and software in cars, security attacks directed towards automobiles are not in distant future.” ([Prathap and Rachumallu, 2013, p. 8](zotero://select/library/items/WNP9XBGM)) 

History

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=8&annotation=37TQKVZ6) “Koscher[1] has demonstrated various security attacks possible in an automobile. A modern automobile is said to have more lines of code than a jet aircraft. In the future, there might be communications between cars and road side units (RSU) through wireless or other protocols. Hence it would be possible to perform firmware updates, send and receive information about traffic and many other things. These new features will make the system more vulnerable to attacks from hackers. If they are targetted carefully, it can have devastating effect on safety of pasengers. Therefore security needs to be addressed in the automotive communication networks.” ([Prathap and Rachumallu, 2013, p. 8](zotero://select/library/items/WNP9XBGM)) 

Code, RSU

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=8&annotation=9859VY7A) “Inter vehicle communication is implemented using Vehicle ad hoc networks (VANETs). It shares information about the environment such as traffic, weather and road conditions between vehicles. It consists of On Board unit (OBU) which is located inside the vehicle and Road side unit (RSU). The In-vehicle network consist of electronic control units (ECU) which are interlinked by various bus system technologies like Controller Area Network (CAN), Local Interconnect Network (LIN), Flexray and Media Oriented Systems Transport (MOST).” ([Prathap and Rachumallu, 2013, p. 8](zotero://select/library/items/WNP9XBGM)) 

Inter vehicle, VANET, OBU, ECU, CAN, MOST, RSU, LIN, V2V

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=10&annotation=PSJYNK9Y) “The Controller Area Network (CAN) protocol is an event triggered bus system for serial communication with data rate of upto one megabit per second. It can operate even if some of the nodes are defective as it allows redundant networks through a multi-master architecture i.e even if one master node fails, another master node can takeover. The CAN messages are classified by their identifier. It does not have a specific recipient address. The CAN protocol transmits the message to the intended ECU by broadcasting i.e sending the message to all the ECUs and the intended ECU responds appropriately by looking at the message type.” ([Prathap and Rachumallu, 2013, p. 10](zotero://select/library/items/WNP9XBGM)) 

datarate

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=10&annotation=G8DPKZMF) “The CAN protocol uses CSMA/CD (Carrier Sense Multiple Access/ Collision Detection) access control method which is decentralized, reliable and priority driven. The CSMA/CD ensures that every time a top priority message is transmitted, it is always transmitted first. The CAN protocol offers an error mechanism that detects transfer errors, interrupts the erroneous transmissions with an error flag and initiates the retransmission of the affected message [2].” ([Prathap and Rachumallu, 2013, p. 10](zotero://select/library/items/WNP9XBGM)) 

CSMACD

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=11&annotation=2HWUVLC5) “The LIN (Local Interconnect Network) protocol is a single-wire sub network for lowcost, serial communication between smart sensors and actuators with typical data rates upto 20 kBit/s. It is used because it is much cheaper than other bus systems and also when the bandwidth and versatility of a CAN network is not required. It has single master, which controls the collision free communication with up to 16 slaves. Incorrect LIN messages are detected by using parity bits and checksums. LIN provides sleep mode operation to consume less power. This feature can be misused by attackers by sending malicious sleep frames which can completely deactivate the corresponding subnet until a wakeup frame is sent from a higher level CAN bus [2].” ([Prathap and Rachumallu, 2013, p. 11](zotero://select/library/items/WNP9XBGM)) 

LIN

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=11&annotation=7MHNPSNI) “The MOST (Media Oriented System Transport) protocol is a serial high speed bus typically used for developing automotive multimedia networks for transmitting audio, video, and control data. It uses fiber optic cables for transmission of data. The peer to peer network is connected by plug and play up to 64 nodes in ring, star or bus topology. It offers data rate of 24 MBit/s for synchronous transmission and 14 MBit/s for asynchronous transmission. In MOST messages, the sender and receiver addresses are always clearly mentioned. The access control for synchronous transmission is done by TDM (Time Division Multiplexing) and for asynchronous transmission is done by CSMA/CA. Since MOST device handles role of the timing master, malicious time frames disturb and interrupt the MOST synchronization mechanism. Continuous bogus channel requests reduce the remaining bandwidth and are a feasible jamming attack on MOST busses [2].” ([Prathap and Rachumallu, 2013, p. 11](zotero://select/library/items/WNP9XBGM)) 

MOST

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=11&annotation=PLVCTFJ2) “y The Flexray protocol is a deterministic and error-tolerant high speed bus, which is used for future safety related high speed automotive networks. It has a data rate of up to 10 MBits/s. The Flexray network is flexible and expandable and has upto 64 point to point connected nodes. Both optical fibers and copper lines are suitable for physical transmission medium. For priority driven control of asynchronous and synchronous transmission, Flexray uses cyclic TDMA (Time Division Multiple Access) method. The ways of error tolerance in Flexray are through channel redundancy, checksum and independent bus guardian that detect and handle logical errors. Fake errors messages can be created and directed at components to deactivate them using the bus guardian. It is also possible to completely deactivate the Flexray network when there is an attack on common time base [2].” ([Prathap and Rachumallu, 2013, p. 11](zotero://select/library/items/WNP9XBGM)) 

Flexray

![](2K7ENWDI.png)  
>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=12&annotation=2K7ENWDI)  
([Prathap and Rachumallu, 2013, p. 12](zotero://select/library/items/WNP9XBGM)) 

BusProperties

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=15&annotation=HN82JGVN) “The threats faced by any embedded systems are of two levels: Top level attacks and bottom level attacks. The top level attacks are classified into three main categories based on their function objectives.  Privacy attacks: These attacks are performed to gain access to sensitive information stored or communicated within an embedded system.  Integrity attacks: The data or code associated with the embedded system is changed in these attacks.  Availability attacks: By misappropriating system resources, normal functioning of the system is disrupted. It causes the system to be unavailable for normal operation. These are the top level attacks in an embedded system. The second level of attacks is based on agents or means used to launch the attacks [16]. These attacks are software attacks, physical or intrusive attacks and side channel attacks. These attacks are explained in detail in the subsequent paragraphs. The classification of attacks on embedded systems is shown in the figure below.” ([Prathap and Rachumallu, 2013, p. 15](zotero://select/library/items/WNP9XBGM)) 

top level, CIA

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=16&annotation=8GEHA5XQ) “Physical or intrusive attack is to damage or gain the knowledge of working of embedded system device by physical tampering. Ravi et al [16] has provided some steps for performing physical attacks. They are listed below  The first step is De-packing, that is to remove the chip of package by dissolving the resin covering silicon using fuming acid.  The second step is reconstructing layout using a systematic combination of microscopy and invasive removal of covering layouts.  The third step is to use techniques such as manual microprobing or ebeam microscopy to observe the values on the busses and interfaces of the components in a depackaged chip. Physical attacks on chip requires expensive infrastructure and hence it is hard to use. However once they are performed, they are used as precursors to the design of successful noninvasive attacks. Some examples are, layout reconstruction is done before performing electromagnetic radiation monitoring. Similarly the knowledge of ROM contents which includes cryptographic routines and control data that can provide information that can help in the design of non-invasive attack to an attacker.” ([Prathap and Rachumallu, 2013, p. 16](zotero://select/library/items/WNP9XBGM)) 

physical, intrusive

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=17&annotation=QWYWKZ5I) “channel attacks A side channel attack is any attack based on the information gained from the physical implementation of a system. Various side channel attacks are Power analysis, Timing attacks and electromagnetic analysis. The power analysis attack monitors the power consumption by the system. As power consumption is data dependent, the key used can be inferred from this attack [16]. Timing attacks exploit the observation that the execution times of cryptographic computations are data dependent and hence can be used to infer the cryptographic key [19]. The Electromagnetic analysis attack measures the electromagnetic radiation emitted by the device to reveal sensitive information. It was shown that using electromagnetic analysis the screen contents of a video display unit can be reconstructed [20].” ([Prathap and Rachumallu, 2013, p. 17](zotero://select/library/items/WNP9XBGM)) 

Side Channel

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=17&annotation=CKGKEVGD) “Reverse engineering attack understands the inner structure of device and learns to emulate its functionality. An attacker who performs is able to reverse engineer the device, gets similar capabilities of a device manufacturer. Reverse engineering is an invasive attack, hence it may not be possible to reuse the same device after trying to reverse engineer. Dr. Sergei [18] describes the possible approaches in performing this attack.” ([Prathap and Rachumallu, 2013, p. 17](zotero://select/library/items/WNP9XBGM))

Reverse Engineering

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=18&annotation=B6JW29KI) “The functionality of each component in the automobile is controlled by an ECU with specific firmware. Gradually other mechanical components are replaced with electronic components controlled by software. The value of electronic components in cars will be 40 percent of its total value by 2015 [3]. With the ever increasing number of ECUs, various third party software for the electronic components have emerged. Hence the need for authentication of ECUs and protecting its integrity is very vital in the present automobile industry.” ([Prathap and Rachumallu, 2013, p. 18](zotero://select/library/items/WNP9XBGM)) 

ECU

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=19&annotation=3WVTZUID) “A modern ECU might have a 32 bit 40 MHz processor and the code in ECU might take upto 2MB. A typical desktop computer has a processor which runs at 1000 to 2000 MHz of speed and with atleast 2 GB of memory. This shows that the individual ECU has less computing power in comparison to a desktop computer. The processor takes up input from the sensors, and sends appropriate signals to the actuators by analyzing the input and the data from the memory of ECU.” ([Prathap and Rachumallu, 2013, p. 19](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=19&annotation=FUWM54BX) “The memory stores the code of ECU which defines its complete behavior. A typical ECU consists of two kinds of memory. They are flash memory and RAM memory. The flash memory does not lose the data stored in it, when the power is switched off. Hence it is a non-volatile memory. It cannot be overwritten as it has a primary boot loader but other parts of the memory can be erased and reprogrammed.” ([Prathap and Rachumallu, 2013, p. 19](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=21&annotation=XJ6JR544) “The current requirements in the automotive industry has risen to a great extent such that new technological breakthrough is required to fulfill customers and legal requirements. In Order to address this, various OEM manufacturers and tier 1 suppliers have collaborated and formed the Automotive Open System Architecture (AUTOSAR). It is an open and standardized software architecture developed jointly by automobile manufacturers, suppliers and tool developers. The goals of AUTOSAR are  Standardization of basic software functionality of automotive ECUs.  Scalability to different vehicle and platform variants.  Transferability of software.  Support of different functional domains.  Definition of an open architecture.  Collaboration between various partners.  Development of highly dependable systems.  Sustainable utilization of natural resources.  Support of applicable automotive international standards and state-of-the-art technologies. To achieve the given technical goals of AUTOSAR such as modularity, scalability, transferability and re-usability of functions, AUTOSAR provides a common software infrastructure based on standardized interfaces. AUTOSAR enables configuration process optimization and wherever necessary to allow local optimization to meet runtime requirements.” ([Prathap and Rachumallu, 2013, p. 21](zotero://select/library/items/WNP9XBGM)) 

AUTOSAR

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=21&annotation=UE66BKT4) “The ECU has challenge response protocol to authenticate communication between the user and the ECU. Since by rule no encryption algorithm can reside in an ECU, both the challenge and its response are in the memory of the ECU [1]. Firstly a user asks for a seed from the ECU. The ECU responds with a seed to the user where he computes the key with a seed to key algorithm and sends it back to the ECU where the calculated key is checked [23]. If this stage is successfully passed, the ECU is open for modifications. The challenge response protocol is shown in the figure below.” ([Prathap and Rachumallu, 2013, p. 21](zotero://select/library/items/WNP9XBGM)) 

Enryption

![](JGTJIHZN.png)  
>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=21&annotation=JGTJIHZN)  
([Prathap and Rachumallu, 2013, p. 21](zotero://select/library/items/WNP9XBGM)) 

Seed

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=21&annotation=HVSSQPMR) “It is also known that the software in ECU has the signature of the manufacturer to authenticate itself. In general, the software image is hased and decrypted with manufacturer’s private key to form signature. This is then authenticated by the device using its public key to encrypt the signature and check if the encrypted signature and hash of software image are the same.” ([Prathap and Rachumallu, 2013, p. 21](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=22&annotation=IZKKXGYK) “The software in ECUs should be frequently updated with latest versions to enhance the performance of the vehicle. Usually these software updates are performed through OnBoard Diagnostic (OBD) protocol. The software updates are performed using any software tool for communicating with ECU installed in a laptop which is connected through OBD cable. The current research activities in vehicular on board IT architectures follows two basic trends. They are unification of network communication and centralization of functionality. Hence in future it is possible to perform software updates on ECUs through wireless.” ([Prathap and Rachumallu, 2013, p. 22](zotero://select/library/items/WNP9XBGM)) 

FOTA, OBD

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=22&annotation=7BA97VJ6) “A pictorial representation of FOTA is given in figure 10. The automobile gets the updates from Original Equipment Manufacturer (OEM) through the service station via internet. The service station sends the update to the wireless gateway in the automobile which communicates with the various ECUs and the appropriate software is loaded in it. There exist technical and practical difficulties in implementing FOTA. Due to the transfer of data over the air, FOTA opens to possible cyber-attacks on the automobiles. Idrees et al [11] suggests a protocol for securing firmware updates by hardware and software modules. These modules provide various security mechanisms like encryption, decryption, signing etc. Nilsson et al [5] suggests a protocol which involves using hashing chains.” ([Prathap and Rachumallu, 2013, p. 22](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=23&annotation=RMV2V2PU) “The powertrain consists of critical components such as engine and transmission controls. There are three computers in powertrain such as Powertrain control module (PCM) which acts as a brain of the whole automobile, Transmission Control Module (TCM) which controls modern electronic transmission of messages between various ECUs and Body control Module (BCM) responsible for monitoring and controlling various electronic accessories. When a fault occurs in PCM, the check engine light on the dashboard will appear. Failure of powertrain ECUs can cause critical damage as these ECUs are responsible for working of critical functions such as acceleration, braking etc.” ([Prathap and Rachumallu, 2013, p. 23](zotero://select/library/items/WNP9XBGM)) 

Powertrain

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=23&annotation=VXU7VVUS) “With significant advances in technology, it is now possible to prevent accidents and to minimize the damage in case of unavoidable accidents. Various devices or features which comes under active safety are Anti-Lock Braking system (ABS), Electronic stability control (ESC), Brake assists etc. The ABS is used to prevent locking of wheels when the driver hits the brake hard at slippery conditions. The ESC is used to control the vehicle in case of a blind turn, a driver might do an oversteer or an understeer. ESC negates the driver error and prevents the vehicle from lopsiding.” ([Prathap and Rachumallu, 2013, p. 23](zotero://select/library/items/WNP9XBGM)) 

ABS, ESC

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=24&annotation=5J9F6QCI) “Passenger comfort systems consist of Automatic climate control which controls heating, ventilating and cooling (HVAC) systems in the car. Automatic windshield wipers are used to keep the windshield clean from rain water, snow, fog and dust. The Automatic headlight alters the lighting of head lamps according to driving situations and curves in the road. A breakdown in these ECUs is not as critical compared to the powertrain and vehicle safety ECUs.” ([Prathap and Rachumallu, 2013, p. 24](zotero://select/library/items/WNP9XBGM)) 

HVAC

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=24&annotation=GTV2IR8N) “The Infotainment systems are gaining more popularity in the cars and provide a myriad of services which includes navigation system which provides turn-by-turn directions by using GPS or electronic maps through display and voice interfaces. Entertainment systems such as AM/FM radio, CD/DVD players, TV, surround sound, game consoles and controls for, headlights, air conditioning, wipers etc. Bluetooth streaming that allows Bluetooth enabled phone or a device to connect with vehicle and one can control functions like checking text messages, answering calls, music from phone etc., with a smart display screen in dashboard or LCD display depending on car variant. According to a survey from a market researcher, every new car built in Europe will have internet connection by 2013 [6]. A failure in these ECUs is not considered as a violation of safety issues.” ([Prathap and Rachumallu, 2013, p. 24](zotero://select/library/items/WNP9XBGM)) 

Infotainment

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=24&annotation=DUMT6FLZ) “The telematics system provides an interface between the user and the mechanical or electrical components. The Telematics Control Unit (TCU) is a small computer about the size and weight of a paperback book, that communicates with automobile ECUs and GPS satellites and accesses telematics services such as Automatic crash notification, vehicle tracking, remote door services, traffic assistance, diagnostics and much more. The telematics unit gets the information about the ECUs from the CAN network and stores them. However for this information to be useful, it should be possible to communicate with external environment.” ([Prathap and Rachumallu, 2013, p. 24](zotero://select/library/items/WNP9XBGM)) 

TCU, Telematics, GPS

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=25&annotation=48PIIAI3) “In this section we give a brief description of penetration testing. Penetration tests are necessary to detect vulnerabilities in system or network, and the knowledge of past and present vulnerabilities of the system is essential for securing it. Although temporary patches to the equipment provide security, penetration tests are useful to detect various vulnerabilities which are present in the system.” ([Prathap and Rachumallu, 2013, p. 25](zotero://select/library/items/WNP9XBGM)) 

Pentesting

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=25&annotation=GJ2RN6HU) “Penetration testing is an accepted procedure that is performed to find vulnerabilities in hosts, networks and application resources using known attacks. Penetration testing also known as Pen test, is a method which is used to check if the existing and new applications, networks and systems are vulnerable to a security risk that could allow unauthorized users to access resources. A penetration test usually includes the use of attacking methods conducted by trusted individuals. The tests can range from a simple scan to identify IP addresses of systems to identify vulnerabilities or exploiting known vulnerabilities. The results of the tests and attacks are documented and presented to the owner of a system in order to address the identified vulnerabilities [34]. One must keep in mind that penetration testing is not a fully security audit, rather it gives security at a single moment in time. Penetration tests are performed in order to secure sensitive information and resources from hackers or unauthorized individuals. For example, a company asset might be compromised if vulnerabilities in the system are exploited by unauthorized persons. Penetration testing is either used to create awareness of security issues among higher management or to test intrusion detection and calculate responses. The aim of penetration testing is to identify vulnerabilities before being exploited.” ([Prathap and Rachumallu, 2013, p. 25](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=25&annotation=ESPDM3U2) “An external test is a traditional approach that lets a remote attacker to attack the network from outside. The attacker targets Internet connected systems that are connected to internal networks to find potential weaknesses. For example, by opening services on internal servers or gaining access to network devices (routers, firewalls). The attacker gathers required knowledge about internal systems and network from various resources to perform such an attack. Internal tests are attacks that are performed by a person who has an authorized access to the internal network or through social engineering. Internal tests are intended to identify the vulnerabilities that exist for systems that are accessible to authorized network connections that reside within internal perimeter. Inside attackers are more dangerous than external attackers because insiders already have necessary information about the network to exploit it, whereas external attackers do not have it in their initial stage.” ([Prathap and Rachumallu, 2013, p. 25](zotero://select/library/items/WNP9XBGM)) 

internal, external

![](4RWUNPIA.png)  
>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=26&annotation=4RWUNPIA)  
([Prathap and Rachumallu, 2013, p. 26](zotero://select/library/items/WNP9XBGM)) 

Pentesting Process

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=26&annotation=ZIX46AQ6) “Planning: In the planning phase, the objectives of penetration testing is determined, rules are established, the resources that need to be tested and staff who are identified. The foundation work is done in this phase to achieve for successful penetration testing [35]. No actual test is done in this phase.” ([Prathap and Rachumallu, 2013, p. 26](zotero://select/library/items/WNP9XBGM)) 

Planning

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=26&annotation=AKQR7KSG) “Discovery: The discovery phase consists of two parts;  Information gathering and analysis: After finishing the planning phase, the next step is to gather as much information as possible about the targeted system using various tools. The actual testing is started in this phase.  Vulnerability detection: The information gathered from the previous step is used to determine the existing vulnerabilities in the targeted systems. The vulnerabilities found are compared with a vulnerability database to see if we already have a countermeasure for the attack. The collection of exploits and vulnerabilities found are important to perform successful penetration testing [34].” ([Prathap and Rachumallu, 2013, p. 26](zotero://select/library/items/WNP9XBGM)) 

Discovery

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=26&annotation=KSI2DJIF) “Attack: This is the important phase of penetration testing. The vulnerabilities that are identified in the previous step are used in this phase when trying to exploit the system. If an attack is successful, then it is verified and measures are proposed to mitigate the risks. If testers are able to exploit the vulnerability successfully on the target system, they can install more tools on target system to gain access to additional systems or resources on the network. These attacks have to be conducted on multiple systems in order to determine the level of access that an attacker can gain. The following figure shows the individual steps of this phase [35].” ([Prathap and Rachumallu, 2013, p. 26](zotero://select/library/items/WNP9XBGM)) 

Attack

![](WN4VX98B.png)  
>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=27&annotation=WN4VX98B)  
([Prathap and Rachumallu, 2013, p. 27](zotero://select/library/items/WNP9XBGM)) 

Attack phase

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=27&annotation=8XSA2U2C) “Reporting: The reporting phase is done together with the other three phases. It is important to generate a comprehensive report that includes details of how penetration testing is done, collections of vulnerabilities that are found during the tests and approaches to resolve those vulnerabilities. This report can be used to analyze how an adversary can exploit weaknesses and will also give guidance how to mitigate the discovered attacks in the system or network.” ([Prathap and Rachumallu, 2013, p. 27](zotero://select/library/items/WNP9XBGM)) 

Reporting

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=27&annotation=LV6C46RU) “Cleaning Up: This cleaning up process is done to clean the mess that has been made as a result of penetration test. E.g. removing user accounts that are created during the process of penetration tests.” ([Prathap and Rachumallu, 2013, p. 27](zotero://select/library/items/WNP9XBGM)) Cleaning

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=28&annotation=9CWVNSIV) “The different goals of penetration test include [36]:  Access to internal resources  Reading and modifying restricted files  Reading and executing transaction data  Controlling network management systems  Access to any user accounts  Access to supervisor privileges  Demonstrating ability to control resources. It is essential to have well defined success criteria, as a failure to properly defined conditions will result in and misconceptions that could lead to a false sense of security.” ([Prathap and Rachumallu, 2013, p. 28](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=28&annotation=H6TFW7BB) “Zero knowledge: In this approach the test team will not have any information about target system. So the test team should start gathering information to proceed further in performing penetration testing. This test provides most realistic penetration test.  Partial Knowledge: In this approach the test team is provided with information from target organization to perform tests. This type of test is chosen when target organization wants to test on specific attack or to test on specific targeted network or host.  Full Knowledge: In this approach the test team has as much information about the target system as possible. This test is used to simulate an attacker who has familiar knowledge of target organization’s systems like a current employee.” ([Prathap and Rachumallu, 2013, p. 28](zotero://select/library/items/WNP9XBGM)) 

White Box, Grey Box, Black Box

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=28&annotation=KSJ44CAF) “Penetration testing is just a snapshot of the targeted systems and network at a moment. There are severe restrictions on penetration testing especially on time and cost issues. It is not intended to be a complete evaluation of security, since the targeted organization may add or change functionalities in the targeted system or network for business purposes, so many security attacks and configuration issues may not be identified during tests. The amount of data that is collected during the given time period is an important element to evaluate the validity of a penetration testing [33] [36].” ([Prathap and Rachumallu, 2013, p. 28](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=29&annotation=J2JK5BTY) “Reverse engineering is the process of discovering the technological principles of a device, object or a system through analysis of its structure, function and operations [22]. In this context, it involves taking a device or software and analyse the working of each components in it. Reverse engineering gives way to pirate software and cloned parts which could have big economic impact on the automobile company. Since the software in ECU is not encrypted due to memory constraints, It can be easily read by using appropriate software. The software loaded in the ECU has an image inorder to detect any changes in the software. Even though we cannot change the software, we can copy both the software and its image into a new ECU [21]. An attacker having physical access to an ECU can disassemble its parts and study the working of each and every components.” ([Prathap and Rachumallu, 2013, p. 29](zotero://select/library/items/WNP9XBGM)) 

Reverse Engineering

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=30&annotation=EJ7KYGQG) “An ECU memory consists of important data which are required for the functioning of automobile components. The memory capacity of an ECU is usually very low and the software in ECU is written in unsafe programming language like C, Hence it is possible to perform buffer overflow attacks on ECUs [24]. A malicious user can inject unexpected error into the memory by power shutdown, injecting wrong values etc. These failures might cause corruption of data stored in the memory and hence disturb the integrity of the data [21]. The memory of an ECU is also subjected to offline attacks. We can disassemble the ECU and takeaway the memory chip using anti-static mat and a soldering iron and using an EEPROM reader we can get the complete software image. Now to make sense of the software image, we need to use a disassembler. Hence contents of the memory can be easily read out and it is not secure [25].” ([Prathap and Rachumallu, 2013, p. 30](zotero://select/library/items/WNP9XBGM)) 

Attacking memory

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=30&annotation=TY22F7SN) “The ECUs in an automobile communicate with each other by using protocols such as CAN, LIN, MOST or Flexray. Wolf et al [2] has pointed out the various security loopholes in these protocols. The ECUs in these protocols are connected through gateway ECUs. The gateway is the most safety critical ECU in the in-vehicle network as attacks such as drop, flood, modify, read, replay and spoof can be performed [26]. Communication with ECUs can be either internal or external. If ECUs communicate within the in-vehicle network then its internal communication whereas if communication is done outside of in-vehicle networks its external communication. Koscher et al [1][27] has explained and performed experiments showing inadequate security in both internal and external communication.” ([Prathap and Rachumallu, 2013, p. 30](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=35&annotation=YN7DUTFQ) “The communication between ECUs must be secured both internal threats from the invehicle network and external threats from outside the in-vehicle network. Many approaches for securing the communication protocols are suggested. Wolf et al [2] has given ways through which authentication and encryption of messages be performed so that only the intended recipient can have access to the message. He also says about the usage of gateway firewalls for a complete vehicular bus communication security. Larson et al [26] discusses about an approach towards specification based attack detection, which involves having a detector for every ECU and sends appropriate signal if a particular attack occurs.” ([Prathap and Rachumallu, 2013, p. 35](zotero://select/library/items/WNP9XBGM))

>[Go to annotation](zotero://open-pdf/library/items/2LPZDSEN?page=36&annotation=8BIKG4LC) “With rapid strides in developing firmware update over the air (FOTA), it is possible to perform software attacks on ECUs in a car from a remote location. Hence it is vital to look at the possible vulnerabilities and insecurities of the system before sophisticated protocols and connections such as FOTA are introduced in the automobile environment. The given countermeasures must be carefully studied and implemented keeping in mind the memory constraints and processing capability of the ECU.” ([Prathap and Rachumallu, 2013, p. 36](zotero://select/library/items/WNP9XBGM))