---
title: Attack Data Generation Framework for Autonomous Vehicle Sensors
authors: Jan Lauinger, Andreas Finkenzeller, Henrik Lautebach, Mohammad Hamad, Sebastian Steinhorst
year: 2022
---

# Attack Data Generation Framework for Autonomous Vehicle Sensors
##### Jan Lauinger, Andreas Finkenzeller, Henrik Lautebach, Mohammad Hamad, Sebastian Steinhorst (2022)
[Zotero-Link](zotero://select/items/@lauingerAttackDataGeneration2022)

Tags: #AttackFramework #Sensors #GNSS #Camera #Blacking #IDS #Pentesting 

>[!ABSTRACT]-
>Driving scenarios of autonomous vehicles combine many data sources with new networking requirements in highly dynamic system setups. To keep security mechanisms applicable to new application fields in the automotive domain, our work introduces a security framework to generate, attack, and validate realistic data sets at rest and in transit. Concerning realistic data sets, our framework leverages autonomous driving simulators as well as static data sets of vehicle sensors. A configurable networking setup enables flexible data encapsulation to perform and validate networking attacks on data in transit. We validate our results with intrusion detection algorithms and simulation environments. Generated data sets and configurations are reproducible, portable, storable, and support iterative security testing of scenarios.


---

# Summary

- The paper introduces a **modular attack data generation framework** designed for autonomous vehicle (AV) sensors. It focuses on creating realistic attack data for AV testing, using both **real and simulated** sensor data from sources such as CARLA and other driving simulators.
- The framework supports a variety of attacks, including **data injection, modification, and removal**, and validates the effects using Intrusion Detection Systems (IDS) and statistical models. It offers a **scenario-based configuration setup**, enabling reproducibility and flexibility in security tests.
- The researchers present multiple **use cases**, such as GNSS offset attacks, DoS attacks, and image tampering, to demonstrate the framework's capabilities.

# Relevancy

- **Focuses on Simulation and Testing**: The use of CARLA and other simulation environments aligns with your objective of manipulating CAN traffic and testing AV vulnerabilities in controlled environments.
- **Explores Multiple Attack Types**: The framework's approach to generating various attack scenarios, such as data injection and DoS, provides methodologies directly applicable to your experiments involving CAN traffic manipulation.
- **Emphasizes Validation Techniques**: The integration of IDS and statistical models for validating attacks offers insights into structuring your own validation methods in simulations.

# Notable Sections and Pages

- **Section II: System Model (Pages 2-4)**: Describes the framework's modular architecture and the use of simulators like CARLA for generating realistic sensor data. This section provides foundational knowledge for building your simulation environment.
- **Section III: Attack Generation (Pages 5-7)**: Explains the configuration of attacks (e.g., injection, modification) and their application to different sensors. This section is essential for understanding how to set up and execute similar attacks in your thesis.
- **Section IV: Use Cases and Evaluation (Pages 8-10)**: Details specific attack scenarios (e.g., GNSS offset, DoS) and their evaluation using CARLA. This is valuable for planning your own experiments and validating the results of CAN traffic manipulation.

# Recommendations

This paper is an excellent source for your thesis as it offers a structured approach to generating and validating attack data for AV systems. I recommend citing it for its detailed explanation of attack configurations, validation methods, and use of simulation environments like CARLA.

---

# Annotations  
(11/1/2024, 6:06:52 PM)

![](QL56FJMG.png)  
>[Go to annotation](zotero://open-pdf/library/items/UBFA6HI5?page=1&annotation=QL56FJMG)  
([Lauinger et al., 2022, p. 1](zotero://select/library/items/7MGCFAR4)) 

Attack Framework

>[Go to annotation](zotero://open-pdf/library/items/UBFA6HI5?page=3&annotation=WF4IP6KT) “Description: To attack sensors, our framework allows configurations that inject, modify, or remove specific data items which reflect value ranges of sensors under attack. Timestamps augment data items and replace removed data samples for labeling purposes. In order to detect attacks, simulation scenarios are executed twice using comparable ground truth paths. Evaluation: To evaluate an exemplary sensor attack, Fig. 3a shows how a constant GNSS offset modification affects the location of the vehicle. The figure shows consecutive longitude and latitude values in periodic intervals. Longitude and latitude value pairs refer to a fix point location in the simulation environment and do not relate to real-world locations. The outcome of the sensor attack causes the vehicle to leave its scheduled path. Thereby, alternating GNSS offset values show the location deviation inside the simulator environment. As a direct consequence, sensor values attached to the simulated vehicle are affected as well (e.g. camera direction changes).” ([Lauinger et al., 2022, p. 3](zotero://select/library/items/7MGCFAR4)) 

Sensors, GNSS, CAmera

>[Go to annotation](zotero://open-pdf/library/items/UBFA6HI5?page=3&annotation=ARX2MAWR) “Description: As already outlined and to model networking traffic and access all networking layers of packets, our framework supports container-driven virtual networking configurations, where further communication protocols will be added in the future. Taking the networking scenario type, one sample use case is to produce a camera image stream between a sending and receiving container. We configure an attacking container to perform a DoS attack targeting the receiver node. From the receiver side, we use Wireshark as the network analyser tool to access network traffic of the scenario. Fig. 3b shows the data collection of the receiver. Here, the increasing number of detection intervals measures the number of received packets. Evaluation: To detect and validate networking attacks, our framework supports a ring-buffer memory capturing of packets and compares traffic distributions between different time frames. The attack is scheduled to occur at round 4. As visualized in Fig. 3b, the number of packets increases to 197 packets. Our ring-buffer traffic analysis at the receiver side triggers a detection after 0.238 ms, when using a pre-defined threshold value of 128 packets.” ([Lauinger et al., 2022, p. 3](zotero://select/library/items/7MGCFAR4)) 

DoS

>[Go to annotation](zotero://open-pdf/library/items/UBFA6HI5?page=3&annotation=LUSH6B4T) “Description: To showcase an attack on static real-world data sets, we perform two types of image tampering attacks, namely image blacking and blurring. To apply these attacks, users are required to configure a percentage of an image array that should be modified. To validate image tampering and expecting an constant input stream of images, we reproduced the real-time image tampering detection algorithm from [6]. This algorithm depends on a Linear Discriminant Analysis (LDA) for threshold determination. Autonomous vehicles typically scan environments before their deployment [7]. This allows data-driven parameter tuning of the image tampering detection threshold which, when set up, predicts new incoming images automatically. Evaluation: To evaluate a blurring attack on a static data set, we considered the training data set 1 of [3], specifically, the data of the centered front camera. After generating two new data sets using the image blacking and image blurring attacks, training of the short LDA-based threshold provided training parameters as shown in row 1 of Tab. I. Using the trained LDA threshold Tab. I: Image tampering LDA parameters; Accuracy, True Positives (TP), False Positives (FP), True Negatives (TN), and False Negatives (FN) Attack Test Phase Accuracy TP FP TN FN Blurred Training 95.45 % 18 0 1 3 Blurred Prediction 95.45 % 51 0 3 12 Blacked Prediction 92.42 % 51 0 5 10 model, Fig. 3c shows real-time image tampering detection after injecting 2 malicious images into the blurred image attack data set. Accuracy results of LDA parameters can be found in row 2 of Tab. I. Detection accuracy decreased slightly to 92.42% in the case of blacked images, as indicated by row 3. Besides the model parameters, Fig. 3c shows the short-term long-term buffer algorithm which compares different image metrics. Here, chromaticity histogram comparison performs a color analysis, the L1R score compares brightness, and gradients compare edges in images. Further information about these metrics can be found in the work [6]. Every line of the chart represents the differences between short-term and long-term buffer values of the described metrics. An attacked image causes the difference to increase above the threshold which allows detection. Every new image that is passed to the algorithm counts as a new frame for comparison, allowing real-time detection of image tampering. The ground truth value is a reference to the detection line which indicates a successful detection after the occurrence of two malicious frames.” ([Lauinger et al., 2022, p. 3](zotero://select/library/items/7MGCFAR4)) 

Blacking, blurring
