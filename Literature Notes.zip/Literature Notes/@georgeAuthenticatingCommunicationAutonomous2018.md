---
title: Authenticating Communication of Autonomous Vehicles With Artificial Intelligence
authors: Neetha George, Jeena Thomas
year: 2018
---

# Authenticating Communication of Autonomous Vehicles With Artificial Intelligence
##### Neetha George, Jeena Thomas (2018)
[Zotero-Link](zotero://select/items/@georgeAuthenticatingCommunicationAutonomous2018)

Tags: #VANET #AttackSurfaces #Vulnerabilities #SafetySecurity #RSU #OBU #DSRC #RADAR #LiDAR #Authentication #PKI #CIA #FastAuthentication #OTS #CHT #SelectiveAuthentication #CABV #Beacons

>[!ABSTRACT]-
>Autonomous vehicles in Vehicular Ad-hoc Networks(VANET)-the spontaneous creation of a wireless network for data exchange to the domain of vehicles may pave the way for future systems where computers take over the art of driving. It aids in transferring secure messages for proper communication between the vehicles. Unauthorized access like injecting spoofed messages to VANET can arise as an extreme threat. So remedies should be taken at early degree of architectonic process.Denial-of Service(DoS) attack takes place while validating each message in VANET ,so an equity between message authentication and DoS prevention should be maintained.This paper discusses on diverse security demanding situations and distinct techniques to secure message transfer between the vehicles that are connected wirelessly.


---

# Summary

- The paper discusses the security challenges in Vehicular Ad-hoc Networks (VANETs) and proposes the use of **Artificial Intelligence (AI)** for authenticating communications between autonomous vehicles. It addresses attacks such as **message spoofing**, **denial-of-service (DoS)**, and **signature flooding**.
- The authors explore **Digital Signatures**, **Fast Authentication (FastAuth)**, and **Selective Authentication (SelAuth)** as methods to enhance the security and efficiency of message validation in VANETs.
- AI is integrated to improve decision-making and positioning for vehicles, employing techniques like **Kalman filters** and **particle filters** to reduce computational overhead and authenticate messages based on vehicle behavior and location.

# Relevancy

- **Covers Authentication Techniques**: Discusses methods for securing communication in vehicle networks, which is valuable for understanding how to protect CAN traffic from spoofing and other attacks.
- **Explores AI for Positioning and Security**: The integration of AI to validate and authenticate messages based on context and vehicle behavior aligns well with your aim of exploring advanced methods to secure and manipulate CAN traffic in simulation environments like CARLA.
- **Focuses on Remote and Sensor-Based Attacks**: Provides insights into preventing remote attacks using message verification and location tracking, which could be applied when simulating CAN traffic attacks in CARLA.

# Notable Sections and Pages

- **Section 2.2: Security Attacks in VANET (Pages 2-3)**: Details various attack vectors in VANET, including spoofing and DoS attacks, which are directly relevant to understanding threats to CAN traffic.
- **Section 3.1: Authentication with Digital Signatures (Pages 3-4)**: Explains the use of digital signatures for securing VANET communications. This section provides a theoretical background for implementing similar security methods in your simulated environment.
- **Section 4: Securing Autonomous Vehicles With Artificial Intelligence (Pages 5-6)**: Describes the integration of AI for message authentication and positioning, offering ideas for incorporating AI techniques in your experiments to secure or manipulate CAN traffic.

# Recommendations

This paper is a useful addition to your thesis as it provides a blend of AI-based authentication mechanisms and traditional methods like digital signatures for securing vehicular networks. Citing this work can support your discussion on securing and authenticating CAN traffic, especially in the context of remote attacks.

---

# Annotations  
(10/29/2024, 12:57:35 PM)

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=1&annotation=4FY7JD26) “The Internet of Things (IOT)[1][2],is one of the most flourishing technology which makes vehicles connected each other. It connects devices, machines and tools to the internet by means of wireless technologies. VANET[3][4] is a type of network in which the interaction of vehicles occur by exchanging messages between them. The safe exchange of messages can lead to collision avoidance, traffic congestion control, thus ensuring the driver a smooth driving experience. But there can be also many attacks faced by VANET[5] like monitoring attacks, social attacks, timing attacks, application attacks, and network attacks. So the connected vehicles should be secured properly. There are several existing methods for securing them.” ([George and Thomas, 2018, p. 1](zotero://select/library/items/U58BNF8G)) 

VANET, Attack Surface, Vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=1&annotation=R6WTWP5Q) “One of the major issues is security; very little attention has been dedicated untill now to the safety of vehicles in the network. Probably, the size of the network, the speed of the vehicles, the relevance of their geographic location, the very intermittent interconnection, and the inevitable gradual distribution of effective resources shape the threat very peculiar and challenging.” ([George and Thomas, 2018, p. 1](zotero://select/library/items/U58BNF8G)) 

Safety and Security

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=2&annotation=HF2LU6Y2) “Vehicles are connected to each other wirelessly with Vehicular Ad-hoc Network (VANET)[5], an advanced technology that takes moving cars as communication nodes to form a instinctive network. Routers, deliberately placed along the road, insure constant coverage for vehicular communications. VANET. Vehicles communicate to each other with On-Board Units(OBU) rigged on vehicles. Road-Side Units (RSU) expand communications with both geographical inclusion and tremendous speed of data. Dedicated Short-Range Communication (DSRC)[6][7] - a two way wireless communication that is short- to- medium-range ensures enormous transmission of data crucial in communications-based valid security functions is entrusted for VANETs. Vehicles also work with OBUs armed with sensors, such as RAdio Detection And Ranging (RADAR) and LIght Detection And Ranging (LIDAR), to avoid collisions.” ([George and Thomas, 2018, p. 2](zotero://select/library/items/U58BNF8G)) 

RSU, OBU, DSRC, RADAR, LIDAR

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=2&annotation=CEPJ32L2) “A Road-Side Unit (RSU)[10][11] works as a static OBU powered by more computing properties and have frequent wired connection to the Internet that is considered to be the backbone. RSUs are usually installed at each 100-200 meters across a road to provide networking infrastructure for enhanced performance and enforced security in transmitting messages in vehicular network.Figure 1 illustrates various components of an On-Board Unit.” ([George and Thomas, 2018, p. 2](zotero://select/library/items/U58BNF8G)) 

RSU

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=2&annotation=DAA792RE) “VANET security has evolved to be a major concern in the society. All the current stations should be authenticated before they contact the available services in the network. The attack enlists the process of identification which represents the whole network to serious aftereffects. In a Vehicular network the authentication safeguards to protect the secured nodes from the outside or inside attackers who tricks the network using a fake identification.The securing scheme process will take place whenever a vehicle tends to link to the network or any service.” ([George and Thomas, 2018, p. 2](zotero://select/library/items/U58BNF8G)) 

Authenticaiton

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=3&annotation=DTQ9D3U4) “Authentication with Digital Signatures[13][14] is one the excellent techniques for securing the VANET messages since they sign each of the messages before passing them to the acceptor side.It uses a Public key Infrastructure(PKI) to provide security due to huge number of individuals in the network.Each of the vehicle in the network will be contributed with a pair of public/private key.A private key signs the message before it is transferred and includes Certification Authority(CA)certificate.A tamper-proof device along with private keys is necessary in each vehicle where the confidential messages are tracked and out-gone data are signed. Little time later, the sender simulcasts the key and instructs all that this revealed key is not to be used in the future. Receivers cache the actual message until the key is received and then verify the signature.Symmetric cryptographic primitives are used by this verification.Digital signature working is shown in figure 2” ([George and Thomas, 2018, p. 3](zotero://select/library/items/U58BNF8G)) 

PKI, CA

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=4&annotation=P6XXAPPA) “FastAuth,is an adequate One-Time Signature(OTS) scheme to secure beacon messages. The innovation in FastAuth[15] is the layout of a sequential Huffman Hash Tree (CHT),which provides the predictability in vehicle mobility to generate small signatures. Every beacon has to be checked when they are received because the beacon may contain definitive and crucial safety information. The recent VANET signature standard is computationally costly, but traditional OTS provides instant verification with increased communication overhead.Inspired by this exclusive challenge,the target of FastAuth is to gain fast authentication with short signatures.” ([George and Thomas, 2018, p. 4](zotero://select/library/items/U58BNF8G)) 

Fast Authentication, OTS, CHT

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=4&annotation=26R4XKIE) “To overcome the challenge for creating a decisive verification scheme for multi-hop applications, SelAuth[15], a signature verification protocol which can quickly block the escalation of invalid signatures without verifying all receiving signatures at every hop can be effectively used. In particular, SelAuth uses neighbor identification to avoid enactment and per neighbor verification probability, adjusted dynamically as wrong signatures are received, to achieve isolation. Neighbors of a vehicle communicates directly with the vehicle. L SelAuth also uses warning pushback to accelerate the desolation of pernicious vehicles. As in many other probabilistic verification schemes, vehicles running SelAuth verify an incoming message with a certain probability in order to help identify invalid signatures.However, an important difference is that in preceding work such a probability depends entirely on the local status of the receiver, disregarding where this message is from or whether other vehicles have checked this message. SelAuth leverages ancillary information shared between neighbours to facilitate the probability adjustment for fast and efficient isolation.” ([George and Thomas, 2018, p. 4](zotero://select/library/items/U58BNF8G)) 

Selective Authentication

>[Go to annotation](zotero://open-pdf/library/items/5LCJ4K92?page=6&annotation=477UQHIW) “We first analyzed Authentication of VANETs with Digital Signatures ,which uses signed messages.Eventhough it secured the network,resulted in computational burden.We later discussed on Fast Authentication and Selective Authentication schemes which were able to overcome some disadvantages of Digital Signatures,but had computational overhead leaving spoofed beacons undetected.Then we saw Particle filter that particularly reduces communication overhead and detection level of spoofed messages will be kept same. Context adaptive beacon verification(CABV) with particle filter proved that it can detect and prevent spoofed attacks and can reduce the computational overhead.But this method also leaves certain number of spoofed beacons undetected.So the study of modified approach of CABV with particle filter is considered in future which can increase the efficiency” ([George and Thomas, 2018, p. 6](zotero://select/library/items/U58BNF8G)) 

CABV, Beacons
