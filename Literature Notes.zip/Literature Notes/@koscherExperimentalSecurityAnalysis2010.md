---
title: Experimental Security Analysis of a Modern Automobile
authors: Karl Koscher, Alexei Czeskis, Franziska Roesner, Shwetak Patel, Tadayoshi Kohno, Stephen Checkoway, Damon McCoy, Brian Kantor, Danny Anderson, Hovav Shacham, Stefan Savage
year: 2010
---

# Experimental Security Analysis of a Modern Automobile
##### Karl Koscher, Alexei Czeskis, Franziska Roesner, Shwetak Patel, Tadayoshi Kohno, Stephen Checkoway, Damon McCoy, Brian Kantor, Danny Anderson, Hovav Shacham, Stefan Savage (2010)
[Zotero-Link](zotero://select/items/@koscherExperimentalSecurityAnalysis2010)

Tags: #History #ECU #Code #Safety #BrakeAttack #Braking #PhysicalAttack #RemoteAttack #CANPackets #Sniffing #DoS #Vulnerabilities #Authentication #Encryption #ICP #BCM #Fuzzing #ReverseEngineering #AccessControl #PrivilegeEscalation #Detection #SupplyChain #Ressources 

>[!ABSTRACT]-
>Modern automobiles are no longer mere mechanical devices; they are pervasively monitored and controlled by dozens of digital computers coordinated via internal vehicular networks. While this transformation has driven major advancements in efficiency and safety, it has also introduced a range of new potential risks. In this paper we experimentally evaluate these issues on a modern automobile and demonstrate the fragility of the underlying system structure. We demonstrate that an attacker who is able to infiltrate virtually any Electronic Control Unit (ECU) can leverage this ability to completely circumvent a broad array of safety-critical systems. Over a range of experiments, both in the lab and in road tests, we demonstrate the ability to adversarially control a wide range of automotive functions and completely ignore driver input —including disabling the brakes, selectively braking individual wheels on demand, stopping the engine, and so on. We find that it is possible to bypass rudimentary network security protections within the car, such as maliciously bridging between our car’s two internal subnets. We also present composite attacks that leverage individual weaknesses, including an attack that embeds malicious code in a car’s telematics unit and that will completely erase any evidence of its presence after a crash. Looking forward, we discuss the complex challenges in addressing these vulnerabilities while considering the existing automotive ecosystem.


---

# Summary

- This paper investigates the vulnerabilities in modern automotive systems by conducting an **experimental evaluation** on a late-model vehicle. The researchers demonstrate the ability to **adversarially control** critical vehicle functions such as braking, acceleration, and steering by infiltrating the car’s Electronic Control Units (ECUs) via the CAN bus.
- The study reveals that it is possible to bypass existing rudimentary network security protections, showing how attackers can inject malicious CAN messages or bridge different subnets within the car. The team developed the **CARSHARK** tool to analyze and manipulate the CAN traffic, and they conducted their tests both in a controlled lab environment and on a closed road course.
- The paper emphasizes the **growing attack surface** as vehicles become more connected through telematics systems, Bluetooth, and other wireless protocols, highlighting the challenges in securing these entry points against remote and physical attackers.

# Relevancy

- **Provides Real-World Testing Scenarios**: The paper's detailed account of conducting physical and remote attacks on an actual vehicle closely aligns with your interest in testing CAN traffic manipulation in simulated environments like CARLA.
- **Explores Vulnerabilities in CAN Protocol**: The analysis of the CAN protocol’s weaknesses and how they were exploited in practice supports your thesis focus on understanding and testing these vulnerabilities.
- **Uses Custom Tools for Analysis**: The development of the CARSHARK tool offers insights into building or adapting similar tools like CANToolz for your experiments.

# Notable Sections and Pages

- **Section II: Experimental Setup (Pages 3-5)**: Describes the vehicle setup and testing tools like CARSHARK, which is critical for understanding how to replicate or adapt their methodology in simulation environments.
- **Section IV: CAN Bus Security (Pages 6-8)**: Analyzes the inherent security challenges of the CAN bus, providing foundational knowledge directly applicable to your experiments.
- **Section V: Component Vulnerability Assessment (Pages 9-12)**: Details the vulnerabilities in specific ECUs and how they were exploited, offering examples of practical attack vectors that can be tested in your thesis.

# Recommendations

This paper is an essential addition to your thesis literature as it provides empirical evidence of CAN bus vulnerabilities and practical examples of attacks on modern vehicles. I recommend citing it for its comprehensive experimental approach and insights into real-world CAN traffic manipulation.

---

# Annotations  
(11/4/2024, 9:49:37 PM)

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=1&annotation=ZLJT4RGR) “Through 80 years of mass-production, the passenger automobile has remained superficially static: a single gasolinepowered internal combustion engine; four wheels; and the familiar user interface of steering wheel, throttle, gearshift, and brake. However, in the past two decades the underlying control systems have changed dramatically. Today’s automobile is no mere mechanical device, but contains a myriad of computers. These computers coordinate and monitor sensors, components, the driver, and the passengers. Indeed, one recent estimate suggests that the typical luxury sedan now contains over 100 MB of binary code spread across 50–70 independent computers — Electronic Control Units (ECUs) in automotive vernacular — in turn communicating over one or more shared internal network buses [8], [13].” ([Koscher et al., 2010, p. 1](zotero://select/library/items/6CRVZZEA)) 

History, ECU, Code

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=1&annotation=X3H2TPJ3) “While the automotive industry has always considered safety a critical engineering concern (indeed, much of this new software has been introduced specifically to increase safety, e.g., Anti-lock Brake Systems) it is not clear whether vehicle manufacturers have anticipated in their designs the possibility of an adversary. Indeed, it seems likely that this increasing degree of computerized control also brings with it a corresponding array of potential threats.” ([Koscher et al., 2010, p. 1](zotero://select/library/items/6CRVZZEA)) 

Safety, Brake

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=2&annotation=LT7PCTS6) “Indeed, we have demonstrated the ability to systematically control a wide array of components including engine, brakes, heating and cooling, lights, instrument panel, radio, locks, and so on. Combining these we have been able to mount attacks that represent potentially significant threats to personal safety. For example, we are able to forcibly and completely disengage the brakes while driving, making it difficult for the driver to stop. Conversely, we are able to forcibly activate the brakes, lurching the driver forward and causing the car to stop suddenly.” ([Koscher et al., 2010, p. 2](zotero://select/library/items/6CRVZZEA)) 

Brake

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=4&annotation=QMS35J6Q) “car’s internal networks. The first is physical access. Someone — such as a mechanic, a valet, a person who rents a car, an ex-friend, a disgruntled family member, or the car owner — can, with even momentary access to the vehicle, insert a malicious component into a car’s internal network via the ubiquitous OBD-II port (typically under the dash). The attacker may leave the malicious component permanently attached to the car’s internal network or, as we show in this paper, they may use a brief period of connectivity to embed the malware within the car’s existing components and then disconnect. A similar entry point is presented by counterfeit or malicious components entering the vehicle parts supply chain — either before the vehicle is sent to the dealer, or with a car owner’s purchase of an aftermarket third-party component (such as a counterfeit FM radio).” ([Koscher et al., 2010, p. 4](zotero://select/library/items/6CRVZZEA)) 

physical

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=4&annotation=Y28IRR7C) “The other vector is via the numerous wireless interfaces implemented in the modern automobile. In our car we identified no fewer than five kinds of digital radio interfaces accepting outside input, some over only a short range and others over indefinite distance. While outside the scope of this paper, we wish to be clear that vulnerabilities in such services are not purely theoretical. We have developed the ability to remotely compromise key ECUs in our car via externally-facing vulnerabilities, amplify the impact of these remote compromises using the results in this paper, and ultimately monitor and control our car remotely over the Internet.” ([Koscher et al., 2010, p. 4](zotero://select/library/items/6CRVZZEA)) 

Remote

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=5&annotation=7Q3CQMDN) “A CAN packet (shown in Figure 5) does not include addresses in the traditional sense and instead supports a publish-and-subscribe communications model. The CAN ID header is used to indicate the packet type, and each packet is both physically and logically broadcast to all nodes, which then decide for themselves whether to process the packets.” ([Koscher et al., 2010, p. 5](zotero://select/library/items/6CRVZZEA)) 

CAN packet

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=6&annotation=URS49PUI) “Broadcast Nature. Since CAN packets are both physically and logically broadcast to all nodes, a malicious component on the network can easily snoop on all communications or send packets to any other node on the network. CARSHARK leverages this property, allowing us to observe and reverse-engineer packets, as well as to inject new packets to induce various actions.” ([Koscher et al., 2010, p. 6](zotero://select/library/items/6CRVZZEA)) 

Sniffing

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=6&annotation=9492N4PX) “Fragility to DoS. The CAN protocol is extremely vulnerable to denial-of-service attacks. In addition to simple packet flooding attacks, CAN’s priority-based arbitration scheme allows a node to assert a “dominant” state on the bus indefinitely and cause all other CAN nodes to back off. While most controllers have logic to avoid accidentally” ([Koscher et al., 2010, p. 6](zotero://select/library/items/6CRVZZEA)) 

DoS, vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=6&annotation=L4YQ2MFD) “breaking the network this way, adversarially-controlled hardware would not need to exercise such precautions.” ([Koscher et al., 2010, p. 6](zotero://select/library/items/6CRVZZEA))

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=6&annotation=PK2SSDGH) “No Authenticator Fields. CAN packets contain no authenticator fields — or even any source identifier fields meaning that any component can indistinguishably send a packet to any other component. This means that any single compromised component can be used to control all of the other components on that bus, provided those components themselves do not implement defenses; we consider the security of individual components in Section V.” ([Koscher et al., 2010, p. 6](zotero://select/library/items/6CRVZZEA)) 

Authentication

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=7&annotation=NUX5V3PM) “Under the hood, ECUs are supposed to use a fixed challenge (seed) for each of these challenge-response pairs; the corresponding responses (keys) are also fixed and stored in these ECUs. The motivation for using fixed seeds and keys is to avoid storing the challenge-response algorithm in the ECU firmware itself (since that firmware could be read out if an external flash chip is used). Indeed, the associated reference standard states “under no circumstances shall the encryption algorithm ever reside in the node.” (The tester, however, does have the algorithm and uses it to compute the key.) Different ECUs should have different seeds and keys.” ([Koscher et al., 2010, p. 7](zotero://select/library/items/6CRVZZEA)) 

Encryption

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=8&annotation=22FTR2VH) “Packet Sniffing and Targeted Probing. To begin, we used CARSHARK to observe traffic on the CAN buses in order to determine how ECUs communicate with each other. This also revealed to us which packets were sent as we activated various components (such as turning on the headlights). Through a combination of replay and informed probing, we were able to discover how to control the radio, the Instrument Panel Cluster (IPC), and a number of the Body Control Module (BCM) functions, as we discuss below. This approach worked well for packets that come up during normal operation, but was less useful in mapping the interface to safety-critical powertrain components.” ([Koscher et al., 2010, p. 8](zotero://select/library/items/6CRVZZEA)) 

ICP, BCM

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=8&annotation=9RTSQWX6) “Fuzzing. Much to our surprise, significant attacks do not require a complete understanding or reverse-engineering of even a single component of the car. In fact, because the range of valid CAN packets is rather small, significant damage can be done by simple fuzzing of packets (i.e., iterative testing of random or partially random packets). Indeed, for attackers seeking indiscriminate disruption, fuzzing is an effective attack by itself. (Unlike traditional uses of fuzzing, we use fuzzing to aid in the reverse engineering of functionality.)” ([Koscher et al., 2010, p. 8](zotero://select/library/items/6CRVZZEA)) 

Fuzzing

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=9&annotation=8BEY4QN8) “Reverse-Engineering. For a small subset of ECUs (notably the telematics unit, for which we obtained multiple instances via Internet-based used parts resellers) we dumped their code via the CAN ReadMemory service and used a third-party debugger (IDA Pro) to explicitly understand how certain hardware features were controlled. This approach is essential for attacks that require new functionality to be added (e.g., bridging low and high-speed buses) rather than simply manipulating existing software capabilities.” ([Koscher et al., 2010, p. 9](zotero://select/library/items/6CRVZZEA)) 

ReverseEngineering

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=11&annotation=2B6KD8HZ) “Brakes. Our fuzzing of the Electronic Brake Control Module (see Table IV) allowed us to discover how to lock individual brakes and sets of brakes, notably without needing to unlock the EBCM with its DeviceControl key. In one case, we sent a random packet which not only engaged the front left brake, but locked it resistant to manual override even through a power cycle and battery removal. To remedy this, we had to resort to continued fuzzing to find a packet that would reverse this effect. Surprisingly, also without needing to unlock the EBCM, we were also able to release the brakes and prevent them from being enabled, even with car’s wheels spinning at 40 MPH while on jack stands.” ([Koscher et al., 2010, p. 11](zotero://select/library/items/6CRVZZEA)) 

BrakeAttack

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=13&annotation=P32ER7ZN) “Ease of Attack. In starting this project we expected to spend significant effort reverse-engineering, with non-trivial effort to identify and exploit each subtle vulnerability. However, we found existing automotive systems — at least those we tested — to be tremendously fragile. Indeed, our simple fuzzing infrastructure was very effective and to our surprise, a large fraction of the random packets we sent resulted in changes to the state of our car. Based on this experience, we believe that a fuzzer itself is likely be a universal attack for disrupting arbitrary automobiles (similar to how the “crashme” program that fuzzed system calls was effective in crashing operating systems before the syscall interface was hardened).” ([Koscher et al., 2010, p. 13](zotero://select/library/items/6CRVZZEA))

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=13&annotation=BF6NZB3H) “Unenforced Access Controls. While we believe that standard access controls are weak, we were surprised at the extent to which the controls that did exist were frequently unused. For example, the firmware on an ECU controls all of its critical functionality and thus the standard for our car’s CAN protocol variant describes methods for ECUs to protect against unauthorized firmware updates. We were therefore surprised that we could load firmware onto some key ECUs, like our telematics unit (a critical ECU) and our Remote Control Door Lock Receiver (RCDLR), without any such authentication. Similarly, the protocol standard also makes an earnest attempt to restrict access to DeviceControl diagnostic capabilities. We were therefore also surprised to find that critical ECUs in our car would respond to DeviceControl packets without authentication first.” ([Koscher et al., 2010, p. 13](zotero://select/library/items/6CRVZZEA)) 

AccessControl

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=13&annotation=ZRVZSZD2) “Attack Amplification. We found multiple opportunities for attackers to amplify their capabilities — either in reach or in stealth. For example, while the designated” ([Koscher et al., 2010, p. 13](zotero://select/library/items/6CRVZZEA)) 

privilege escalation

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=14&annotation=EXUX5FP8) “gateway node between the car’s low-speed and highspeed networks (the BCM) should not expose any interface that would let a low-speed node compromise the high-speed network, we found that we could maliciously bridge these networks through a compromised telematics unit. Thus, the compromise of any ECU becomes sufficient to manipulate safety-critical components such as the EBCM. As more and more components integrate into vehicles, it may become increasingly difficult to properly secure all bridging points.” ([Koscher et al., 2010, p. 14](zotero://select/library/items/6CRVZZEA))

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=14&annotation=5YK4F664) “Detection Versus Prevention. More broadly, certain considerations unique to cyber-physical vehicles raise the possibility of security via detection and correction of anomalies, rather than prevention and locking down of capabilities. For example, the operational and economic realities of automotive design and manufacturing are stringent. Manufacturers must swiftly integrate parts from different suppliers” ([Koscher et al., 2010, p. 14](zotero://select/library/items/6CRVZZEA)) 

Detection, SupplyChain

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=15&annotation=RWVNEZI7) “(changing as needed to second and third source suppliers) in order to quickly reach market and at low cost. Competitive pressures drive vendors to reuse designs and thus engenders significant heterogeneity. It is common that each ECU may use a different processor and/or software architecture and some cars may even use different communications architectures — one grafted onto the other to integrate a vendor assembly and bring the car to market in time. Today the challenges of integration have become enormous and manufacturers seek to reduce these overheads at all costs a natural obstacle for instituting strict security policies. In addition, many of an automobile’s functions are safety critical, and introducing additional delay into the processing of, say, brake commands, may be unsafe.” ([Koscher et al., 2010, p. 15](zotero://select/library/items/6CRVZZEA))

>[Go to annotation](zotero://open-pdf/library/items/SZNCAM83?page=15&annotation=RI4CXY7R) “These considerations raise the possibility of exploring the tradeoff between preventing and correcting malicious actions: if rigorous prevention is too expensive, perhaps a quick reversal is sufficient for certain classes of vulnerabilities. Several questions come with this approach: Can anomalous behavior be detected early enough, before any dangerous packets are sent? Can a fail-safe mode or last safe state be identified and safely reverted to? It is also unclear what constitutes abnormal behavior on the bus in the first place, as attacks can be staged entirely with packets that also appear during normal vehicle operation.” ([Koscher et al., 2010, p. 15](zotero://select/library/items/6CRVZZEA)) 

Ressources

