---
title: Enhancement of Automotive Penetration Testing with Threat Analyses Results
authors: Jürgen Dürrwang, Johannes Braun, Marcel Rumez, Reiner Kriesten, Alexander Pretschner
year: 2018
---

# Enhancement of Automotive Penetration Testing with Threat Analyses Results
##### Jürgen Dürrwang, Johannes Braun, Marcel Rumez, Reiner Kriesten, Alexander Pretschner (2018)
[Zotero-Link](zotero://select/items/@durrwangEnhancementAutomotivePenetration2018)

Tags: #Code #ECU #TARA #BlackBox #WhiteBox #HARA #Pentesting #CSP #HEAVENS #STRIDE #ThreatAnalysis #SGM #ISO26262 #Airbag #Vulnerabilities #UDS #CAN #RemoteAttack #Design #Authentication #Replay #Cryptography #Encryption #HMAC #ACL #AES #AES #AUTOSAR #SecOC #PDU #BruteForce #CIA #SGM 

>[!ABSTRACT]-
>In this work, we present an approach to support penetration tests by combining safety and security analyses to enhance automotive security testing. Our approach includes a new way to combine safety and threat analyses to derive possible test cases. We reuse outcomes of a performed safety analysis as the input for a threat analysis. We show systematically how to derive test cases and we present the applicability of our approach by deriving and performing test cases for a penetration test of an automotive Electronic Control Unit (ECU). Therefore, we selected an airbag control unit due to its safety-critical functionality. During the penetration test, the selected control unit was installed on a test bench and we were able to successfully exploit a discovered vulnerability, causing the detonation of airbags.


---

# Summary

- The paper introduces a method that integrates **Hazard Analysis and Risk Assessment (HARA)** with **Threat Analysis and Risk Assessment (TARA)** to derive comprehensive test cases for penetration testing of automotive Electronic Control Units (ECUs). By combining safety and security analyses, the authors aim to streamline the testing process and increase efficiency.
- The approach involves creating **attack trees** based on identified hazards and threats, which are used to systematically generate test cases. The authors demonstrate the method through a practical penetration test on an airbag control unit, successfully exploiting a vulnerability that could cause unintended airbag deployment.
- The integration of **Security by Design** concepts and early-phase threat modeling is emphasized to minimize vulnerabilities before they reach implementation stages.

# Relevancy

- **Combines Safety and Security Analyses**: The integration of safety (HARA) and security (TARA) methodologies aligns with your aim to assess vulnerabilities comprehensively in simulated environments like CARLA.
- **Provides Attack Tree Framework**: The attack tree methodology supports your objective to structure and design CAN manipulation experiments in an organized manner.
- **Demonstrates Practical Application**: The airbag ECU test provides a real-world example of how vulnerabilities can be identified and exploited, offering insights into structuring your own experiments with CAN traffic.

# Notable Sections and Pages

- **Introduction (Pages 1-2)**: Explains the importance of integrating safety and security analyses in automotive systems and introduces the combined approach.
- **Section on Threat Modeling Using HARA and TARA (Pages 3-4)**: Discusses the methodology for integrating safety and threat analyses to develop attack trees, directly relevant for planning your experiments.
- **Experimental Evaluation (Page 8)**: Describes the practical penetration test on the airbag ECU, which provides an example of implementing the methodology for testing vulnerabilities.

# Recommendations

This paper is a crucial addition to your thesis literature. It offers a structured and validated methodology for testing and manipulating automotive systems in a controlled environment. I recommend citing it for its approach to integrating safety and security analyses and the practical application of penetration testing techniques.

---

# Annotations  
(11/7/2024, 3:07:30 PM)

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=1&annotation=P6UD2YXA) “Modern automobiles host more than 50 ECUs, which contain a total of up to 100 million code lines to control safety-critical functionality [1]. In total, this fact and the close interconnectivity of automotive ECUs open up new possibilities to attack these systems. Many of these attacks affect the safe operation of the vehicle which can lead to injuries of the passengers [2][3][4][5]. To decrease the possibility of such scenarios, security has to be an integral part of the development lifecycle. In order to achieve the highest level of protection against security attacks, the Security by Design concept represents a promising attempt. Therefore, security tasks have to be embedded in early phases of the development lifecycle. One securityrelated task is the Threat Analysis and Risk Assessment (TARA). It identifies and prioritizes possible threats against the target which can lead to security incidents. Thus, countermeasures or design changes can be applied before the first line of code is written. In contrast, a validation of implemented security measures and a review of further vulnerabilities after an implementation should be performed. This can be done with a security testing of the system including internal and/or external testing. In particular, internal security testing is typically executed during the product development. On the other hand, external security tests, which are usually performed after product development, are called penetration tests if they are performed from the perspective of an attacker (see Figure 1, right path).” ([Dürrwang et al., 2018, p. 1](zotero://select/library/items/UC8I5XE3)) 

Code, ECU, TARA

![](EGTLAL5A.png)  
>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=1&annotation=EGTLAL5A)  
([Dürrwang et al., 2018, p. 1](zotero://select/library/items/UC8I5XE3)) 

Boxes

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=2&annotation=TZ9WWJQK) “As safety violations can also be caused by security problems, it is important to analyse Hazard Analysis and Risk Assessment (HARA) results in terms of security. Beyond that, safety analyses performed with HARAs are a fixed part in the automotive sector. Results of these analyses contain valuable knowledge which can be used for threat modeling and therefore for penetration testing as well. Unfortunately, no approach exists which reuses HARA and TARA results for penetration testing. Consequently, we want to show the first step towards an approach that reuses results of both analysis types for decreasing the security testing effort. Moreover, we evaluate our approach by applying it for a safety critical ECU. In detail, the contributions of this paper are the following:” ([Dürrwang et al., 2018, p. 2](zotero://select/library/items/UC8I5XE3)) 

HARA, TARA

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=2&annotation=R7NVW6WF) “SECURITY TESTING METHODOLOGIES A traditional approach in IT to assess the security of a system is the application of a penetration test. In this type of testing, the security engineers do not have any detailed information about the target system. The objective of penetration testing is to analyse the security level of a system, network or application from an attacker’s perspective. This also implicates to use general public tools and methods which are available to a potential hacker. The primary goal of penetration testing is to find vulnerabilities that are not found during internal security testing and could be exploited by an adversary. Furthermore, penetration testing is usually a mandatory part of a security testing. The execution of penetration tests is normally at a late stage of the product development or afterwards. If any security issues are uncovered at this point, the costs and efforts of software patches are high in contrast to early development stages. Thus, a combination of white-box testing during the product development and penetration testing after the product release is reasonable.” ([Dürrwang et al., 2018, p. 2](zotero://select/library/items/UC8I5XE3)) 

Pentesting

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=3&annotation=EHEU9WWA) “In summary, the analysed security testing methodologies have different characteristics relating to penetration testing. Only the PTES guideline supports the approach of threat modeling, which is fundamental part of our approach to derive test cases. As we mentioned before, PTES does not recommend a specific methodology for this step. For this reason, we depict differences between existing threat modeling methodologies in the next section relating to their applicability for Cyber-Physical-Systems (CPS) due to their special relationship between safety and security.” ([Dürrwang et al., 2018, p. 3](zotero://select/library/items/UC8I5XE3)) 

CSP

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=3&annotation=AQIM2DVS) “The HEAVENS methodology is focused on threats of the Microsoft Spoofing, Tampering, Repudiation, Information disclosure, Denial of service, Elevation of privilege (STRIDE) classification model [18][19]. Due to the fact that the scope of STRIDE is mainly on security goals, it depends on the security engineer to decide whether a threat violates the safety of a vehicle or not. This fact implies that security engineers have to be familiar with safety to decide if a threat can violate a safety goal. Lastly, EVITA uses dark-side scenarios as unintended use cases to identify possible security threats. The methodology is mainly focused on vehicle-to-vehicle connections and less on in-vehicular networks. The threat identification depends highly on the set of use cases (dark-side scenarios) whereas safety-related use cases are less in focus. As a result, threats with impact on safety can be unconsidered by using this approach. Furthermore, the classification of safety and non-safety threats is different. Hence, this can lead to an unbalanced threat assessment [20].” ([Dürrwang et al., 2018, p. 3](zotero://select/library/items/UC8I5XE3)) 

HEAVENS, STRIDE

![](2GHEPX79.png)  
>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=4&annotation=2GHEPX79)  
([Dürrwang et al., 2018, p. 4](zotero://select/library/items/UC8I5XE3)) ThreatAnalysis

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=4&annotation=M5BJNENG) “As a result, we decided to use another approach for a combined safety and security analysis that can be easily integrated into existing safety analyses while also achieving a link between safety and security. The method is called Security Guide-word Method (SGM) and will be described in the next section.” ([Dürrwang et al., 2018, p. 4](zotero://select/library/items/UC8I5XE3)) 

SGM

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=5&annotation=EKMDEFHK) “For this purpose, we extend the typical safety analysis process with our approach as an intermediate step, which is shown in Figure 3 by the dashed box. The analyst is guided through the brainstorming phase using guide-words and a template (see Table 2) to achieve a structured threat identification. The use of guide-words was originally introduced by HAZOP for functional safety analysis and in compliance with ISO 26262. HAZOP was then extended by the researchers Rune et al. [32][33] for security, whereupon we extended the approach to reuse the results of a safety analysis to identify threats. In particular, we derive threats from the identified hazards violating the safety of the vehicle. We call this method the SGM and we demonstrated the applicability of the method by means of an experimental evaluation with safety and security engineers [31].” ([Dürrwang et al., 2018, p. 5](zotero://select/library/items/UC8I5XE3)) 

ISO26262

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=5&annotation=EXB2AKLQ) “We want to point out that SGM is actually only focused on security threats which can violate safety goals. We consider this as reasonable due to the negative consequences that safety violations can cause. Furthermore, manufacturers are committed to performing a safety analysis and therefore they should look for security threats which influence safety goals. Currently, assets like confidentiality or repudiation are not directly addressed and therefore they should be addressed by using one of the listed threat methodologies above, e.g. STRIDE or hTMM.” ([Dürrwang et al., 2018, p. 5](zotero://select/library/items/UC8I5XE3))

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=9&annotation=DKB2RCDK) “Consequently, we used each path in the attack tree for the derivation of individual test cases. In particular, as a first test case, we derived: Try to violate the authenticity and integrity of the diagnostic message used for airbag deployment. One example for this is the replay of a message, which was recorded during a diagnostic session between PCU and diagnostic tester. Performing the second path of the tree, we derived: Try to manipulate the payload of messages which are used in the diagnostic session. For the manipulation of payloads, we simply tried all possible combinations on binary level. Lastly, the third path in the tree leads to the test case: Try to fake crash situation by manipulating crash signals or message. As we knew that for this case we would have to manipulate three different signal sources, we concluded that this path should be the most difficult one.” ([Dürrwang et al., 2018, p. 9](zotero://select/library/items/UC8I5XE3)) 

Aribag

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=10&annotation=YUQFTS3U) “Identification of Vulnerable Vehicles In a first step, we had to check the implementation of the EOL capability according to the ISO standard. Therefore, a diagnostic scan (UDS) on the test vehicles was performed. The standard mandates that the first Airbag-ECU inside a vehicle listens and replies to diagnostic requests (UDS) with the CAN ID shown in Table 3. This is the so-called fixed-address and enables us to directly identify if an Airbag-ECU (PCU) has implemented the relevant EOL standard. Table 3: CAN IDs for communication with fixed-address PCU regarding the airbag standard [38] 11 bit CAN ID 29 bit CAN ID Request 0x7F1 0x18DA53F1 Response 0x7F9 0x18DAF153 In the case that a vehicle contains more than one airbag unit, the CAN IDs of the other units can be requested via a diagnostic service reached from the first AirbagECU (fixed-address PCU). If a PCU does not respond to the sent messages, it can be assumed directly that the EOL standard has not been implemented.” ([Dürrwang et al., 2018, p. 10](zotero://select/library/items/UC8I5XE3)) 

vulnerabilitites, uds, can

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=12&annotation=28KMS9IU) “To verify the exploitation of this vulnerability we used the test bench in Figure 10 for the selected target and executed all the necessary steps according to the EOL standard. To ensure the functionality of the target, the pyrotechnic charges were simulated by attaching resistors to the corresponding pins on the connector of the target. To enable the EOL functionality CAN traffic was replayed, consisting of only one message including a vehicle speed of zero. This CAN bus only included the target and a CAN transceiver sending the diagnostic messages and playing back the aforementioned vehicle speed message. The exploitation was successfully validated by an oscilloscope displaying the firing impulse. The related Common Vulnerabilities and Exposures (CVE)-ID is listed under CVE-2017-14937 [41]. In addition, a module for the Metasploit Hardware Bridge was developed in cooperation with the security researcher Craig Smith [42]. The module can test for the presence of this vulnerability in a vehicle without the possibility of actually deploy the charges [43].” ([Dürrwang et al., 2018, p. 12](zotero://select/library/items/UC8I5XE3))

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=12&annotation=4JBYEHYM) “Combined with the fast and highly automated procedure of the attack, this leads to the possibility of malicious deployment while the engine is running and people reside in the car, e.g. while waiting at a stoplight. This should be seen as a real threat, as the remote exploitation of passenger vehicles, specifically getting access to the CAN bus via remote connections has been demonstrated before [44][45]. Besides, it is conceivable that hackers distribute malicious OBD-Dongles on sales platforms on the Internet. Furthermore, OBD-Dongles sold by manufactures can also give the required access to the internal vehicle network. In a worst-case scenario, this could lead to remote access [46]. Both options could lead to a scaled attack on different types of cars from several manufactures as the vulnerability is part of an international standard.” ([Dürrwang et al., 2018, p. 12](zotero://select/library/items/UC8I5XE3))

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=13&annotation=S3ER37K7) “COUNTERMEASURES In general, software should be designed from the ground up as secure as possible by applying Security by Design during the development process. There are several security principles, which software architects should consider. The following countermeasures are only examples for our observed target based on the mentioned principles.” ([Dürrwang et al., 2018, p. 13](zotero://select/library/items/UC8I5XE3)) 

Design

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=13&annotation=U9E65ZL3) “Selection of Suitable Technologies Documented exploitation of passenger vehicles was achieved in multiple cases by sending or replaying CAN messages on the target’s bus. CAN can be seen as a bus system not designed with security issues in mind. Especially the lack of authentication of message sources is one of the main problems of CAN. By using cryptographic authentication methods coupled with integrity protection and a freshness value, this problem can be mitigated. An example of this is an Keyed-Hash Message Authentication Code (HMAC) of the transmitted message, including a freshness value to prevent replay attacks. In addition, techniques such as threat modeling [18][31] can provide valuable information to select specific security measures for implementation. Furthermore, ACL’s bidirectional communication capability [47] provides the ability to add an authentication process using a recognized method such as digital certificates. Moreover, the mandatory use of an ACL line on the Airbag-ECU as an additional plausibility check could have prevented exploitation by a single CAN message.” ([Dürrwang et al., 2018, p. 13](zotero://select/library/items/UC8I5XE3)) 

Authentication, Replaying, Cryptography, HMAC, ACL

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=13&annotation=7CLWU4P4) “Usage of Cryptography When developers want to design a new security feature, they should follow the Kerckhoff’s Principle [40]. The principle explicitly describes that cryptosystems shouldn’t be secure due to hidden details about how the algorithm works (security by obscurity). Moreover, the whole secret should be based on the confidentiality of the used key. The past has already shown multiple times that mechanisms which disregard the mentioned principle are often broken as soon as the algorithm has been reverse-engineered [49]. Our investigation has also confirmed the violation of the mentioned principle by analysing the sent seed. A first approach to fix the existing issue could be an additional security layer which ensures a correct authentication. However, the best solution to the problem is to use generally recommended cryptographic algorithms such as the Advanced Encryption Standard (AES) [50]. The AUTomotive Open System ARchitecture (AUTOSAR) members have already recognized the necessity of the mentioned security goals for future on-board communication. For this reason, they have standardized the SecOC module [51], which includes authentication mechanisms on the level of Protocol Data Units (PDUs). The specification does not define a specific method for creating a Message Authentication Code (MAC), but rather recommends standardized cryptographic algorithms and defines the payload of a secured PDU with a freshness value and an authenticator for protecting against replay attacks and unauthorized manipulation of the message.” ([Dürrwang et al., 2018, p. 13](zotero://select/library/items/UC8I5XE3)) 

Encryption, AES, AUTOSAR, SecOC,PDU

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=13&annotation=PZMASJHW) “Hardening Against Brute-Force Attacks The use of Negative Response Codes (NRCs), such as the exceeded number of attempts and required time delay not expired, as described in the UDS standard could be used to slow down brute-force attempts. While the former would require a power cycle of the target to continue the brute-force attempt, the latter would slow the approach down. To counter the use of scripted power cycling of the target in rapid succession, the target could require a certain time delay after being powered on, before enabling the diagnostic capability. The length of the seed and key could be increased to harden the target against brute-force attempts. As mentioned before the length of 2 bytes leads to 65536 possible keys per seed. By using the most significant byte for the version number of the implemented ISO standard, the most significant byte is fixed in every seed. Thus, by only changing the values of the least significant byte, only 256 different seeds can be supplied by the target after a request, although the seed is 16 bits long. Consequently, this reduces the number of maximum tries to unlock the Security Access, as the same seeds occur more frequently, which enables a faster iteration over the possible keys. Besides this problem, we recommend to increase the key length significantly. In combination with a suitable algorithm such as AES, a key length of 128 bits is recommended [52][53].” ([Dürrwang et al., 2018, p. 13](zotero://select/library/items/UC8I5XE3)) 

BruteForce

>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=14&annotation=FSF48ILZ) “For an easier integration in existent approaches we want to provide a mapping between SGM guide-words and the CIA(A) triad in Table 4. This further allows us to provide a mapping between SGM and STRIDE. We provide this transformation ability between SGM and STRIDE due to the fact that STRIDE nomenclature is well-known in security and commonly used. As one example for the mapping, we utilize the threat Unintended airbag deployment can be triggered by triggering of (diagnostic) function airbag deployment. that was built with the guideword triggering of (diagnostic) function. For this guideword, we propose to select spoofing from Table 4 as pedant for STRIDE. With this, we can transform the threat description to Spoofing of (diagnostic) function presenting the STRIDE nomenclature. We do this for the other two threats as well, leading to an attack tree in STRIDE nomenclature shown in Figure 12.” ([Dürrwang et al., 2018, p. 14](zotero://select/library/items/UC8I5XE3)) 

CIA

![](CPJ55DS6.png)  
>[Go to annotation](zotero://open-pdf/library/items/IEHKS8HQ?page=14&annotation=CPJ55DS6)  
([Dürrwang et al., 2018, p. 14](zotero://select/library/items/UC8I5XE3)) 

SGM