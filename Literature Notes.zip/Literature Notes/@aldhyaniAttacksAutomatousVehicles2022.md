---
title: "Attacks to Automatous Vehicles: A Deep Learning Algorithm for Cybersecurity"
authors: Theyazn H. H. Aldhyani, Hasan Alkahtani
year: 2022
---

# Attacks to Automatous Vehicles: A Deep Learning Algorithm for Cybersecurity
##### Theyazn H. H. Aldhyani, Hasan Alkahtani (2022)
[Zotero-Link](zotero://select/items/@aldhyaniAttacksAutomatousVehicles2022)

Tags: #ECU #IVN #CAN #IDS #Authentication #AttackTypes #Vulnerabilities #DP #ML #CNN #ANN #RealAttacks #Prevention #Detection #Flooding #Spoofing #Replay #RemoteAttack 

>[!ABSTRACT]-
>Rapid technological development has changed drastically the automotive industry. Network communication has improved, helping the vehicles transition from completely machine- to software-controlled technologies. The autonomous vehicle network is controlled by the controller area network (CAN) bus protocol. Nevertheless, the autonomous vehicle network still has issues and weaknesses concerning cybersecurity due to the complexity of data and traffic behaviors that benefit the unauthorized intrusion to a CAN bus and several types of attacks. Therefore, developing systems to rapidly detect message attacks in CAN is one of the biggest challenges. This study presents a high-performance system with an artificial intelligence approach that protects the vehicle network from cyber threats. The system secures the autonomous vehicle from intrusions by using deep learning approaches. The proposed security system was verified by using a real automatic vehicle network dataset, including spoofing, flood, replaying attacks, and benign packets. Preprocessing was applied to convert the categorical data into numerical. This dataset was processed by using the convolution neural network (CNN) and a hybrid network combining CNN and long short-term memory (CNN-LSTM) models to identify attack messages. The results revealed that the model achieved high performance, as evaluated by the metrics of precision, recall, F1 score, and accuracy. The proposed system achieved high accuracy (97.30%). Along with the empirical demonstration, the proposed system enhanced the detection and classification accuracy compared with the existing systems and was proven to have superior performance for real-time CAN bus security.


---

# Summary

- The paper investigates the use of **deep learning algorithms** to detect and prevent cyber-attacks targeting autonomous vehicles (AVs). It emphasizes the need for real-time attack detection to ensure the safety and security of AV systems.
- The authors present a **neural network model** designed to identify malicious behaviors and patterns in AV data streams, focusing on CAN traffic and sensor data to detect anomalies.
- The study includes **case studies** demonstrating the algorithm's effectiveness against attacks such as **CAN bus spoofing** and **sensor manipulation**.

# Relevancy

- **Focuses on Cybersecurity for AVs**: The emphasis on using deep learning for detecting CAN bus attacks aligns with your goal of testing CAN traffic manipulation in simulation environments like CARLA.
- **Covers Attack Scenarios**: The case studies on spoofing and sensor attacks offer practical insights that can be applied when designing similar experiments in your thesis.
- **Utilizes Deep Learning**: The application of AI techniques for real-time monitoring and anomaly detection could inform your approach to integrating similar models in your simulated tests.

# Notable Sections and Pages

- **Section II: Deep Learning in AV Security (Pages 3-5)**: Discusses the structure and design of the deep learning model for AV security. This section is valuable for understanding how AI can be integrated into CAN traffic analysis.
- **Section IV: Case Studies (Pages 6-8)**: Provides detailed case studies on spoofing and sensor attacks, directly relevant for designing similar test scenarios in CARLA.
- **Section V: Algorithm Evaluation (Pages 9-11)**: Describes the results of the algorithm's performance in real-time testing environments, offering insights into the potential effectiveness of such models in your experiments.

# Recommendations

This paper is a useful addition to your thesis as it offers an AI-based approach to cybersecurity for AVs, specifically focusing on CAN bus attacks. I recommend citing it for its practical application of deep learning in detecting and mitigating cyber threats in AV systems.

---

# Annotations  
(10/31/2024, 8:32:16 PM)

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=1&annotation=MI6E6KZE) “Vehicle nodes function as a communication messenger and are studied in different research areas, for example, vehicular ad hoc networks, the Internet of vehicles, and vehicle-to-everything communications. An independent area of research, the in-vehicle networks (IVNs), deals with the communication between the engine control unit (ECU), the transmission control unit, the anti-lock braking system, the body control modules, and various sensors inside the vehicle [2].” ([Aldhyani and Alkahtani, 2022, p. 1](zotero://select/library/items/NFQIEGNX)) 

ECU, IVN

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=1&annotation=HLAJ6RX5) “There are special protocols that facilitate the functioning of IVNs. These protocols include the controller area network (CAN), FlexRay, and Ethernet [3]. CAN is the most common network topology used for controlling the automotive and the industrial system. It is a communication network that offers rapid communication among microcontroller devices. CAN employs interconnected nodes to send a message-based protocol designed to permit all nodes to receive the message and perform on the network message [4]. Figure 1 Sensors 2022, 22, 360. https://doi.org/10.3390/s22010360 https://www.mdpi.com/journal/sensors shows the CAN standard bus interface that attackers use to inject attack messages into the communication network.” ([Aldhyani and Alkahtani, 2022, p. 1](zotero://select/library/items/NFQIEGNX)) 

CAN

![](TBDR97LP.png)  
>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=2&annotation=TBDR97LP)  
([Aldhyani and Alkahtani, 2022, p. 2](zotero://select/library/items/NFQIEGNX)) 

CAN Bus

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=2&annotation=78MLJGX5) “Certain procedures must be considered when designing the cybersecurity of a missioncritical environment such as vehicles. IVNs protection requires intrusion detection or prevention systems of high accuracy [12]. A vehicle may recognize a critical message as an attack, causing safety issues. Consequently, the intrusion prevention system should be able to block false alarms [13,14]. Malicious attacks on vehicles could pose safety problems to passengers, pedestrians, and other vehicles. Hence, real-time response is vital for the cybersecurity of vehicles. Nevertheless, the in-vehicle system does not respond in real time due to constraints in the time and space resources of the moving vehicle. This leads to the necessity of designing a real-time intrusion detection system (IDS) of high accuracy that performs within the available limited resources [15].” ([Aldhyani and Alkahtani, 2022, p. 2](zotero://select/library/items/NFQIEGNX)) 

IDS

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=3&annotation=HEKTIXX9) “The CAN bus system has been shown to have technical defects, as the receiving nodes do not authenticate if a received packet whose source is not given is authorized or not [16]. Hackers can use ECUs to send unauthenticated CAN packets. Such defects make CAN bus systems vulnerable and unable to recognize the nodes responsible for the attacks. Thus, security systems for the CAN bus are important [17].” ([Aldhyani and Alkahtani, 2022, p. 3](zotero://select/library/items/NFQIEGNX)) 

Authenticaiton

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=3&annotation=KUYWZI8X) “Login password, knowledge-acquiring attacks are sorts of attacks on interconnectedcomputers networks [28]. Various sources of attack in traditional automobile vehicles have indeed been classified into two sorts [29], including cyberattacks on the sound system or mobile apps and attacks on the CAN. The latter sort of attack is deemed riskier than the first because CAN is interconnected to in-vehicle hardware pieces of equipment such as brakes, air conditioning systems, and the steering wheel. CAVs are integrated with both hardware and virtual software components interconnected to the complete transportation infrastructure, unlike computer networks and ordinary autos. As a result, any form of attack on a vehicle could occur in CAVs. Furthermore, as autonomy and connectivity grow, more vulnerability and attack points will occur [30]. Cybersecurity is required to secure the system against cyberattacks that could impact its effectiveness, whether electronically or physically. Utilizing the artificial intelligence model-based CAV architecture described in Figure 3, it is vital to detect, identify, and categorize different types of attacks on CAVs at an initial stage.” ([Aldhyani and Alkahtani, 2022, p. 3](zotero://select/library/items/NFQIEGNX)) 

Attacktypes, CAN, Vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=4&annotation=C4N3KEVR) “Several machine learning (ML) and deep learning (DL) algorithms have been applied to predict intrusions on the CAN bus, using the deep neural network [39,40], applied Convolutional Neural Networks (CNNs) [41], and artificial neural networks (ANNs) to build the adversarial attacks [42].” ([Aldhyani and Alkahtani, 2022, p. 4](zotero://select/library/items/NFQIEGNX)) 

DP, ML, CNN, ANN

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=4&annotation=DTK2DEB8) “To raise awareness about the cybersecurity of vehicles, a Jeep Cherokee was remotely hacked in 2015 [43]. A recent study [44] concluded that the main focus of research should not be on preventing attacks, since it is impossible to produce a vehicle with a security system that defends it against attacks. On the contrary, attention should be paid toward designing a system that detects attacks and responds accordingly.” ([Aldhyani and Alkahtani, 2022, p. 4](zotero://select/library/items/NFQIEGNX)) 

realattack, not prevention abut detection

![](6YIKNX2T.png)  
>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=6&annotation=6YIKNX2T)  
([Aldhyani and Alkahtani, 2022, p. 6](zotero://select/library/items/NFQIEGNX)) 

CAN Bus attacks, Flood, replaying, spoofing

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=17&annotation=GVC9CPFF) “With the rapid development of automobile manufacturing and the Internet of Things technology, the autonomous vehicle network has become intelligent and more established. The autonomous vehicle provides many facilities by connecting the automobile to satellite navigation or entertaining systems. However, autonomous cars providing these facilities face the risk of remote attacks due to the connection of the intelligent automatic vehicle network to the Internet for remote accessing.” ([Aldhyani and Alkahtani, 2022, p. 17](zotero://select/library/items/NFQIEGNX)) 

Remote

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=17&annotation=V6UTCDSQ) “The traffic behavior of CAN is a broadcast domain in nature. The development of an efficient security system has faced a lot of challenges. Hence, the intrusion detection system based on artificial intelligence models has given solutions against the increased risk of vehicle networks. IDS based on artificial intelligence algorithms can update the system if there are any changes in the CAN messages sent from possible attackers.” ([Aldhyani and Alkahtani, 2022, p. 17](zotero://select/library/items/NFQIEGNX))

>[Go to annotation](zotero://open-pdf/library/items/D8EMZMJW?page=17&annotation=G6VJ8C5P) “The empirical results established that the proposed CNN-LSTM and CNN models identify attack messages. The proposed systems were confirmed to efficiently display abnormal packet detection to protect the CAN bus. They can also be extended to other designs of security systems within the complex infrastructures of autonomous vehicle networks for secure data processing. Overall, the proposed systems achieved an accuracy score of 97.30%. These empirical results were compared with existing systems, outperforming them. In the future, we will continue improving our system by using advanced artificial intelligence.” ([Aldhyani and Alkahtani, 2022, p. 17](zotero://select/library/items/NFQIEGNX))