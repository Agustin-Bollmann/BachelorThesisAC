---
title: "Introduction to the CARLA simulator: Training a neural network to control a car (Part 1)"
to the CARLA simulator: Training a neural network to control a car (Part 1)
authors: Maciek Dziubiński
year: 2018
---

# Introduction to the CARLA simulator: Training a neural network to control a car (Part 1)
##### Maciek Dziubiński (2018)
[Zotero-Link](zotero://select/items/@dziubinskiIntroductionCARLASimulator2018)

Tags: #CARLA 

>[!ABSTRACT]-
>


---

# Summary

- The paper introduces **CARLA**, an open-source simulator built on the Unreal Engine 4 (UE4) gaming engine, designed for testing autonomous driving algorithms. It highlights CARLA’s ability to simulate various driving scenarios, including **traffic lights, speed limits, pedestrians**, and other cars in a realistic urban environment.
- The author walks through building a simple **Proportional-Derivative (PD) controller** to collect data from a predefined track and then using that data to train a neural network model to control steering. The approach demonstrates how CARLA can be used for both data collection and model training, focusing on steering control.
- The tutorial explains how to implement a **Model Predictive Control (MPC)** system for optimizing both steering and throttle, as well as the use of depth map data for training a convolutional neural network (CNN) for improved performance.

# Relevancy

- **Demonstrates CARLA's Flexibility for Testing**: It provides an example of how CARLA can be used for both developing and testing autonomous driving models, aligning with your interest in using CARLA for CAN traffic manipulation experiments.
- **Explores Real-Time Control Systems**: The tutorial’s focus on PD and MPC controllers aligns with your objective of testing CAN manipulation and understanding system responses in real-time scenarios.
- **Covers Data Collection and Training**: The detailed explanation of using CARLA for data collection and training neural networks offers insights into structuring your experiments and validating your manipulation methods.

# Notable Sections and Pages

- **Introduction to CARLA (Page 1)**: Provides an overview of the CARLA simulator, useful for understanding its capabilities and how it can be applied to your experiments.
- **Controller Implementation (Pages 3-5)**: Explains the setup and implementation of a PD controller for data collection, relevant for designing CAN traffic manipulation tests.
- **Neural Network Training (Pages 5-7)**: Details the process of using CARLA to train a neural network for steering control, applicable for validating system behavior under manipulated CAN conditions.

# Recommendations

This paper is a valuable addition to your thesis literature as it offers practical insights into using CARLA for autonomous driving development, data collection, and control testing. I recommend citing it for its detailed guidance on using the CARLA environment for model development and testing.

---

# Annotations  
(11/4/2024, 12:48:29 PM)

[Go to annotation](zotero://open-pdf/library/items/EWWQMTST?page=3&annotation=EMB4VCEQ) “CARLA is an open-source simulator built on top of the Unreal Engine 4 (UE4) gaming engine, with additional materials and features providing: a LIDAR a depth map (emulating a stereo camera, e.g.: ZED or Intel’s D435) semantic segmentation data two (and soon to be three) towns with pedestrians, other cars, traffic lights, speed limits, and realistic layout a repository and data for imitation learning a repository for testing out reinforcement learning models an option of running without display But more importantly, CARLA is thriving; it has a great community, it’s documented well, and it’s (subjectively) easy to use.” ([Dziubiński, 2018, p. 3](zotero://select/library/items/Y2WF39X6)) CARLA