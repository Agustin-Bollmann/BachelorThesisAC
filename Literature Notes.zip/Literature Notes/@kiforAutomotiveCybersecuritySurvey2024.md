---
title: "Automotive Cybersecurity: A Survey on Frameworks, Standards, and Testing and Monitoring Technologies"
authors: Claudiu Vasile Kifor, Aurelian Popescu
year: 2024
---

# Automotive Cybersecurity: A Survey on Frameworks, Standards, and Testing and Monitoring Technologies
##### Claudiu Vasile Kifor, Aurelian Popescu (2024)
[Zotero-Link](zotero://select/items/@kiforAutomotiveCybersecuritySurvey2024)

Tags: #EE #History #ECU #ABS #SAE #SAEJ3061 #UNR155 #OEM #CSMS #ISO #ISO21434 #ISO26262 #ISO21448 #SecOC #AUTOSAR #IoT #MQTT #OTA #TLS #Firewall #Spoofing #MITM #Norms #ISO24089 #SUMS #GPS #IDS #VANET #SAIDuCANT #TARA #ISO27001 #TISAX #IVN #TOUCAN #IDHCAN #SecOC #AUTOSAR #NSKUP #LiBrACAN #HARA 

>[!ABSTRACT]-
>Modern vehicles are increasingly interconnected through various communication channels, which requires secure access for authorized users, the protection of driver assistance and autonomous driving system data, and the assurance of data integrity against misuse or manipulation. While these advancements offer numerous benefits, recent years have exposed many intrusion incidents, revealing vulnerabilities and weaknesses in current systems. To sustain and enhance the performance, quality, and reliability of vehicle systems, software engineers face significant challenges, including in diverse communication channels, software integration, complex testing, compatibility, core reusability, safety and reliability assurance, data privacy, and software security. Addressing cybersecurity risks presents a substantial challenge in finding practical solutions to these issues. This study aims to analyze the current state of research regarding automotive cybersecurity, with a particular focus on four main themes: frameworks and technologies, standards and regulations, monitoring and vulnerability management, and testing and validation. This paper highlights key findings, identifies existing research gaps, and proposes directions for future research that will be useful for both researchers and practitioners.


---

# Summary

- The paper surveys the current state of automotive cybersecurity, focusing on **frameworks, standards, monitoring technologies**, and **vulnerability management**. It covers recent advancements like the **ISO/SAE 21434** and **UN Regulation R155**, which provide guidelines for cybersecurity management in vehicles.
- The study emphasizes the importance of integrating **cybersecurity measures** throughout the vehicle development lifecycle, from concept to decommissioning, and the challenges faced by **Original Equipment Manufacturers (OEMs)** in adapting their systems to these new standards.
- It also discusses **testing and validation technologies** such as **model-based testing** and **fuzz testing**, outlining the limitations and benefits of each method, and highlighting the need for real-time, secure communication protocols like **SecOC (Secure Onboard Communication)**.

# Relevancy

- **Provides an Overview of Standards**: The paper's detailed explanation of automotive cybersecurity standards like ISO/SAE 21434 and UN R155 aligns well with your need to base your CAN traffic manipulation experiments within recognized regulatory frameworks.
- **Discusses Testing and Monitoring**: The focus on testing and validation technologies directly supports your thesis objective of developing and testing CAN traffic manipulation strategies using simulation environments like CARLA.
- **Covers Emerging Threats and Solutions**: The survey of emerging threats and the importance of secure communication offers foundational knowledge for understanding attack vectors and developing new mitigation techniques.

# Notable Sections and Pages

- **Section 3.1: Frameworks and Technologies (Pages 5-7)**: Describes different cybersecurity frameworks and technologies, including SecOC, which is relevant for understanding CAN traffic security measures.
- **Section 3.3: Monitoring and Vulnerability Management (Pages 9-12)**: Provides insights into monitoring technologies and vulnerability management strategies applicable to your work on testing CAN vulnerabilities.
- **Section 3.4: Testing and Validation (Pages 13-15)**: Discusses various testing methods like fuzz testing, which are directly relevant for structuring your experiments and simulations.
- **Section 4: Standards and Regulations (Pages 16-20)**: Reviews standards such as ISO/SAE 21434, offering a regulatory context for your thesis.

# Recommendations

This paper is an excellent addition to your thesis literature. It provides a structured overview of the current automotive cybersecurity landscape, standards, and testing technologies, all of which are crucial for your work on manipulating and testing CAN traffic. I recommend citing it for its comprehensive analysis of standards and testing methods.

---

# Annotations  
(11/3/2024, 2:52:36 PM)

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=1&annotation=WFFUFQNQ) “Over the last 40 years, cars have undergone significant transformations to meet quality, environmental, and safety requirements, as well as to satisfy customer expectations for performance, comfort, and driver assistance. In the 1980s, core electrical systems were introduced alongside anti-lock braking systems (ABSs) and airbags. Between the 1990s and early 2000s, vehicles saw a rise in electronic control units (ECUs) within their electrical architecture, driven by a focus on production efficiency and maintenance, as well as a desire for car customization through functional features. These features could later be updated by replacing ECUs or certain sensors and actuators. As time progressed, the electrical and electronic (E/E) architecture became decentralized. Safety and comfort functions were separated, and vehicle functions were distributed among many interconnected ECUs. Each ECU was capable of processing its own data and communicating with others to implement advanced functionalities [1]. In the late 2000s and early 2010s, connected and autonomous vehicle functions were introduced, transforming vehicle systems from isolated entities into open systems capable of exchanging information with the environment, drivers, and other traffic participants. This shift led to a significant increase in the complexity of the E/E architecture with each electrical subsystem, such as braking, steering, propulsion, infotainment, and connectivity systems, incorporating between two and ten ECUs. These subsystems also began to utilize various communication protocols, including LIN, CAN, FlexRay, and MOST [2]. By the 2010s, advanced driver assistance systems (ADASs) had entered the market, featuring Sensors technologies such as emergency braking systems, lane-keeping assist systems, park assist systems, predictive forward collision warning systems, and autopilot functionality.” ([Kifor and Popescu, 2024, p. 1](zotero://select/library/items/XKNCGR65)) 

EE, History, ECU, ABS

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=2&annotation=XJIZK2X7) “In 2016, the Society of Automotive Engineers (SAE) published SAE J3061, a guideline for developing secure automotive systems [8]. One of the key principles of this guideline is that cybersecurity must be integrated into the design of features from the outset, rather than being appended at the end of the development process.” ([Kifor and Popescu, 2024, p. 2](zotero://select/library/items/XKNCGR65)) 

SAE, SAE J3061

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=2&annotation=869KXSCI) “In 2021, the World Forum for Harmonization of Vehicle Regulations, a working group within the Sustainable Transport Division of the United Nations Economic Commission for Europe, published UN Regulation No. 155 [9]. According to this regulation, each OEM must establish and maintain a Cyber Security Management System (CSMS) to address organizational processes, responsibilities, and governance related to cybersecurity. The goal is to protect vehicles from cyber threats and attacks. OEMs are required to identify risks associated with vehicle technologies and implement measures to safeguard against them. These risk management processes must be demonstrated when OEMs seek vehicle type approval from validation authorities.” ([Kifor and Popescu, 2024, p. 2](zotero://select/library/items/XKNCGR65)) 

UNR155, OEMs, CSMS

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=2&annotation=DAK87SEW) “The engineering requirements for managing cybersecurity risks across the concept, product development, production, operation, maintenance, and decommissioning phases of E/E systems in road vehicles are detailed in the ISO/SAE 21434:2021 standard [10]. Starting in July 2024, this standard will apply to all newly manufactured vehicles. A key challenge for OEMs is integrating the new CSMS into the traditional automotive software development lifecycle. In the initial phase of implementing the standard, the CSMS will likely be added as an “add-on” to existing tools. Over time, automotive companies will develop solutions to more seamlessly integrate it into their development processes, similar to how safety requirements under ISO 26262 were eventually integrated [11].” ([Kifor and Popescu, 2024, p. 2](zotero://select/library/items/XKNCGR65))

ISO, ISO21434, 26262

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=2&annotation=TIXTUUIU) “However, to support the development of autonomous vehicles, safety processes need to be updated. To address this, the ISO 21448:2022 standard (Road vehicles—Safety of the intended functionality) [13] was created.” ([Kifor and Popescu, 2024, p. 2](zotero://select/library/items/XKNCGR65)) 

ISO 21448

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=7&annotation=6NUHD4NM) “Secure Onboard Communication (SecOC) The AUTomotive Open System ARchitecture (AUTOSAR) partnership created and established an open and standardized software architecture for automotive ECUs [54]. In 2017, the first specification for secure onboard communication (SecOC) [55] was released, describing a practical approach of how secure in-vehicle communication can be achieved. Instead using a shared key between sender and all receivers, a secret pair consisting of a public key and a secret key is used. In this way, the receiver has the possibility to check the authenticity of sender and also the integrity of the received data. Nowadays, SecOC is implemented by almost all OEMs, and SecOC is used not for all CAN messages, but only for safety-critical and cybersecurity-relevant messages. SecOC implementation requires periodic resynchronization phases, and its implementation across various embedded systems demands significant computational power. Later on, similar specifications were released over AUTOSAR group for secure hardware extensions, crypto stack, secure diagnostics [56] and secure logging, identity and access management, intrusion detection system manager [57], secure updates, and trust platforms.” ([Kifor and Popescu, 2024, p. 7](zotero://select/library/items/XKNCGR65)) 

SecOC, AUTOSAR, OEMs

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=8&annotation=RNZLYTDU) “The Internet of Things is increasingly being integrated into the automotive industry, primarily through intelligent sensors [58]. Designed to be lightweight, Message Queue Telemetry Transport (MQTT) was the easiest IoT data communication protocol adopted in the automotive sector. Previous studies analyzed the impact of adding the Transport Layer Security (TLS) protocol to MQTT communication, with positive results observed in networks with lower busloads [59]. The implementation of TLS and MQTT in automotive networks permit now the secure software update Over-The-Air. Shin et al. [60] propose a novel firmware over-the-air (OTA) update method, MQTree, which combines the MQTT protocol with Merkle tree-based blockchain verification to enhance the efficiency of software updates. The study demonstrates that MQTree performs well against spoofing, man-in-the-middle, and duplicate update attacks. However, to address denial-of-service threats, the addition of a firewall to the system is necessary.” ([Kifor and Popescu, 2024, p. 8](zotero://select/library/items/XKNCGR65)) 

IoT, MQTT, OTA, TLS, Firewall, Spoofing, MITM

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=9&annotation=9NXGFKX6) “tive applications [71]. Its primary goal is to establish a uniform approach for OEMs to address safety considerations. The increasing complexity of high connectivity interfaces, shared services, and advanced autonomous vehicle features has necessitated a shift in the development of the E/E systems, emphasizing the need for enhanced cybersecurity measures. In 2018, a revised version of ISO 26262 [11] was released, introducing significant updates such as improved management of safety anomalies, more detailed objectives, references to cybersecurity, and additional requirements for trucks, buses, and trailers. This was preceded by the introduction of SAE J3061 in January 2016, the first global cybersecurity standard for the automotive industry [8].” ([Kifor and Popescu, 2024, p. 9](zotero://select/library/items/XKNCGR65)) 

ISO

![](PBK2AL96.png)  
>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=9&annotation=PBK2AL96)  
([Kifor and Popescu, 2024, p. 9](zotero://select/library/items/XKNCGR65)) 

Norms

![](2PCIPUCW.png)  
>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=10&annotation=2PCIPUCW)  
([Kifor and Popescu, 2024, p. 10](zotero://select/library/items/XKNCGR65))

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=10&annotation=7L6KDJCW) “The introduction of ISO 24089 aims to transform the management of software updates within the automotive sector [82]. Alongside ISO 24089, UN Regulation No. R156 [78] has established a more standardized approach to software update requirements through the Software Update Management System (SUMS). Schober et al. [89] reviewed the current state of automotive cybersecurity regulations and standards, highlighting the connections and interdependencies among them.” ([Kifor and Popescu, 2024, p. 10](zotero://select/library/items/XKNCGR65)) 

ISO24089, SUMS

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=10&annotation=WLYC2WAN) “IDS functionalities can be implemented either as a separate or dedicated ECU, within the vehicle network (network-based IDS). This could involve a cloud-based software solution that receives data from the vehicle’s telematics ECU [92] (cloud network-based IDS), or a software module embedded in one or more high-performance ECUs within the vehicle (host-based IDS) [93]. Currently, OEMs are more inclined to deploy dedicated ECU IDS versions. In terms of attack detection methods, IDS systems are categorized into signature-based or anomaly-based systems [94]. Signature-based IDS utilize a database of known attack signatures and monitor permissible data exchanges between ECUs. This database requires regular updates, as does the information regarding allowed data exchanges following any ECU software updates. Anomaly-based IDS, on the other hand, monitor changes in physical properties (e.g., voltage, current, busload) of in-vehicle network communications [95,96], or detect anomalies in functional signal values (e.g., GPS signal jumps indicative of spoofing attacks) [97].” ([Kifor and Popescu, 2024, p. 10](zotero://select/library/items/XKNCGR65)) 

GPS, Spoofing, IDS

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=11&annotation=LYZFYE56) “Researchers are also focusing on in-vehicle network IDS as a robust defense mechanism against automotive attacks [98]. IDS solutions are being explored for Vehicular Ad-hoc Network (VANET) systems [99], including flow-based IDS that are sensitive to timing and frequency changes of messages, and payload-based IDS that detect modifications to message content [100]. Furthermore, algorithms are being developed to generate realtime model parameters for specific CAN buses, enabling specification-based IDS using anomaly-based supervised learning with real-time models (SAIDuCANT) [101].” ([Kifor and Popescu, 2024, p. 11](zotero://select/library/items/XKNCGR65)) 

VANET,  SAIDuCANT

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=11&annotation=GQBB6NUS) “New regulations are requesting OEMs to establish dedicated vehicle security teams responsible for monitoring all sold vehicles and addressing new vulnerabilities discovered in their software. The study referenced in [106] identifies commonalities and differences between Security Operation Centers (SOC) in IT and Vehicle Security Operation Centers (VSOC). It highlights that methods, procedures, and technical solutions from IT SOCs cannot typically be applied directly to VSOCs due to their unique requirements.” ([Kifor and Popescu, 2024, p. 11](zotero://select/library/items/XKNCGR65))

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=11&annotation=IQW6FX9V) “Wang et al. [109] propose a systematic risk assessment framework that includes a specific risk assessment process and systematic methods. This framework has a similar structure with TARA process mentioned in ISO 21434 [10], and it is based on three standard blocks: risk identification; risk analysis; and risk assessment, that are applicable across all phases of the vehicle lifecycle. Zhang et al. conducted a case study focusing on threat analysis, test item determination, and vulnerability scoring, which are essential components of a comprehensive TARA procedure [110]. Dobaj et al. carried out a case study on risk-driven system design and the development of cybersecurity requirements [111]. This study complements the standard and offers engineers a practical guide for developing secure systems. Prior to initiating TARA, preliminary steps must be taken, including identifying system assets and associated risks through structured approaches.” ([Kifor and Popescu, 2024, p. 11](zotero://select/library/items/XKNCGR65)) 

TARA

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=12&annotation=NGN7LGG2) “The Trusted Information Security Assessment Exchange (TISAX) certification, which is adapted from ISO 27001 [113], serves as a European automotive industry standard for “information security assessment” (ISA). It focuses on key aspects of information security, such as data protection and third-party connections [114]. The term TISAX did not appear in our bibliographic research because it is associated with “security” rather than “cybersecurity” within the automotive context. The implementation methods and benefits of TISAX were analyzed in [115]. A new version of TISAX is expected to be released in 2024.” ([Kifor and Popescu, 2024, p. 12](zotero://select/library/items/XKNCGR65)) 

ISO27001, TISAX

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=12&annotation=SUQH2MCL) “To further bolster the cybersecurity of IVNs, various secure communication protocols have been proposed and validated, including TOUCAN and IDH-CAN [18,122–126]. TOUCAN (proTocol tO secUre Controller Area Network) was designed to secure CAN communication [122]. An improved version of TOUCAN, called CINNAMON (Confidential, INtegral aNd Authentic on board co-MunicatiON), was proposed to be compatible with AUTOSAR and addresses confidentiality issues that SecOC does not [127,128].” ([Kifor and Popescu, 2024, p. 12](zotero://select/library/items/XKNCGR65)) 

IVN, TOUCAN, IDHCAN, SecOC, AUTOSAR

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=12&annotation=AEJWDHPK) “Identification Hopping CAN (IDH-CAN) is another hardware and software solution that ensures both communication security and real-time application constraints. It introduces a hardware firewall between the physical and data link layers. However, implementing IDH-CAN in existing vehicle architectures can be challenging, as it requires simultaneous updates to all hardware CAN drivers [124].” ([Kifor and Popescu, 2024, p. 12](zotero://select/library/items/XKNCGR65))

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=12&annotation=WN62MZ3N) “Palaniswamy et al. developed a new secure CAN protocol suite that includes a session key update protocol (NSKUP) to prevent key reuse [18,125]. While NSKUP requires significant computational resources and introduces time delays, Groza et al. introduced a lightweight broadcast authentication (LiBrA-CAN) protocol as a more resource-efficient alternative [129].” ([Kifor and Popescu, 2024, p. 12](zotero://select/library/items/XKNCGR65)) 

NSKUP. LiBrACAN

>[Go to annotation](zotero://open-pdf/library/items/VLVB9I6P?page=13&annotation=3LENN8GX) “Risk management during the development phase is handled similarly for safety and cybersecurity, using HARA (Hazard Analysis and Risk Assessment) for safety and TARA for cybersecurity [10]. Some studies suggest that integrating safety and security risk management, including shared processes and documentation, could provide a better overview of product risks and potentially reduce costs [52,84,112].” ([Kifor and Popescu, 2024, p. 13](zotero://select/library/items/XKNCGR65)) 

HARA