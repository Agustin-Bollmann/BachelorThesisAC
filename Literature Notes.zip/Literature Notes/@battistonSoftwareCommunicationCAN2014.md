---
title: Software in C++ for communication between CAN bus and ROS in a robot vehicle
authors: Alex Battiston
year: 2014
---

# Software in C++ for communication between CAN bus and ROS in a robot vehicle
##### Alex Battiston (2014)
[Zotero-Link](zotero://select/items/@battistonSoftwareCommunicationCAN2014)

Tags: #CAN #Frames #DataFrame #RemoteFrame #SAE #SAEJ1939 #ISO #ISO15765 #CANopen #CANFrame #ROS #IPC #ROSLevel #CANMessage

>[!ABSTRACT]-
>


---

# Summary

- The thesis focuses on developing C++ software to manage real-time communication between the CAN bus and ROS for a robot vehicle, specifically an **all-terrain vehicle (ATV)** modified for autonomous functionality. The software integrates sensor data and translates it into commands for vehicle control via ROS.
- The work emphasizes using **mutexes and condition variables** to optimize CAN message sending and receiving, ensuring efficient data exchange. Various software versions were tested to determine the most effective approach.
- It also covers the technical architecture of CAN and J1939 protocols, hardware components such as LiDAR and the Kvaser Leaf Light HS, and the implementation of Ackermann steering geometry for precise vehicle control.

# Relevancy

- **Details CAN-ROS Communication**: The focus on establishing efficient communication between CAN and ROS directly supports your goal of using simulation environments like CARLA for testing CAN traffic manipulation and integrating tools like CANToolz.
- **Explores Real-Time Control Techniques**: The use of mutexes and condition variables for CAN communication provides insights into optimizing your experimental setup for real-time message manipulation.
- **Highlights CAN Protocol Implementation**: The detailed implementation of CAN and J1939 protocols offers foundational knowledge for structuring your experiments involving CAN traffic.

# Notable Sections and Pages

- **Chapter 3: CAN Bus and J1939 (Pages 17-27)**: Provides an in-depth look at CAN communication and the J1939 protocol, critical for understanding the technical aspects of CAN traffic manipulation.
- **Chapter 5: Communication (Pages 35-41)**: Explains how the software interfaces with ROS, which is valuable for designing communication modules in your experiments.
- **Chapter 6: Implementation (Pages 41-45)**: Discusses the implementation of CAN communication in C++, providing insights into setting up and managing CAN-ROS communication effectively.

# Recommendations

This thesis is a valuable addition to your literature as it offers practical implementation details for CAN-ROS communication, which is directly applicable to your work on autonomous vehicle simulation and testing. I recommend citing it for its technical insights into the integration of CAN and ROS in real-time systems.

---

# Annotations  
(11/3/2024, 8:11:16 PM)

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=19&annotation=IGL3B7XE) “CAN bus communication for in-vehicle networks is very widespread because it is simple, efficient and robust. CAN, which stands for Controller Area Network, is a low-level serial data communication protocol for embedded realtime applications internationally standardized by International Standardization Organization (ISO). The Controller Area Network was developed in the mid 1980s by Bosch GmbH, to provide a cost-effective communications bus for automotive applications, but is used also in factory and plant controls, in robotics, medical devices and also in some avionics systems. The communication between controllers, sensors and actuators uses CAN bus that allows all devices to be connected with any other device on a common serial bus.” ([Battiston, 2014, p. 19](zotero://select/library/items/62VELHAW)) 

CAN

![](HLD8SXMF.png)  
>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=23&annotation=HLD8SXMF)  
([Battiston, 2014, p. 23](zotero://select/library/items/62VELHAW))

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=23&annotation=MNDXIQQX) “The CAN controller determines the level of a bus by potential difference in two wires that comprise the bus with a logic high as the recessive state and a logic low as the dominant state. On a single CAN bus any node can transmit data and it is allowed to every node to listen and transmit at the same time, when two or more nodes attempting transmission, messages are transmitted one after another according to their priority. The CAN controller of each node monitors the bus as it transmits and, consequently, can detect if another node wins arbitration. If the bus is active (a node is transmitting or has just finished transmission), the other nodes will not attempt transmission. If, when the bus is idle (for at least the length of the interframe spacing), and more than one node begins transmission, arbitration occurs transparently and nondestructively. Nondestructive arbitration means that the node winning arbitration can simply continue transmission of its message without any other node having interfered with the message transmission. The highest priority message has an arbitration field of the highest number of dominant bits: it will transmit a dominant bit first, while the other nodes are transmitting recessive bits. Also known as the identifier (ID), the arbitration field prioritizes the messages on the bus. All nodes transmit a single dominant bit when starting a message. This is the start of message (SOM) bit. Any node just listening will see bus activity and will not attempt to start a transmission until the current packet is complete. So the only possibility for collision is between nodes that simultaneously send a SOM bit. These nodes will remain synchronized for the duration of the packet or until one of them backs off. After the SOM bit, the arbitration field is transmitted. If multiple nodes start transmitting at the same time, then the node with the message with the higher numeric CAN Identifier will win arbitration and continue to send its message. The other nodes will cease transmitting and must wait until the bus becomes idle again before attempting to re-transmit their messages after the current message is completed. In this second attempt, the next highest value arbitration field will take control of the bus. All nodes transmit a single dominant bit when starting a message. The highest priority message always gets through, but at the expense of the lower-priority messages. Thus, CAN’s real-time properties are analogous to the properties of a preemptive real-time kernel on a single processor. In both cases, the goal is to ensure that the highest-priority work gets completed as soon as possible. The CAN standard does not indicate the meaning of those bits, but the many higher-level protocols that sit on top of CAN do define them. For example, the J1939 standard allows one portion of the bits to be a destination address, since the CAN protocol itself specifies a source address for all packets, but doesn’t mandate a destination address. This is quite reasonable since much of the traffic on an automotive bus consists of broadcasts of measured information, which is not destined for one specific node.” ([Battiston, 2014, p. 23](zotero://select/library/items/62VELHAW))

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=24&annotation=AF9CQVJ9) “The data and the remote frames come in two frame formats: standard and extended. The standard format has a 11-bit ID (CAN 1.0, 2.0A (standard CAN)) and the extended format has a 29-bit ID (2.0B (extended CAN)). Frame types, roles and user settings of each frame are in these list. • Data frame: the frame is used by the transmit unit to send a message to the receive unit. User setting necessary. • Remote frame: the frame is used by the receive unit to request transmission of a message that has the same ID from the transmit unit. User setting necessary • Error frame: when an error is detected, this frame is used to notify other units of the detected error. User setting unnecessary. • Overload frame: it is used by the receive unit to notify that it has not been prepared to receive frames yet. User setting unnecessary. • Interframe space: used to separate a data or remote frame from a preceding frame. User setting unnecessary.” ([Battiston, 2014, p. 24](zotero://select/library/items/62VELHAW)) 

Frames

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=24&annotation=5PNHU9BT) “CAN bus protocol uses asynchronous data transmission design. The transmitted data is sent in a data frame, which is controlled by start and stop bits at the beginning and end of each transmission.” ([Battiston, 2014, p. 24](zotero://select/library/items/62VELHAW)) 

Data Frame

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=25&annotation=P8SPTDEW) “This frame is used by the receive unit to request transmission of a message from the transmit unit. The remote frame consists of six fields. The remote frame is the same as a data frame except that it does not have a data field. The differences between a Data Frame and a Remote Frame is that the RTR bit is transmitted as a dominant bit in the Data Frame and recessive in Remote Frame and Remote Frame there is not Data Field.” ([Battiston, 2014, p. 25](zotero://select/library/items/62VELHAW)) 

Remote Frame

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=25&annotation=B7BILCDP) “The J1939 protocol is an application layer built on top of the CAN standard developed by the Truck & Bus Control and Communications Network Subcommittee of the Society of Automotive Engineers (SAE). J1939 is one of three major CAN high level protocols, with the other two being ISO 15765 and CANopen. The J1939 standard is used in many applications, including automotive, agricultural and construction equipment. Planned for use in light, medium and heavy-duty trucks, it is also now being used in conventional passenger vehicles. SAE J1939 defines five layers of the seven-layer OSI network model and includes the Controller Area Network (CAN) 2.0b specification (using only the 29-bit / extended identifier) for the physical and data-link layers (the session and presentation layers are not part of the specification).” ([Battiston, 2014, p. 25](zotero://select/library/items/62VELHAW)) 

SAE, J1939, ISO 15765, CANopen

![](QTUIQMZI.png)  
>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=26&annotation=QTUIQMZI)  
([Battiston, 2014, p. 26](zotero://select/library/items/62VELHAW)) 

CANFrameFormat

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=37&annotation=EJEP2236) “ROS (Robot Operating System) is a open source operating system for controlling robotic components. With a large a set of libraries, ROS is used for creating programs that communicate efficiently, and with a flexible and simply data structures. ROS provides standard operating system services such as hardware abstraction, low-level device control, implementation of commonly used functionality, message-passing between processes and package management. In Figure 22 has shown the level of ROS is in the same level of the application and it is the interface between hardware and IPC (Inter-Process Communication). The fundamental concepts of the ROS implementation are nodes, messages, topics and services [24]. • Nodes: A node is an instance of an executable and can be a sensor, actuator, processing or monitoring algorithm. • Messages: A message is a typed data structure made up with primitive types like (integer, floating point, boolean, etc.), arrays of primitives and constants. Nodes communicate with each other by passing messages. • Topic: A topic is a asynchronous data transport system based on a subscribe/publish system and is identified by a name. One or more nodes are able to publish data (messages) to a topic and one or more nodes can read data on that topic. Data is exchanged asynchronously by means of a topic and via a service. • Services: A services allows to communicate nodes each other with a synchronously communication. With service nodes are able to send a request and receive a response. ROS starts with the ROS master. Master allows to all other ROS instances (nodes) to find and talk each other, a node which wants to send a message to another node needs simply asking to master to send the message without specifying any address. Examples of Topic and Services are in Appendix B.” ([Battiston, 2014, p. 37](zotero://select/library/items/62VELHAW)) 

ROS, IPC

![](CI42HJDD.png)  
>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=38&annotation=CI42HJDD)  
([Battiston, 2014, p. 38](zotero://select/library/items/62VELHAW)) 

ROS Level

>[Go to annotation](zotero://open-pdf/library/items/4IQHXDEB?page=39&annotation=IQXT22AJ) “The CAN packet will be sent or receive in the CAN bus from the software is a variable of type CanMsg with the fields id, id_type, length and data. In Appendix A Listing 1 the structure of CAN messages used during the exchange of information between the Acrosser and CAN bus. id: This field holds the ID information of the CAN packet. In a ’Standard Data Frame’ CAN packet, the ID field consists of 11 bits of binary digitals. In an ’Extended Data Frame’ CAN packet, the ID field consists of 29 bits of binary digitals. CAN packet can be a ’Standard Data Frame’ packet or an ’Extended Data Frame’ packet is determined by the ’id_type’ field in the CanMsg variable. id_type: This field identifies if CAN packet is a ’Standard Data Frame’ CAN packet, Listing 2, or a ’Extended Data Frame’ CAN packet, Listing 3. data[8]: ’data’ field is an 8-byte long array, the range of this field ’length’ is 0 - 8 and it is filled with effective data. length: This field identifies the number of data bytes in the field ’data[8]’. 5.3.2 sendCanMessage The prototype of the function sendCanMessage receive as parameter the address of the variable of type CanMsg. The function returns the result of the operation, zero if the operation has not completed with successful otherwise a number different from zero. In Listing 4 the definition of the function sendCanMessage. 5.3.3 getCanMessage The prototype of the function getCanMessage receives as parameter the address of the variable of type CanMsg and a integer number that represents the amount of CAN messages that the function will get from the CAN bus. The function returns the result of the operation, zero if the operation hasn’t completed with successful otherwise a number different from zero. In Listing 4 the definition of the function getCanMessage.” ([Battiston, 2014, p. 39](zotero://select/library/items/62VELHAW)) 

CANMessage


