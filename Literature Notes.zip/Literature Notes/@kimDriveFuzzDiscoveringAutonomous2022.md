---
title: "DriveFuzz: Discovering Autonomous Driving Bugs through Driving Quality-Guided Fuzzing"
authors: Seulbae Kim, Major Liu, Junghwan "John" Rhee, Yuseok Jeon, Yonghwi Kwon, Chung Hwan Kim
year: 2022
---

# DriveFuzz: Discovering Autonomous Driving Bugs through Driving Quality-Guided Fuzzing
##### Seulbae Kim, Major Liu, Junghwan "John" Rhee, Yuseok Jeon, Yonghwi Kwon, Chung Hwan Kim (2022)
[Zotero-Link](zotero://select/items/@kimDriveFuzzDiscoveringAutonomous2022)

Tags: #Perception #LiDAR #Fuzzing #DriveFuzz #Autoware #CARLA #Architecture #Planning #Actuation #Attackers #ExternalInputs #Collision #Infraction #Immobility #ROS #AVFuzzer #PlanFuzz 

>[!ABSTRACT]-
>Autonomous driving has become real; semi-autonomous driving vehicles in an affordable price range are already on the streets, and major automotive vendors are actively developing full self-driving systems to deploy them in this decade. Before rolling the products out to the end-users, it is critical to test and ensure the safety of the autonomous driving systems, consisting of multiple layers intertwined in a complicated way. However, while safety-critical bugs may exist in any layer and even across layers, relatively little attention has been given to testing the entire driving system across all the layers. Prior work mainly focuses on white-box testing of individual layers and preventing attacks on each layer.


---

# Summary

- The paper introduces **DriveFuzz**, a feedback-driven fuzzing framework designed for **autonomous driving systems (ADS)**. DriveFuzz focuses on **holistic testing** by examining vehicle states across all layers of an ADS, rather than isolating individual layers.
- The framework leverages a **high-fidelity driving simulator** (CARLA) to generate and mutate driving scenarios, testing the ADS as a whole. It incorporates **driving quality metrics** to guide the fuzzing process toward identifying bugs that lead to safety-critical misbehaviors.
- DriveFuzz successfully identified **34 bugs** in two ADS systems (Autoware and CARLA's Behavior Agent), demonstrating the effectiveness of the framework in revealing critical vulnerabilities.

# Relevancy

1. **Utilizes Simulation-Based Testing**: The use of CARLA and driving quality-guided fuzzing aligns with your objective of testing CAN traffic manipulation and autonomous vehicle vulnerabilities in a simulation environment.
2. **Provides Practical Testing Examples**: The focus on testing full-stack ADS systems like Autoware directly supports your experiments involving CAN traffic manipulation in similar simulation setups.
3. **Emphasizes Vulnerability Identification**: The comprehensive approach of DriveFuzz in discovering bugs across various components of ADS systems could be leveraged in your own testing methodology.

# Notable Sections and Pages

- **Section II: Background and Threat Model (Pages 3-5)**: Discusses the multi-layer structure of ADS and potential attack surfaces, providing a theoretical foundation for understanding vulnerabilities in CAN manipulation.
- **Section IV: DriveFuzz Architecture (Pages 6-8)**: Details the design and components of DriveFuzz, which is valuable for developing your own framework for manipulating and testing CAN traffic in CARLA.
- **Section VI: Evaluation (Pages 10-12)**: Explains the results of testing Autoware and the Behavior Agent, demonstrating the framework's effectiveness and providing practical insights for your experiments.

# Recommendations

This paper is an excellent addition to your thesis literature. It provides a structured and innovative approach to fuzz testing ADS systems using simulation, offering valuable methodologies and results that can support your research on CAN traffic manipulation. I recommend citing it for its comprehensive testing framework and practical applications with tools like CARLA.

---

# Annotations  
(11/1/2024, 3:40:28 PM)

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1753&annotation=XR54VMZM) “To ensure the safety of autonomous driving, existing work has focused on individual layers of an ADS. Specifically, the security research community has been extensively focusing on finding adversarial examples on the perception layer [13, 17, 24, 39, 58, 76, 78, 80], assuming a threat model in which an attacker attempts to confuse the machine learning model by supplying a deceptive driving scene (e.g., modifying a traffic sign) or spoofing sensor data (e.g., injecting falsified LiDAR points).” ([Kim et al., 2022, p. 1753](zotero://select/library/items/PCMRU8TH)) 

perception, LiDAR, fuzzing

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1754&annotation=TMB4KZNY) “Based on these insights, we propose DriveFuzz, a feedbackguided fuzzing framework for end-to-end testing of ADSes leveraging a driving simulator (CARLA [28]). DriveFuzz plugs a target ADS into the fuzzing framework and tests the self-driving system stack as a whole to facilitate the test coverage to span all layers. It generates and mutates driving scenarios in which the ADS has to drive from one point to another, and simulates them in a threedimensional virtual environment (similar to a racing video game), where it has full control over both spatial and temporal dimensions of the input spaces as well as multiple actors and entities including the roads, pedestrians, and vehicles.” ([Kim et al., 2022, p. 1754](zotero://select/library/items/PCMRU8TH)) 

DriveFuzz

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1754&annotation=8EN558UA) “We evaluate DriveFuzz by testing Autoware [44, 45], which is a full-fledged (Level 4 [25]) ADS extensively used by car manufacturers and academic institutions [5], and Behavior Agent, which is a native ADS integrated into CARLA. To date, DriveFuzz discovered a total of 34 critical bugs; 33 of which are new bugs, including 17 in Autoware, 13 in Behavior Agent, and 3 simulation bugs in CARLA. We have reported all 34 bugs to the developers, and 10 have been confirmed and being patched, and others are under review. Our discovery of the simulation bugs shows that DriveFuzz is capable of finding bugs in both single and multiple layers of the software stack, including various components for self-driving and even the simulator itself. We observe and demonstrate that the bugs we found are realistic and practical to exploit; that is, attackers can exploit them by controlling the external inputs in a seemingly legitimate way (e.g., moving nearby objects).” ([Kim et al., 2022, p. 1754](zotero://select/library/items/PCMRU8TH)) 

Autoware, CARLA, Fuzzing

![](L34CBGMN.png)  
>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1755&annotation=L34CBGMN)  
([Kim et al., 2022, p. 1755](zotero://select/library/items/PCMRU8TH)) 

Architecture

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1755&annotation=UPN2K7S5) “A general autonomous driving system (ADS) consisting of sensing, perception, planning, and actuation layers. By taking the vehicle states and environment perceived by sensors, a 3D map, and a destination as inputs, ADS ultimately outputs control commands, i.e., steering, throttle and brake controls, that in turn update the vehicle states for the next iteration of the loop.” ([Kim et al., 2022, p. 1755](zotero://select/library/items/PCMRU8TH)) 

Architecture

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1755&annotation=EMP2E4DF) “Perception modules fuse and interpret the captured sensor data to comprehend the current standing and the environment around a vehicle. For example, identifying the traffic signals ahead or predicting the motion of adjacent vehicles by assessing their velocities belongs to the tasks of the perception layer. Many systems leverage various computer vision and machine learning techniques for such tasks. A perception error can mislead the vehicle to make faulty decisions, e.g., estimating the distance to an obstacle to be farther than the actual distance, ending up hitting it. Planning. With the perceived internal and external states, the planning layer makes a routing plan for the given map and the destination. Generally, it first computes a global trajectory consisting of a sequence of waypoints from the initial position to the destination the user specifies. And then, traffic rules and perceived states (e.g., nearby obstacles) are taken into account by a local planner, which updates the trajectory at runtime to safely drive to the destination. Errors in this layer can cause not only inefficient but also unsafe routing that involves infeasible paths, e.g., crossing a river. Actuation. Given the generated trajectory to follow, the actuation layer sets up a concrete motion plan consisting of a steering wheel angle, a target speed at waypoints, and the amount of throttling or braking, to seamlessly follow the trajectory. These commands are sent to the steering wheel, throttle, and brake controllers to move an autonomous vehicle as planned. When the commands move the vehicle in the driving environment, the vehicle states are changed and observed by the sensing layer in the following iteration of the loop. Thus, an error in the actuation layer can critically impair the vehicle’s ability to properly maneuver in a given situation and may also affect other layers in the loop by changing the vehicle states.” ([Kim et al., 2022, p. 1755](zotero://select/library/items/PCMRU8TH)) 

Perception, Planning, Actuation

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1755&annotation=XI6GZ4NU) “We do not assume that the attacker takes control over the ADS physically (e.g., attach a device via an OBD-II port) or remotely (e.g., perform remote code execution) to exploit a vulnerability. Instead, the attacker only has control over the external inputs such as nearby objects or locations (e.g., moving a nearby vehicle) with a goal to cause critical misbehavior of the autonomous vehicle (e.g., a crash, lane invasion, traffic violations, or becoming immobile). These external inputs are legitimate and authentic inputs to the ADS, as opposed to maliciously crafted inputs by adversarial attacks (e.g., sensor spoofing) or synthetically generated driving scenes.” ([Kim et al., 2022, p. 1755](zotero://select/library/items/PCMRU8TH)) 

attackers controlling external inputs

![](HMCMI5GE.png)  
>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1756&annotation=HMCMI5GE)  
([Kim et al., 2022, p. 1756](zotero://select/library/items/PCMRU8TH)) 

DriveFuzz

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1758&annotation=H8T26EWW) “The test executor runs an ADS under the given driving scenario in a driving simulator, collecting various vehicle states for the fuzzing process. For the simulator, we choose to use CARLA [28], a high-fidelity driving simulator implemented using Unreal Engine. CARLA is known for its active development status and usage, professionally designed realistic maps, a wide range of supported sensors, flexibility in controlling various aspects of a driving scenario, and the ability to integrate various ADSes with ease by supporting Robot Operating System (ROS) [70], a universal middleware, which many robotic systems are built on top of.” ([Kim et al., 2022, p. 1758](zotero://select/library/items/PCMRU8TH)) 

CARLA

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1758&annotation=P7LNDBF2) “Inspired by the fact that the ADSes are designed to drive in the real world complying with traffic rules and regulations [65], we build the following three driving test oracles that check for the events that are closely related to human safety: collisions, infractions, and immobility of the ego-vehicle. • Collision. Collision is one of the most destructive events that can cause significant damage to human drivers. By attaching a collision sensor to the ego-vehicle (that would be corresponding to multiple sensors around a real vehicle), a collision to any object is captured and reported. • Infraction. Infractions are traffic violations including (1) speeding, (2) invading lanes, and (3) running on red lights, which are directly involved in approximately 30%, 8.5%, and 4%, respectively, of the annual fatal accidents in the United States in 2018 [59]. As DriveFuzz has full access to the simulated space, it compares the states of the vehicle (e.g., current speed) with the defined traffic rule (e.g., speed limit) to check for any violation. • Immobility. A vehicle that is not moving at a particular location would become a cause of subsequent undesirable events such as collisions (e.g., a car stopped in the middle of an intersection would cause other cars to crash into it). The immobility monitor measures the time duration when the vehicle is not moving, excluding legitimate stops (e.g., at traffic lights). If it exceeds a threshold (60 sec in this paper), that is considered a misbehavior.” ([Kim et al., 2022, p. 1758](zotero://select/library/items/PCMRU8TH)) 

collision, infraction, immobility

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1760&annotation=PEM32E7E) “ROS and portability. ROS [70] is a de facto middleware that provides a means of message passing between distributed nodes, hardware abstraction, and a toolset for the easier development of robotic systems. DriveFuzz incorporates ROS in the design of the test executor and makes any ROS-based ADSes [44, 45] and simulators [28, 72, 75] pluggable into the system.” ([Kim et al., 2022, p. 1760](zotero://select/library/items/PCMRU8TH)) 

ROS

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1760&annotation=R7UKTQA7) “Autoware: A full-fledged ADS with active development status. Started in 2015, it has been internationally adopted by many wellknown automobile manufacturers, e.g., BMW [6], and qualified to run driverless vehicles on public roads in Japan since 2017 [81]. • Behavior Agent: An ADS developed by CARLA, implementing path planning, feedback-based PID control, compliance with traffic laws, and collision avoidance.” ([Kim et al., 2022, p. 1760](zotero://select/library/items/PCMRU8TH)) 

Autoware, CARLA

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1763&annotation=JGEJRZRX) “AV-Fuzzer [53] is a state-of-the-art ADS testing approach that mutates the trajectory of two actor vehicles driving nearby, aiming to detect vehicle-to-vehicle collisions. It uses the longitudinal distance from the ego-vehicle to actor vehicles as a fitness function for the mutation to create scenarios with smaller distances. It detected five buggy scenarios: (1) hitting an overtaking vehicle, (2) hitting another vehicle while trying to cut in, (3) hitting a vehicle that cuts in, (4) rear-ending a suddenly braking vehicle, and (5) interpreting two adjacent vehicles as one and hitting one.” ([Kim et al., 2022, p. 1763](zotero://select/library/items/PCMRU8TH)) 

AV-Fuzzer

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1763&annotation=J6Q8N2M3) “Quantitative comparison. DriveFuzz was able to automatically generate all five crash scenarios AV-Fuzzer found and successfully detected misbehaviors (bugs #12-14, 19, 21, 25-27). On the other hand, AV-Fuzzer is bound to miss 26 out of 34 (76%) bugs DriveFuzz found due to fundamental limitations in the design. We discuss the reasons in the following, referring to the latest source code of AV-Fuzzer3. First, the input space of AV-Fuzzer is a subset of DriveFuzz’s driving scenarios. AV-Fuzzer divides a scenario into five time-slices (line 10 in drive_experiment.py and lines 1134 in Chromosome.py), and randomly mutates the target speed and the maneuver (e.g., go straight, change to the left lane, or change to the right lane) (lines 203-234 in GeneticAlgorithm.py) of two hardcoded actor vehicles (line 9 in drive_experiment.py), which always start driving at fixed positions (lines 180-181 in simulation.py). In contrast, DriveFuzz explores a multifaceted input space including the mission, weather, locations, and trajectories of an unbounded number of actor vehicles and/or pedestrians, and puddles. Second, DriveFuzz detects not only collisions (to vehicles, people, and objects), but also safety-critical traffic violations (e.g., running red lights) with the driving test oracles. However, AV-Fuzzer only considers vehicle-to-vehicle collisions (lines 190-215 in simulation.py), which is a subset of the misbehaviors DriveFuzz detects.” ([Kim et al., 2022, p. 1763](zotero://select/library/items/PCMRU8TH))

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1763&annotation=GGCC3397) “The accuracy of misbehavior detection depends on the correctness of the driving test oracles DriveFuzz leverages. We evaluate it by injecting errors that cause the misbehavior that each oracle targets. Table 5 shows each misbehavior and corresponding errors that are injected to synthesize scenarios where each misbehavior must be observed. For example, to test the collision oracle, the input mutator is set to create a high-speed vehicle driving directly towards the ego-vehicle at 100 different locations. After injecting each error, we run DriveFuzz to check whether the intended misbehavior is detected or not from each mutated scenario. Except for the four rare false negatives caused by a known issue in CARLA’s lane invasion sensor [18], the oracles never missed any misbehavior.” ([Kim et al., 2022, p. 1763](zotero://select/library/items/PCMRU8TH))

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1764&annotation=658Z4NYY) “PlanFuzz [84] tries to find denial of service vulnerabilities in the planning layer by introducing physical objects into driving scenes and guiding the input scenario generation based on the code execution that it monitors through instrumentation. Unlike these works, DriveFuzz considers a target ADS as a whole system rather than focusing on a specific layer or problem. This holistic approach allows us to find not only those bugs that individual layer testing covers, but also other types of bugs with propagating impacts across multiple layers that cause critical accidents. Besides, our approach does not require the source code, instrumentation, or domain knowledge of the target ADS in contrast to those white-box approaches.” ([Kim et al., 2022, p. 1764](zotero://select/library/items/PCMRU8TH)) 

PlanFuzz

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1765&annotation=MNEKWT45) “Fidelity of simulation. Despite a potential gap between the simulated and real environments, the use of high-fidelity simulation brings the quality of test cases in close proximity to that of physical testing and significantly enhances the quality of automated ADS testing over existing methods. This is also demonstrated by the fact that DriveFuzz discovers 33 new ADS and simulator bugs in the corner case driving scenarios that existing testing methods could not attempt to generate. 10 (out of 33 reported) bugs have been acknowledged by the ADS developers, and most are readily exploitable with concrete attacks by an adversary as we demonstrate in §6.3. More importantly, it not only enables a full degree of automation, but also provides other practical benefits, such as low cost and safety of testing, in comparison with physical testing with real vehicles. It is also supported by the fact that major ADS vendors rely heavily on simulators to develop and test their systems before physical testing [37, 85]. In our future work, we plan to reproduce the ADS issues in this paper with a real autonomous vehicle.” ([Kim et al., 2022, p. 1765](zotero://select/library/items/PCMRU8TH))

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1765&annotation=U3TKJTWT) “Limitation. Our driving quality-based feedback directs DriveFuzz to scenarios where an ADS performs unsafe maneuvers. We have proven that such feedback is effective in triggering misbehavior that we target. However, similar to most feedback-driven fuzzers that register a specific fitness function as a feedback, DriveFuzz can have a local optima problem [55], i.e., reaching a local optimum in the search space as a result of feedback guidance, and ends up missing other potential bugs that are less related to the feedback. In addition, there may exist attacks that do not affect the driving quality score but still cause misbehaviors. For example, if an adversary draws a fake curved lane on a straight road and misleads an ADS to invade a sidewalk, the driving quality score can still be good if an ego-vehicle seamlessly follows the fake lane, while the resulting circumstance is a lane invasion. As a mitigation, we can extend and diversify the driving quality score metrics, e.g., considering the adherence to the original plan, to deal with the bugs that are not necessarily coupled with clumsy driving behaviors.” ([Kim et al., 2022, p. 1765](zotero://select/library/items/PCMRU8TH))

>[Go to annotation](zotero://open-pdf/library/items/KEUMINPC?page=1765&annotation=PMHA9927) “Our study shows that the bugs we found can be triggered by only controlling legitimate inputs and cause devastating vehicle accidents.” ([Kim et al., 2022, p. 1765](zotero://select/library/items/PCMRU8TH))