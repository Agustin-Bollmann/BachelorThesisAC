---
title: Automotive Network Protocol Detection for Supporting Penetration Testing
authors: Florian Sommer, Jurgen Durrwang, Marius Wolf, Hendrik Juraschek, Richard Ranert, Reiner Kriesten
year: 2019
---

# Automotive Network Protocol Detection for Supporting Penetration Testing
##### Florian Sommer, Jurgen Durrwang, Marius Wolf, Hendrik Juraschek, Richard Ranert, Reiner Kriesten (2019)
[Zotero-Link](zotero://select/items/@sommerAutomotiveNetworkProtocol2019)

Tags: #Vulnerabilities #AttackSurfaces #BrakeAttack #ExternalCommunication #InternalCommunication #AUTOSAR #SAE #Pentesting #BlackBox #OSI #CAN #LIN #FlexRay #MOST #ApplicationLayer #Diagnostics #PTES #ASTM #PortScanner #Fuzzing #beSTORM #FlexibleDatarate #CaringCaribou #HEAVENS #Vulnerabilities #SecForCARs
>[!ABSTRACT]-
>Currently, the automotive industry aims to integrate security into the vehicle development process. In this process, a vehicle is analyzed for possible security threats in order to develop security concepts or security measures. Another important aspect in vehicle security development is security testing. Penetration testing is often used for this purpose. In penetration testing, a tester acts from the perspective of an attacker and tries to violate security properties of a vehicle through attacks (tests) in order to uncover possible vulnerabilities. Since this task is usually performed as a black box test with little knowledge about the system, penetration testing is a highly experience-based activity. Due to this, an automation of this process is hard to achieve. In this paper, we want to support the penetration testing process and its automation by introducing an extension of our automotive portscanner tool. This scanner was developed to scan vehicle networks, which are different from typical Information Technology (IT) networks, in order to extract information about the vehicle. Our tool is able to gather Electronic Control Units (ECUs) installed in a vehicle, as well as diagnostic services and subfunctions they provide. This functionality is extended by an automatic detection of transport and diagnostic protocols used in vehicles. With this knowledge, new use cases and functionalities like fuzzing or an automated generation of penetration test cases can be realized.


---

# Summary

- The paper introduces an **automotive portscanner tool** designed to identify Electronic Control Units (ECUs) and their diagnostic services in vehicle networks. It aims to automate the penetration testing process for automotive systems, enhancing information gathering and testing efficiency.
- The tool detects **transport and diagnostic protocols** automatically, allowing penetration testers to develop fuzzing tests and automate test case generation based on known vulnerabilities.
- The work emphasizes the importance of supporting black-box penetration testing and proposes use cases such as gathering vehicle data, reverse engineering routing tables, and exploiting diagnostic services.

# Relevancy

- **Focuses on Automotive Network Penetration Testing**: The methods and tools described align with your interest in manipulating and testing CAN traffic in simulated environments.
- **Covers Protocol Detection and Automation**: The automation of detecting transport and diagnostic protocols is particularly relevant for building an efficient setup using tools like CANToolz and Scapy in CARLA.
- **Explores Fuzzing and Vulnerability Scanning**: It discusses fuzz testing and vulnerability scanning based on protocol identification, offering practical techniques applicable to your thesis experiments.

# Notable Sections and Pages

- **Section II: Vehicle Network Protocols (Pages 2-3)**: Provides an overview of vehicle communication systems, including CAN and diagnostic protocols like UDS and OBD. This section is essential for understanding the structure of CAN networks and the protocols that your experiments will target.
- **Section III: Automotive Portscanner (Pages 3-5)**: Details the architecture and capabilities of the portscanner tool, including its automated protocol detection. This section is valuable for setting up similar automated scanning processes in your experiments with CARLA.
- **Section IV: Use Cases (Pages 5-7)**: Describes practical applications like fuzzing and vulnerability scanning. These examples offer insights into extending your thesis to explore similar attack vectors using simulated environments.

# Recommendations

This paper is an excellent source for your thesis, particularly in the context of automating penetration testing and protocol detection in automotive networks. I recommend citing it for its structured approach to penetration testing and its detailed explanation of how automated tools can be applied in automotive cybersecurity.

---

# Annotations  
(10/29/2024, 6:47:09 PM)

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=114&annotation=TDHXTHF6) “A trend towards autonomous driving is currently pursued in the automotive industry [1]. This increases the number of sensors and actuators installed in vehicles, as well as the complexity of internal and external communication of vehicle components. The required communication with the outside world for autonomous driving results in an increased risk of security attacks. This has already been demonstrated by various research groups [2]–[8]. Attacks were carried out on vehicles in which it was possible to manipulate actuators, which had an influence on driving physics, such as steering and braking systems. Since only a few methods have been established in the automotive sector to protect against such attacks, a high effort is currently being invested in research and development of security measures, standards and processes.” ([Sommer et al., 2019, p. 114](zotero://select/library/items/PHZ36JM7)) 

Vulnerabilities, AttackSurfaces, BrakeAttack, External,Internal Communication

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=114&annotation=PZC6CIZP) “The development partnership AUTomotive Open System ARchitecture (AUTOSAR) presented a measure to secure internal vehicle networks with Secure Onboard Communication (SecOC) [9], which enables authenticated communication of the vehicle’s internal bus systems. In January 2016, Society of Automotive Engineers (SAE) International published SAE J3061 (Cybersecurity Guidebook for Cyber-Physical Vehicle Systems) [10], a guideline in which security was integrated into the vehicle development process. In this process, a vehicle is analyzed for possible security threats in order to develop security concepts or security measures.” ([Sommer et al., 2019, p. 114](zotero://select/library/items/PHZ36JM7)) 

AUTOSAR, SAE

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=114&annotation=MFTW6587) “In penetration testing, a tester acts from the perspective of an attacker. The tester tries to violate security properties of a vehicle through attacks (tests) in order to uncover possible vulnerabilities. Penetration tests can be carried out as black box tests, without any information about the internal function of a system, or as white box tests in case of knowledge about the internal function. Especially in case of black box tests, the success of a penetration test depends on the experience of a tester, since there is limited knowledge about the system.” ([Sommer et al., 2019, p. 114](zotero://select/library/items/PHZ36JM7)) 

Pentesting, BlackBox

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=114&annotation=K6PGK9A3) “Penetration testing can be time consuming and potential vulnerabilities could be missed, depending on available system information. It is an explorative test method which highly depends on a tester’s experience. As a result, an automation of this process is hard to achieve.” ([Sommer et al., 2019, p. 114](zotero://select/library/items/PHZ36JM7)) 

Blackbox problems

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=115&annotation=LKMW67HG) “The Open Systems Interconnection (OSI) layer model [14] is used for a structured description of communication systems. It describes seven different layers which include specific tasks of message transmission. Since we focus on transport and diagnostic protocols for automotive communication systems, the relevant layers for our purposes are: physical layer (1), data link layer (2), transport layer (4) and application layer (7). The layers 1 and 2 are represented by the used communication systems. There are different communication systems in a vehicle, like FlexRay [15], Controller Area Network (CAN) [16], Local Interconnect Network (LIN) [17], Ethernet [18] and Media Oriented System Transport (MOST) [19]. These systems are used for various applications and have different properties. FlexRay is a cyclic network communication system which is used for applications requiring high data rates (10 Mbit/s). MOST and Ethernet are mainly applied for multimedia purposes with even higher data rates. LIN is a serial network protocol which connects components like sensors and ECUs. For the automotive sector, CAN [16] is one of the most important and commonly used bus systems. It is a bitstreamoriented bus system, using twisted pair wires as physical medium” ([Sommer et al., 2019, p. 115](zotero://select/library/items/PHZ36JM7)) 

OSI, CAN, LIN, FlexRay, MOST

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=115&annotation=DYFL27ZJ) “CAN is a broadcast system in which each message is uniquely characterized by an identifier. Since it is currently the most used bus system in the automotive domain, we first focus on CAN for the automated protocol detection. To explain the functionality of that mechanism, this paper is focused on CAN-based transport and diagnostic protocols. Transport protocols represent the fourth layer of the OSI layer model. They are required to transfer data larger than the maximum message length. This is particularly necessary for diagnostic applications and flash programming of ECUs. A further task of the transport protocols is to control time intervals between individual data packages. Transport protocols are also used to forward messages via gateways to networks with a different address space.” ([Sommer et al., 2019, p. 115](zotero://select/library/items/PHZ36JM7)) 

CAN

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=115&annotation=W84ZP5CZ) “The application layer is represented by diagnostic protocols. Diagnostic protocols use a so-called Service Identifier (SID) [23] to select different diagnostic services an ECU offers. To understand their functionality, the communication principle is shown in Figure 1. An external diagnostic testing device runs as a client, whereas the ECU runs as a server. To start a diagnostic communication, the diagnostic testing device has to send a diagnostic request message to an ECU. This request contains a SID and a subfunction which is necessary to address diagnostic services like reading the error memory. The addressed ECU can answer with a positive or negative response. A positive response is characterized by the addition of value 0x40 to the SID. A negative response is characterized by an Error-ID (0x7F), the original SID and a Response Code that contains the reason for the negative reponse.” ([Sommer et al., 2019, p. 115](zotero://select/library/items/PHZ36JM7)) 

ApplicaitonLayer, Diagnostics,

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=115&annotation=THDTSP9I) “An example of a pure penetration testing standard is the Penetration Testing Execution Standard (PTES) [30], which is intended to support companies and security service providers in conducting penetration tests. A methodology for security testing in the automotive sector is presented in the dissertation [31] with Automotive Security Testing Methodology (ASTM), which is divided into five areas: planning phase, detection phase, safe state analysis, moving vehicle analysis, documentation and review.” ([Sommer et al., 2019, p. 115](zotero://select/library/items/PHZ36JM7)) 

Pentesting, PTES, ASTM

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=116&annotation=UQ5WDGFJ) “In the first step, the portscanner uses an exhaustive search method to detect all ECUs inside a vehicle network. Therefore, standard diagnostic requests, as defined in International Organization for Standardisation (ISO) 14229, are sequencially sent to every possible CAN Identifier (ID). If a response to a request is received (positive or negative), an ECU is identified. In the next step, supported diagnostic services are identified. Similar to the ECU identification process before, every possible SID is checked by sending diagnostic requests to every detected ECU. A service is supported if there is a positive or negative response to a request. As a last step, subservices of all found diagnostic services are identified by sending diagnostic requests to every possible subservice for all supported services of each ECU. A challenge with the portscanner is the variation of transport protocols that can be used in vehicle networks. ISOTP in combination with OBD is required by law for diagnostic purposes. However, specific areas are reserved for vehicle manufacturers in diagnostic standards. For example, transport protocols, such as TP 2.0 are used for these diagnostic requests in vehicles of Volkswagen AG. An example of current capabilities of the portscanner is given in [31], where the tool was applied on two vehicles. On the first vehicle, our portscanner could find 47 ECUs, 380 diagnostic services and 1,924 subservices within 48 minutes and 27 seconds. On the second vehicle, it could find 43 ECUs, 282 diagnostic services and 2,538 subservices within 36 minutes and 5 seconds. A further evaluation across several vehicle types and manufacturers will have to be carried out in the future. The portscanner functionality is extended by an automatic protocol detection in order to achieve a greater coverage during the extraction of vehicle data.” ([Sommer et al., 2019, p. 116](zotero://select/library/items/PHZ36JM7)) 

PortScanner

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=118&annotation=6X6ATVYG) “In fuzzing, an attempt is made to test a system for its susceptibility to errors or robustness by entering random or modified data [13]. This method can uncover new vulnerabilities in a system. The usage of fuzzing techniques in the automotive sector has been shown in [41] in which fuzzing is performed using the data bytes of CAN messages, or in [42] in which the fuzzing tool beSTORM was extended by the Controller Area Network Flexible Datarate (CAN FD) [43] protocol. Another fuzzing tool in the automotive industry is CaringCaribou, which was developed as part of the HEAling Vulnerabilities to ENhance Software Security and Safety (HEAVENS) research project [44]. By knowing the transport and diagnostic protocols, the input sequence for fuzzing can be specified based on the given information by simply changing the data within these protocols.” ([Sommer et al., 2019, p. 118](zotero://select/library/items/PHZ36JM7)) 

Fuzzing, beSTORM, CAN, Flexible Datarate, CaringCaribou, HEAVENS

>[Go to annotation](zotero://open-pdf/library/items/VP9GUNJW?page=118&annotation=A75B46WI) “Another use case incorporates vulnerability scanning in which a system is scanned for known security vulnerabilities. Through an automatic detection of supported vehicular network protocols, the scanning process can be automated. Vulnerability databases can serve as data input for our tool. The Karlsruhe University of Applied Sciences [45] currently aims to develop such a database for the automotive sector as part of the Security For Connected, Autonomous caRs (SecForCARs) [46] project.” ([Sommer et al., 2019, p. 118](zotero://select/library/items/PHZ36JM7)) 

Vulnerabilities Scanner, SecForCARs