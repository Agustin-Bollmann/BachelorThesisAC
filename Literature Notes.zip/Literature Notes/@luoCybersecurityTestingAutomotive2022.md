---
title: "Cybersecurity Testing for Automotive Domain: A Survey"
authors: Feng Luo, Xuan Zhang, Zhenyu Yang, Yifan Jiang, Jiajia Wang, Mingzhi Wu, Wanqiang Feng
year: 2022
---

# Cybersecurity Testing for Automotive Domain: A Survey
##### Feng Luo, Xuan Zhang, Zhenyu Yang, Yifan Jiang, Jiajia Wang, Mingzhi Wu, Wanqiang Feng (2022)
[Zotero-Link](zotero://select/items/@luoCybersecurityTestingAutomotive2022)

Tags: #WP29 #UNECE #ISO #SAE #Verification #Jeep #AUTOSAR #Literature #ThreatBased #Pentesting #BlackBox #WhiteBox #GreyBox #Automation #Code #RemoteAttack #AttackSurfaces #Scanning #Vulnerabilities #InternalCommunication #ExternalCommunication #UDS #ECU #CAN #Spoofing #Jamming #Camera #AttackSurfaces #AttackVectors #Fuzzing #TARA #RiskManagement #SecOC #MAC #PDU #CINNAMON #CSP #OTA #PrT #UML #TestingModels #TestBeds #AI #Blockchain 

>[!ABSTRACT]-
>Modern vehicles are more complex and interconnected than ever before, which also means that attack surfaces for vehicles have increased significantly. Malicious cyberattacks will not only exploit personal privacy and property, but also affect the functional safety of electrical/electronic (E/E) safety-critical systems by controlling the driving functionality, which is life-threatening. Therefore, it is necessary to conduct cybersecurity testing on vehicles to reveal and address relevant security threats and vulnerabilities. Cybersecurity standards and regulations issued in recent years, such as ISO/SAE 21434 and UNECE WP.29 regulations (R155 and R156), also emphasize the indispensability of cybersecurity verification and validation in the development lifecycle but lack specific technical details. Thus, this paper conducts a systematic and comprehensive review of the research and practice in the field of automotive cybersecurity testing, which can provide reference and advice for automotive security researchers and testers. We classify and discuss the security testing methods and testbeds in automotive engineering. Furthermore, we identify gaps and limitations in existing research and point out future challenges.


---

# Summary

- The paper provides a **comprehensive survey** of cybersecurity testing methods in the automotive domain, examining the state-of-the-art practices, challenges, and technologies applied in vehicle testing. It discusses various testing methodologies, including **black-box, white-box, and grey-box** testing, and their applications in the automotive sector.
- The authors also review **fuzzing**, **penetration testing**, and **model-based testing** techniques, elaborating on their use cases, advantages, and limitations in automotive security. The survey integrates information from standards such as **ISO/SAE 21434** and the **UNECE WP.29** regulations, highlighting the importance of these standards in guiding automotive cybersecurity practices.
- It further discusses the use of testbeds for conducting cybersecurity tests, comparing their characteristics and applications, and identifies the **challenges and limitations** currently faced in the field.

# Relevancy

- **Provides a Broad Overview**: The paper offers insights into different automotive cybersecurity testing methods, directly aligning with your focus on manipulating CAN traffic and testing vulnerabilities using simulation tools like CARLA.
- **Discusses Standards and Regulations**: The review of ISO/SAE 21434 and UNECE WP.29 regulations is valuable for ensuring that your experiments and methodology align with industry standards.
- **Explores Testbeds and Methodologies**: The information on testbeds and different testing methodologies, such as fuzzing and penetration testing, supports your work on developing a testing framework using CAN manipulation tools like CANToolz.

# Notable Sections and Pages

- **Section 3: Automotive Cybersecurity Testing Methods (Pages 3-7)**: This section categorizes different testing methods (e.g., black-box, grey-box) and explains their application in the automotive field, providing a foundation for developing your testing strategies.
- **Section 4: Testbeds for Cybersecurity Testing (Pages 8-10)**: Discusses various testbeds used for automotive security testing, including those relevant to CAN traffic analysis, essential for designing your simulation experiments in CARLA.
- **Section 5: Challenges and Future Trends (Pages 11-13)**: Highlights the current gaps and challenges in automotive cybersecurity testing, offering insights into potential areas of improvement that could be integrated into your thesis.

# Recommendations

This survey is a crucial addition to your thesis literature as it provides a structured and detailed overview of existing automotive cybersecurity testing methods, aligning closely with your research objectives. I recommend citing it for its thorough discussion of standards, methodologies, and the state-of-the-art in automotive security testing.

---

# Annotations  
(11/1/2024, 8:53:37 PM)

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=1&annotation=KKXWZ2TR) “Cybersecurity standards and regulations issued in recent years, such as ISO/SAE 21434 and UNECE WP.29 regulations (R155 and R156), also emphasize the indispensability of cybersecurity verification and validation in the development lifecycle but lack specific technical details.” ([Luo et al., 2022, p. 1](zotero://select/library/items/T5ZR2JUC)) 

WP.29, UNECE, ISO, SAE, Verificaiton

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=1&annotation=E28N5HKP) “In particular, Miller and Valasek’s compromise of Jeep led to the recall of 1.4 million vehicles, which brought public attention to automotive cybersecurity [2]. Therefore, it is crucial to effectively test and discover threats and vulnerabilities before vehicle production.” ([Luo et al., 2022, p. 1](zotero://select/library/items/T5ZR2JUC)) 

Jeep

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=2&annotation=Z5HHTABS) “To the best of our knowledge, there are currently few review articles on automotive cybersecurity testing. Pekaric et al. [10] perform a systematic mapping study (SMS) on automotive security testing techniques. They discuss various security testing techniques and map them to the vehicle lifecycle, the AUTomotive Open System ARchitecture (AUTOSAR) layers, and attack types.” ([Luo et al., 2022, p. 2](zotero://select/library/items/T5ZR2JUC)) 

AUTOSAR

![](QZ8LCKAM.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=5&annotation=QZ8LCKAM)  
([Luo et al., 2022, p. 5](zotero://select/library/items/T5ZR2JUC)) 

Literature

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=5&annotation=WSER3S6F) “attention to the level of a tool. It can be classified into three types based on the level of autom automated testing, semi” ([Luo et al., 2022, p. 5](zotero://select/library/items/T5ZR2JUC)) 

Threat based testing

![](WLDMZFQ6.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=6&annotation=WLDMZFQ6)  
([Luo et al., 2022, p. 6](zotero://select/library/items/T5ZR2JUC)) 

Pentesting, methods

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=6&annotation=WKYWYEPK) “The knowledge-based testing is conducted based on the degree of knowledge of the SUT. In general, it can be divided into the following three categories. For black-box testing, testers do not have functional specifications and documents related to the SUT, and the target system is treated as a black box. Testers verify the security design and defense of the system from the outside, which is closer to the actual attack situation and can assess the system’s resistance to attacks. Since the information is not available, it can be challenging in the early stage of testing, requiring significant time and cost to reverse engineer the system. Moreover, without specifics, potential threats and vulnerabilities are difficult to identify. Penetration testing is a kind of black-box testing in most cases and will be thoroughly presented in Section 3.3.2.” ([Luo et al., 2022, p. 6](zotero://select/library/items/T5ZR2JUC)) 

blackbox

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=6&annotation=PWZY9SXV) “White-box testing means that the internal details of the target system are known. Potential threat vulnerabilities can be carefully revealed based on functional specifications and source code without wasting much time and effort on information acquisition. Test coverage can be significantly improved by accessing the full source code, but this would take a significant amount of time. This method is commonly used in dynamic and static code scanning of automotive applications [15]. This approach enables comprehensive testing of the automotive system from source code to architecture design.” ([Luo et al., 2022, p. 6](zotero://select/library/items/T5ZR2JUC)) 

Whitebox

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=6&annotation=JIC36GKN) “source code without wasting much time and effort on information acqu coverage can be significantly improved by accessing the full source code, but take a significant amount of time. This method is commonly used in dynami code scanning of automotive applications [15]. This approach enables compreh ing of the automotive system from source code to architecture design. Grey-box testing is a combination of black-box and white-box, a method into account time and cost tr” ([Luo et al., 2022, p. 6](zotero://select/library/items/T5ZR2JUC)) 

Greybox

![](NI3L3FPV.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=7&annotation=NI3L3FPV)  
([Luo et al., 2022, p. 7](zotero://select/library/items/T5ZR2JUC))

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=7&annotation=DZUYSLWC) “A fully automated method is ideal and expensive, so it is usually superior to use a semi-automated testing method that combines manual and automated testing. In our surveyed literature, Marksteiner et al. [17] proposed a conceptual framework to transfer threats into executable test cases using a workflowbased system. In 2021, they also presented an automated automotive cybersecurity security testing process based on ISO/SAE 21343, bridging the gap between existing automotive security standards and actual system testing [18]. Table 5 shows the comparison of the automated testing methods.” ([Luo et al., 2022, p. 7](zotero://select/library/items/T5ZR2JUC)) 

Automation

![](37QATKTH.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=7&annotation=37QATKTH)  
([Luo et al., 2022, p. 7](zotero://select/library/items/T5ZR2JUC)) 

Automation

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=8&annotation=KYFRX6YL) “The first one is static/dynamic code analysis. The software-defined vehicles (SDV) concept has recently become popular. The software has become the basis of future automotive intelligence. Today, the software size in cars has exceeded 100 million lines of code [20], and software code security has become a critical task.” ([Luo et al., 2022, p. 8](zotero://select/library/items/T5ZR2JUC)) 

Code

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=8&annotation=QXJZ34D4) “The other is communication service scanning. The communication here can be wireless or wired communication. Traditional vulnerability scanning can be used for classic wireless communication, such as Wi-Fi, cellular network, and Bluetooth, which is also the most commonly used attack vector for hackers to compromise vehicles [1]. This attack is more straightforward and less expensive than accessing a physical interface like on-board diagnostics (OBD). Franco et al. [22] utilized Nmap and Nessus scanners to obtain sensitive data of car infotainment systems through Wi-Fi, such as a physical address, chip manufacturer, open ports, and conduct a denial of service (DoS) attack on Wi-Fi communication.” ([Luo et al., 2022, p. 8](zotero://select/library/items/T5ZR2JUC)) 

emoteattack, attackSurfaces

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=8&annotation=8A7IHUUY) “The other is the physical interface of direct contacts, such as the OBD interface, which generally runs the unified diagnostic services (UDS) on the CAN. UDS is a diagnostic protocol based on the application layer in the open systems interconnection (OSI) model defined by ISO-14229 [23]. Among them, ISO 14229-1 defines diagnostic services. However, it does not involve the network layer and implementation details, only the content of the application layer so that it can be implemented on different automotive buses such as CAN, Local Interconnect Network (LIN), Flexray, Ethernet. and K-line. Attackers can tamper with the configuration of the electronic control unit (ECU) through the UDS protocol, which can affect the functionality of the ECU. However, before reading and writing data, a simple security access verification is required by the UDS security access service. The client must send a seed request first, and then the server replies with the seed of a positive response. The client calculates the secret key according to the seed and the security algorithm. The client sends the secret key, and the server compares the received secret key with its secret key. If the keys match, the server unlocks the relevant data or service. If it does not match, it is considered a bad attempt. There are several security holes in this verification process. First, if the randomness of the seed is weak, the system can be easily broken by an attacker. In addition, if there is no time interval between false attempts, then the attacker can use brute force to crack. Therefore, we can use some automated scanning tools or scripts to verify the randomness of the seed and whether there is a delay among multiple false attempts. In our other work [24], we used our self-developed software tool to automatically discover ECUs with UDS protocol in the invehicle network and further identify the UDS services supported by various ECUs. The information obtained from the previous UDS topology discovery and service scanning can facilitate subsequent penetration testing and fuzzing. Weiss et al. [25] also designed a security scanning tool for the CAN transport layer to help assess the attack surface of the system. Table 6 compares various vulnerability scanning methods by time, cost, test scope and limitation.” ([Luo et al., 2022, p. 8](zotero://select/library/items/T5ZR2JUC)) 

Scanning, vulnerabilitites

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=9&annotation=9ZQIR24N) “Penetration testing, also called pen testing, is a traditional testing method commonly used in the IT field to test the security of web applications. Security testers usually imitate hackers to conduct malicious attacks on the system under test to discover system security loopholes. The objectives tested generally contains applications, communication networks and security-critical systems. As it develops, penetration testing is not only a testing technology but also a testing process. Nowadays, there have been some agreed rules that describe the steps of penetration testing. One of the most famous is the penetration testing execution standard (PTES). In summary, PTES can be divided into five steps: intelligence gathering, threat modeling, vulnerability analysis, exploitation, and reporting. Intelligence gathering is the first step of penetration testing. This phase is responsible for collecting security-related information about the SUT, such as system architecture, communication methods, etc. This information is beneficial to the subsequent penetration work. The threat modeling phase analyzes the possible threats to the system through threat analysis and risk assessment and determines the best way to attack. Vulnerability analysis combines the information from the first two steps and identifies the attack points. The exploitation phase conducts the actual attack on the identified threat vulnerabilities to reach the purpose of penetration testing. Finally, the report phase summarizes the entire penetration process and condenses the details of the test. Although there is no standardized penetration testing methodology for the automotive sector, the above-mentioned traditional testing process for IT can provide a reference for the application of penetration testing in automobiles.” ([Luo et al., 2022, p. 9](zotero://select/library/items/T5ZR2JUC)) 

Pentesting

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=9&annotation=VA8TULCH) “Automotive network communication is divided into internal and external communication. Internal communication contains wired types such as CAN, LIN, and automotive Ethernet, while external communication includes wireless types such as Wi-Fi, Bluetooth, cellular network, etc. The automotive network is a common entry point for attackers to break into vehicles. Due to possible flaws in the design and implementation of network communication protocols, security testers utilize various attack methods to violate the” ([Luo et al., 2022, p. 9](zotero://select/library/items/T5ZR2JUC)) 

internal, external communicaiton

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=10&annotation=QA2HHLF5) “security properties of network communication from the perspective of attackers, thereby discovering potential security vulnerabilities in automotive network communication. The security attributes involved in communications generally include confidentiality, integrity, authentication, availability, authorization (CIAAA). For each security attribute, different attack methods can be applied, such as sniffing, tampering, spoofing, DoS, unauthorization access, etc. Testers build single-step or multi-step combined attacks that violate the security properties according to the security requirements of real scenarios and evaluate the security risk” ([Luo et al., 2022, p. 10](zotero://select/library/items/T5ZR2JUC))

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=10&annotation=Z8M8KZ4L) “As for software testing, penetration testing mainly performs malicious operations on the application software, such as injection and tampering, to change its control logic. Testers can tamper with the ECU firmware or employ the UDS function to affect the behavior of the ECU [26]. They also can install malicious apps on the smartphone to connect to the car’s invehicle infotainment system (IVI), then exploit the IVI vulnerability to send malicious CAN messages that impact the safety-critical function [27]. Through these attacks, the software system’s defense resistance to malicious attacks can be assessed, and the vulnerability of the software can be effectively discovered.” ([Luo et al., 2022, p. 10](zotero://select/library/items/T5ZR2JUC)) 

UDS, ECU, CAN

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=10&annotation=ZWN3BX9S) “Regarding hardware, the research on attack and testing sensors such as lidar, millimeterwave radar, and cameras has become increasingly popular in recent years. As the core components of intelligent networked vehicles, sensors play a crucial role in guiding driving. If the sensor is compromised, it could endanger human life. Yan et al. [28] performed spoofing and jamming attacks on multiple Tesla sensors, causing the automotive self-driving to malfunction. Shin et al. [29] present a saturation attack to affect the ability of the lidar to detect objects.” ([Luo et al., 2022, p. 10](zotero://select/library/items/T5ZR2JUC)) 

spoofing, jamming, camera

![](GI5CKSIX.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=10&annotation=GI5CKSIX)  
([Luo et al., 2022, p. 10](zotero://select/library/items/T5ZR2JUC)) 

pentesting comparison

![](TQ4BNFB7.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=11&annotation=TQ4BNFB7)  
([Luo et al., 2022, p. 11](zotero://select/library/items/T5ZR2JUC))


![](TSPSI2GA.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=12&annotation=TSPSI2GA)  
([Luo et al., 2022, p. 12](zotero://select/library/items/T5ZR2JUC)) 

AttackVector

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=12&annotation=DRL8VPVP) “.3. Fuzzing Fuzz testing, also named fuzzing, is a software testing techniq curity and robustness of the SUT. This approach identifies security SUT by feeding a large amount of random or unexpected data to a havior of the SUT. Fuzzing comprises three parts: a test case genera tem, and a test environment. This testing is generally executed by tool called fuzzer. Fuzzer can be divided into two types based on generated: mutation-based and generation-based. The mutation-b ates test cases by randomly mutating existing data samples. It is a However, the generation-based approach is a white-box approach, and structure of known protocols or files to generate test cases bas models. The generation-based approach has a higher test case pass than the mutation-based approach, but with a relatively higher cost. testing technique that combines the advantages of both types is so Figure 5. Distribution of papers by attack vector. 3.3.3. Fuzzing Fuzz testing, also named fuzzing, is a software testing technique that verifies the security and robustness of the SUT. This approach identifies security vulnerabilities in the SUT by feeding a large amount of random or unexpected data to and monitoring the behavior of the SUT. Fuzzing comprises three parts: a test case generator, a monitoring system, and a test environment. This testing is generally executed by a dedicated software tool called fuzzer. Fuzzer can be divided into two types based on how the test data is generated: mutation-based and generation-based. The mutation-based approach generates test cases by randomly mutating existing data samples. It is a black-box approach. However, the generation-based approach is a white-box approach, which uses the syntax and structure of known protocols or files to generate test cases based on specific rules or models. The generation-based approach has a higher test case pass rate and test coverage than the mutation-based approach, but with a relatively higher cost. Therefore, a gray-box testing technique that combines the advantages of both types is sometimes utilized. Although fuzzing is relatively mature in operating systems and application software, it is still rare in automotive systems [20]. In addition, fuzzers in the traditional IT industry cannot be directly applied to the automotive industry. Therefore, the development and application of fuzzing tools in the automotive field is also an important task” ([Luo et al., 2022, p. 12](zotero://select/library/items/T5ZR2JUC)) 

Fuzzing

![](ELXIXNGT.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=12&annotation=ELXIXNGT)  
([Luo et al., 2022, p. 12](zotero://select/library/items/T5ZR2JUC)) 

AttackType

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=13&annotation=YQE6HS29) “The applicable scenarios of fuzzing are different for various attack vectors. The first one is network communication. The fuzzing of communication protocols is aimed to identify vulnerabilities in their principles or implementations. The second is application services, and this type is mainly for testing the implementation of application services to prevent malicious exploitation by attackers. The third type targets automotive systems, which aims to discover the security vulnerabilities in automotive systems to guarantee the stability and robustness of security-critical systems. In network communication, Lee et al. [45] mutated the CAN ID and data fields from sniffed CAN messages. The generated fuzzy CAN data was then injected into the CAN bus via the Bluetooth of the computer, and the behavior of the vehicle was monitored. Thus, the vulnerability of the automotive network is exposed. Fowler et al. [46] developed a custom PC-based fuzzer. A mutation-based approach was utilized for CAN bus experiments on the vehicle simulator and instrumentation components to avoid damage to the vehicle. In 2019, they improved their fuzzer prototype and proposed a systematic fuzzy test scheme. The security properties of the ECU were also tested by fuzzy data injection of the display ECU [47]. Werquin et al. [48] developed a sensor harness to facilitate automated detection of the system’s behavior, which has significant advantages over previous manual testing approaches. Furthermore, the method has been integrated into the open-source security testing tool CaringCaribou. Most of the above fuzzy test cases for CAN are random variants of CAN-specific data, and the test coverage is not high. Radu et al. [49] created initial seeds for fuzzing using relevant static data from control flow graphs extracted from ECU firmware. This approach can improve the test coverage and is better than the random mutation strategy. Zhang et al. [50] proposed a more novel fuzzing approach to expose the vulnerability of CAN. They developed two fuzzy data generators. One reverses CAN by bit-flip rate (BFR) and performs a mutation operation on the identified signals to prevent data combination explosion. The other uses generative adversarial networks (GAN) in deep learning to learn protocol models and generate test cases. They conducted experimental evaluations on intrusion detection systems (IDS) and live vehicles. The results show that both approaches are more effective than the random mutation approach. In addition to CAN, Nishimura et al. [51] developed an interface to support CAN FD based on the existing fuzzing tool beSTORM and calculated test execution time parameters to evaluate the usability. Li et al. [52] developed a fuzzer for the automotive Ethernet Scalable service-Oriented MiddlewarE over IP (SOME/IP) protocol, and the fuzzer can enable multiple test processes simultaneously to improve testing efficiency. In addition, valid packet headers can be generated by structural mutation, which can successfully expose the implementation flaws of SOME/IP. In application services, Bayer et al. [53] implemented four UDS service request message models and performed fuzzer tests on simulated ECUs. The results show that their fuzzer effectively detects faults and standards compliance of automotive ECUs. Patki et al. [54] developed a fuzzing tool for the UDS protocol. It uses a mutation-based approach to create invalid inputs to find hidden vulnerabilities in the automotive environment. They also compared their proposed system with other existing fuzzers (Defensics and extended Peach) to highlight the advantages. As for automotive systems, Moukahal et al. [55] designed a fuzz testing framework, VulFuzz. The framework uses security metrics to rank the security priority of automotive components and tests the most vulnerable components thoroughly. They used the framework to evaluate an autonomous driving system, OpenPliot, and compared the test results with American fuzzy lop (AFL) and a mutation-based fuzzer. The proposed framework performs better in exposing crashes for the same code coverage. In the same year, they improved their fuzzing framework [56]. The new framework can enhance vulnerability identification and improve branch coverage with lower overhead. In addition to the fuzzing technology itself, researchers are also studying how to integrate fuzzing into existing automotive security engineering. Vinzenz [57] and Oka [58]” ([Luo et al., 2022, p. 13](zotero://select/library/items/T5ZR2JUC))


![](BXQTVJLF.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=14&annotation=BXQTVJLF)  
([Luo et al., 2022, p. 14](zotero://select/library/items/T5ZR2JUC)) 

Fuzzing

![](VGR4QUFA.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=14&annotation=VGR4QUFA)  
([Luo et al., 2022, p. 14](zotero://select/library/items/T5ZR2JUC))

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=15&annotation=DT9PVJJ9) “TARA serves as the core of risk-based testing. TARA results include threat identification, probability and impact of threat scenarios, and risk values. Using the risk assessment results can help prioritize test cases and test execution. In the past, risk assessment was not an activity in automotive development. However, with the promulgation of SAE J3601 and ISO/SAE 21434, risk-based security activities have been introduced throughout the automotive cybersecurity development process. The standard also provides a TARA methodology for OEMs and suppliers to implement, as shown in Figure 8. Moreover, based on the research literature, Table 9 describes several security analysis methods and techniques in the automotive domain. It also compares the threat models. In addition, whether the analysis method involves safety and security is considered.” ([Luo et al., 2022, p. 15](zotero://select/library/items/T5ZR2JUC)) 

TARA, Risk

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=17&annotation=Y83QMVQN) “In order to ensure the security of the internal communication data of the connected car, a secure in-vehicle communication solution is generally adopted. The secure onboard communication (SecOC) in the AUTOSAR software specification is generally acknowledged in the automotive industry. The SecOC mechanism can verify the authenticity, integrity, and freshness of the communication between ECUs. Figure 9 shows the freshness verification and message authentication process of SecOC. On the sender side, the SecOC module uses the secret key to generate the message authentication code (MAC) for the message protocol data unit (PDU). It adds the freshness value to obtain the Secured I-PDU. After receiving the Secured I-PDU, the receiver will use the same algorithm to check whether the MAC of the message is consistent with the sender to ensure the authenticity and integrity of the data. Additionally, the freshness value can prevent replay attacks. However, SecOC cannot guarantee the confidentiality of data, so researchers developed CINNAMON (Confidential, INtegral aNd Authentic on board coMunicatiON), which extended the SecOC module to ensure the confidentiality of transmitted data [68]. It is necessary to know the corresponding 2022, 22, 9211 18 of 27 algorithms for testing cryptographic and verification functions. If not, it needs to be fetched by the reverse engineer, such as machine learning [69]. After obtaining the algorithm, the inverse operation can be performed in the test system to verify whether the output is consistent with the input.” ([Luo et al., 2022, p. 17](zotero://select/library/items/T5ZR2JUC))

SecOC, AUTOSAR, MAC, PDU, CINNAMON

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=18&annotation=SEW2I9VY) “Cheah et al. [71] presented a test case generation method based on attack trees model using communicating sequential processes (CSP). CSP is a process-algebraic formalism for analyzing and modeling dynamic systems. They conduct testing on the Bluetooth and CAN. Since the construction of attack trees still mainly relies on manual effort, this is a semi-automatic approach. Heneghan et al. [72] further propose a framework for automated security testing of ECU at the component level based on CSP. They expect to identify vulnerabilities and verify functional security with model checking techniques. Mahmood et al. [73] provide a systematic MBST approach based on their work in [4], they design a software tool and a testbed for generating and executing test cases automatically. They launch several simulated attacks against the automotive Overthe-Air (OTA) system using the Uptane framework. Although only one type of attack is described in this paper, the effectiveness and prospect of this method are shown from the complete implementation process. Dos Santos et al. [74] considered the security flaws of automotive systems and vehicular network at an abstract level with Predicate/Transition (PrT) nets, which are a graphical dynamic system modeling language. They model four Sensors 2022, 22, 9211 19 of 27 common attacks (interception, fabrication, modification of data, and interruption) and demonstrate the accuracy of the threat model in three real-world vehicle scenarios. They believe that the functional model of unified modeling language (UML) can be combined to generate the code of security test cases, but it was not implemented at the time.” ([Luo et al., 2022, p. 18](zotero://select/library/items/T5ZR2JUC)) 

CSP, ECU, OTAm PrT, UML

![](234JF6LI.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=20&annotation=234JF6LI)  
([Luo et al., 2022, p. 20](zotero://select/library/items/T5ZR2JUC)) 

TestingModels

![](5LW58WKV.png)  
>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=21&annotation=5LW58WKV)  
([Luo et al., 2022, p. 21](zotero://select/library/items/T5ZR2JUC)) 

Testbeds

>[Go to annotation](zotero://open-pdf/library/items/PGCNWM6D?page=22&annotation=26CZDYP7) “In addition to model-based approaches, research on other advanced technologies, such as blockchain and artificial intelligence (AI), is also gradually increasing in the automotive field. Blockchain is regarded as a secure, trusted, and decentralized solution. Javed et al. [96] provided a comprehensive survey of blockchain and federated learning applications on vehicular networks. Jabbar et al. [97] compared the application of blockchain technology in intelligent transportation system. Kapassa et al. [98] discussed the limitations and contributions of blockchain technology in the application of the Internet of Vehicles. Zhou et al. [99] studied blockchain technology for secure authentication and trading between automobiles. AI is mainly applied in automotive security countermeasures, including secure communication [100,101], access control mechanisms [102], and IDS [103]. These two technologies are currently mainly utilized in security design, which can protect automotive cybersecurity, but their application in security testing remains to be studied.” ([Luo et al., 2022, p. 22](zotero://select/library/items/T5ZR2JUC)) 

AI, Blockchain