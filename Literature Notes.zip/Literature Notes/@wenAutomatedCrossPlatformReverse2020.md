---
title: Automated Cross-Platform Reverse Engineering of CAN Bus Commands From Mobile Apps
authors: Haohuang Wen, Qingchuan Zhao, Qi Alfred Chen, Zhiqiang Lin
year: 2020
---

# Automated Cross-Platform Reverse Engineering of CAN Bus Commands From Mobile Apps
##### Haohuang Wen, Qingchuan Zhao, Qi Alfred Chen, Zhiqiang Lin (2020)
[Zotero-Link](zotero://select/items/@wenAutomatedCrossPlatformReverse2020)

Tags: #ReverseEngineering #CANHunter #MobileApps #CANStructure #CANCommands #Autoware 

>[!ABSTRACT]-
>In modern automobiles, CAN bus commands are necessary for a wide range of applications such as diagnosis, security monitoring, and recently autonomous driving. However, only a small portion of CAN bus commands is standardized, and a vast majority of them is developed privately by car manufacturers. Today, the most effective way of revealing the proprietary CAN bus commands is to reverse engineer with real cars, which unfortunately is time-consuming and costly. In this paper, we propose a cost-effective (no real car needed) and automatic (no human intervention required) system, CANHUNTER, for reverse engineering of CAN bus commands using just car companion mobile apps. To achieve high effectiveness, we design an efficient technique to uncover the syntactics of CAN bus commands with backward slicing and dynamic forced execution, and a novel algorithm to uncover the semantics of CAN bus commands by leveraging code-level semantic clues. We have implemented a prototype of CANHUNTER for both Android and iOS platforms, and tested it with all free car companion apps (236 in total) from both Google Play and Apple App Store. Among these apps, CANHUNTER discovered 182, 619 unique CAN bus commands with 86.1% of them revealed with semantics, covering 360 car models from 21 car manufactures. We have also evaluated their correctness (both syntactics and semantics) using public resources, cross-platform and cross-app validation, and also realcar testing, with which over 70% of all the uncovered commands are validated. We observe no inconsistency in cross-platform and cross-app validation. While there are 3 semantic inconsistency among 241 manually validated CAN bus commands from public resources and real-car testing, we find that these three cases are actually caused by mistakes from app developers.


---

# Summary

- **Cross-Platform Analysis**: The study highlights the challenges and solutions in handling various mobile operating systems (e.g., Android, iOS) to intercept and reverse-engineer CAN communications. It uses network sniffing and traffic interception tools like **Wireshark** and custom scripts for packet analysis.
- **Reverse Engineering Techniques**: It details specific methodologies for decoding encrypted CAN messages, including the use of **dynamic analysis** tools and frameworks such as **Frida** and **Xposed**, to bypass security measures like app encryption and obfuscation.
- **Command Manipulation**: The research demonstrates how attackers can remotely access vehicle controls, including acceleration and braking commands, by manipulating CAN messages through mobile apps that communicate with the vehicle's network.

# Relevancy

- **Covers Reverse Engineering Techniques**: The methods discussed are directly applicable for testing and manipulating CAN traffic, providing technical approaches that can be adapted for simulation environments like CARLA.
- **Explores Mobile App Interactions**: The examination of mobile app communications with vehicle CAN networks aligns with your interest in both physical and remote access points for hacking autonomous vehicles.
- **Focuses on Bypassing Security Measures**: The techniques for decoding encrypted CAN traffic provide insight into potential vulnerabilities and attack vectors, which can be essential for designing your CAN manipulation experiments.

# Notable Sections and Pages

- **Section III: Network Interception Methods (Pages 8-11)**: Details the tools and techniques used for intercepting CAN messages exchanged via mobile apps, relevant for structuring your experiments.
- **Section IV: Dynamic Analysis and Bypass Techniques (Pages 12-15)**: Explains the use of tools like Frida for bypassing app security, crucial for understanding how to access and manipulate CAN traffic.
- **Section V: Case Studies (Pages 18-21)**: Provides real-world examples of CAN command manipulation, demonstrating practical applications that could guide your simulations.

# Recommendations

This paper is an important addition to your thesis literature. It provides practical insights into reverse engineering CAN traffic, particularly through mobile app interfaces, which is directly applicable to your work on testing and manipulating CAN messages. I recommend citing it for its technical depth and real-world application examples.

---

# Annotations  
(11/3/2024, 10:32:10 PM)

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=1&annotation=4JY3FQU2) “In modern automobiles, CAN bus commands are necessary for a wide range of applications such as diagnosis, security monitoring, and recently autonomous driving. However, only a small portion of CAN bus commands is standardized, and a vast majority of them is developed privately by car manufacturers. Today, the most effective way of revealing the proprietary CAN bus commands is to reverse engineer with real cars, which unfortunately is time-consuming and costly. In this paper, we propose a cost-effective (no real car needed) and automatic (no human intervention required) system, CANHUNTER, for reverse engineering of CAN bus commands using just car companion mobile apps. To achieve high effectiveness, we design an efficient technique to uncover the syntactics of CAN bus commands with backward slicing and dynamic forced execution, and a novel algorithm to uncover the semantics of CAN bus commands by leveraging code-level semantic clues. We have implemented a prototype of CANHUNTER for both Android and iOS platforms, and tested it with all free car companion apps (236 in total) from both Google Play and Apple App Store. Among these apps, CANHUNTER discovered 182, 619 unique CAN bus commands with 86.1% of them revealed with semantics, covering 360 car models from 21 car manufactures. We have also evaluated their correctness (both syntactics and semantics) using public resources, cross-platform and cross-app validation, and also realcar testing, with which over 70% of all the uncovered commands are validated. We observe no inconsistency in cross-platform and cross-app validation. While there are 3 semantic inconsistency among 241 manually validated CAN bus commands from public resources and real-car testing, we find that these three cases are actually caused by mistakes from app developers.” ([Wen et al., 2020, p. 1](zotero://select/library/items/IGAH9NP3)) 

Reverse Engineering, CAN HUNTER

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=1&annotation=EUNW7N2J) “Although CAN bus commands are highly valuable, only a small portion of them is standardized and the vast majority of them is developed privately by car manufacturers. As a result, there are usually completely different CAN bus commands across different car models [20]. Over the years, a significant amount of effort has been made to reverse engineer CAN bus commands for different car models. Currently, the stateof-the-art is to rely on dynamic testing with a real car by analyzing the repeated correlation patterns between specific CAN messages and vehicle behavior. In particular, there are two ways to do so: (i) one is to manually trigger physical actions in the car, e.g., stepping on the throttle, and then observes changes on the CAN bus [13] [4]; (ii) the other is to generate and send arbitrary CAN messages to the CAN bus, and then observe the triggered physical actions on the vehicle [38] [39]. Unfortunately, these approaches not only require a huge amount of hardware resources, e.g., real cars and testing equipment such as jack stands [38] and CLX000 CAN analyzers [4], but also are time-consuming and errorprone due to the significant manual efforts involved.” ([Wen et al., 2020, p. 1](zotero://select/library/items/IGAH9NP3))

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=2&annotation=HXTIA4K2) “In addition to revealing the syntactics of CAN bus commands, CANHUNTER also focuses on recovering the semantics to facilitate the practical usage of the commands. Prior efforts on protocol semantics recovery rely on either the keywords in the network traces (e.g., [57]) or the parameters and execution contexts of well-known APIs (e.g., [41] [25] [24]), and they mostly focus on desktop applications or malware and cannot be directly applied in our targeted domain. Interestingly, we notice that CAN bus commands are often triggered by users when using the mobile apps, and the UI-rich apps must provide clues in their user interfaces (e.g., using an unlock door button to trigger unlock door CAN bus commands). Therefore, by leveraging the semantics clues in the app, we design an app code based semantics recovery algorithm to reveal the semantics of the CAN bus commands.” ([Wen et al., 2020, p. 2](zotero://select/library/items/IGAH9NP3)) 

mobile Apps

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=2&annotation=YRFXDMM9) “The syntactics of a CAN bus command is usually presented as hexadecimal values, including its identifier and data. The identifier can be either 11 or 29 bit referring to the specific ECU that emits the command [33]. The command data contains various length of bytes ranging from 0 to 8, each” ([Wen et al., 2020, p. 2](zotero://select/library/items/IGAH9NP3)) CAN Syntactics

![](A2Y5FU3U.png)  
>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=3&annotation=A2Y5FU3U)  
([Wen et al., 2020, p. 3](zotero://select/library/items/IGAH9NP3)) 

CAN Structure

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=3&annotation=GZ634UZD) “of which stores the parameter of the command. The semantics for CAN bus commands can be generally classified into two categories: (1) control, which operates physical components of a vehicle such as unlocking doors and starting the engine, and (2) diagnosis, which queries the data of a vehicle such as speed and temperature. For each semantic meaning, there is a one-toone mapping to a CAN bus command. For instance, for Toyota Prius, the CAN bus command identifier “0x750” refers to the main body and “0x7C4” is for the air conditioning.” ([Wen et al., 2020, p. 3](zotero://select/library/items/IGAH9NP3))

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=3&annotation=67TZL7FH) “The specific syntactics and semantics of most of the CAN bus commands are not standardized, and thus they are defined privately by car manufacturers to represent various functions for different car models. This makes CAN bus commands highly diversified, and even different car models of the same brand (e.g., Audi A3 and A4) can often have completely different set of commands. For example, the command identifier “0x3B7” represents engine for BMW E65 but window for BMW E84, according to the validated commands from a car hacking forum [20].” ([Wen et al., 2020, p. 3](zotero://select/library/items/IGAH9NP3))

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=3&annotation=42M5B3UH) “Remote control. CAN bus commands can be used by mobile apps to offer remote vehicle control, which provides great convenience for users to remotely operate their vehicles such as locking doors and closing windows. For example, we find various car companion apps such as Carista, BimmerCode, and OSCC [17] that interact with vehicles by sending remote control CAN bus commands. • Vehicle diagnosis. CAN bus commands are also used for vehicle diagnosis and inspection such as monitoring the status of vehicles including reading parameters like fuel, pressure, and speed. For instance, we have noticed that various apps and dongles are developed for this purpose, including those mentioned in §II-B. • Security monitoring. CAN bus commands are also widely used in developing CAN bus firewalls (e.g., [35] [48] [47] [44] [28]), to prevent malicious message from being injected into the CAN bus. Without the knowledge of each specific CAN bus command, the security monitoring system would not work properly. • Vehicle hacking. Since CAN bus commands are essential for vehicle control and diagnosis, they can be leveraged to perform attacks on automobiles [44] [45] [46]. For instance, by injecting the corresponding CAN bus commands to an IVI system, Miller and Valasek [46] demonstrated how to shut down the engine of a Jeep Cherokee. Generally, for an attacker with little knowledge about the CAN bus protocol, she could interfere the control of a vehicle by sending random CAN bus messages. However, in order to achieve desired attack consequences on a vehicle, such as shutting down the engine or unlocking doors, one must know the precise CAN bus commands of interest in advance. • Autonomous driving. CAN bus commands are also crucial for the development of autonomous driving nowadays.” ([Wen et al., 2020, p. 3](zotero://select/library/items/IGAH9NP3)) 

Commands

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=4&annotation=UKDEQ35L) “We have examined the source code of the three notable autonomous driving software: ApolloAuto [2], Autoware [7] and Openpilot [16]. We noticed the only software interface that interacts with the vehicles is the corresponding CAN bus commands, such as braking, steering, acceleration, and checking tire pressure and fuel. Since CAN bus commands are diversified across vehicle models, ApolloAuto [2] only supports Lincoln MKZ, and Autoware only supports a few models such as Toyota Prius. At this point, these state-of-the-art autonomous driving software platforms can only support a very limited set of car models, which is partly due to the lack of the knowledge of the CAN bus commands for other car models [21].” ([Wen et al., 2020, p. 4](zotero://select/library/items/IGAH9NP3)) 

Autoware

>[Go to annotation](zotero://open-pdf/library/items/3VNDLCBM?page=14&annotation=4EESF6SV) “A prototype of CANHUNTER for both Android and iOS platforms has been developed, and applied to test 236 car companion apps from both app markets. Evaluation results show that CANHUNTER is able to uncover 182, 619 unique CAN bus commands of 360 car models from 21 car makers, and recover the semantics of 86.1% of them. Through public resources, cross validation, as well as real car tests, we have validated the syntactics and semantics of over 70% of the recovered CAN bus commands.” ([Wen et al., 2020, p. 14](zotero://select/library/items/IGAH9NP3))