---
title: Security Challenges in Autonomous Systems Design
authors: Mohammad Hamad, Sebastian Steinhorst
year: 2023
---

# Security Challenges in Autonomous Systems Design
##### Mohammad Hamad, Sebastian Steinhorst (2023)
[Zotero-Link](zotero://select/items/@hamadSecurityChallengesAutonomous2023)

Tags: #CPS #ML #Challenges #VSOC #SOC #RealAttacks #Vulnerabilities #Patching #Code #ECU #SupplyChain #OTA #ZeroTrust 

>[!ABSTRACT]-
>Autonomous systems are emerging in many application domains. With the recent advancements in artificial intelligence and machine learning, sensor technology, perception algorithms and robotics, scenarios previously requiring strong human involvement can be handled by autonomous systems. With the independence from human control, cybersecurity of such systems becomes even more critical as no human intervention in case of undesired behavior is possible. In this context, this paper discusses emerging security challenges in autonomous systems design which arise in many domains such as autonomous incident response, risk assessment, data availability, systems interaction, time and data trustworthiness, updatability, access control, as well as the reliability and explainability of machine learning methods. In all these areas, this paper thoroughly discusses the state of the art, identifies emerging security challenges and proposes research directions to address these challenges for developing secure autonomous systems.


---

# Summary

- The paper discusses the emerging security challenges in the design of **autonomous cyber-physical systems (CPS)**, particularly focusing on autonomous vehicles (AVs). It highlights the critical need for **cybersecurity measures** as these systems operate without human intervention, making them vulnerable to cyberattacks that could have direct physical consequences.
- The authors explore key challenges such as **autonomous incident response**, **risk assessment**, **data availability**, and **updatability**. They emphasize the necessity for **real-time, lightweight security solutions** that can operate efficiently within the embedded and distributed nature of AVs.
- The paper proposes research directions to address these challenges, including the integration of **machine learning (ML)** for intrusion detection and dynamic risk assessment, the use of **zero-trust architecture** for access control, and ensuring **trustworthiness** in both data and timing protocols.

# Relevancy

- **Explores Critical Security Aspects**: The focus on CAN traffic vulnerabilities, ML integration, and real-time security aligns well with your objective of testing and manipulating CAN traffic using simulations like CARLA.
- **Proposes Advanced Solutions**: The paper discusses dynamic risk assessment and the zero-trust model, offering insights that could be applied to your experimental design when simulating and testing attack scenarios.
- **Covers Real-Time Autonomous Responses**: Emphasizes the importance of real-time, autonomous responses to cyber incidents, supporting your work on testing and validating these in controlled environments.

# Notable Sections and Pages

- **Section 2: Autonomous Cybersecurity Incident Response (Pages 2-3)**: Discusses the requirements for real-time responses in autonomous systems, relevant for structuring your CAN manipulation tests and response mechanisms.
- **Section 3: Autonomous and Dynamic Cybersecurity Risk Assessment (Pages 4-5)**: Describes the need for risk assessment models that operate in real-time, crucial for designing dynamic risk evaluation processes in your simulations.
- **Section 6: Data and Time Trustworthiness (Pages 7-8)**: Explores the importance of data and time integrity in autonomous systems, relevant for ensuring the reliability of simulated attack scenarios and sensor data in CARLA.
- **Section 8: Access Control and Zero Trust (Pages 9-10)**: Provides insights into implementing zero-trust models, which could guide your approach to securing CAN traffic in simulated environments.

# Recommendations

This paper is an essential addition to your thesis literature. It provides a detailed examination of the security challenges and potential solutions in autonomous systems, offering both theoretical and practical insights applicable to your work. I recommend citing it for its thorough analysis of autonomous system vulnerabilities and its advanced security strategies.

---

# Annotations  
(11/2/2024, 9:26:11 PM)

>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=1&annotation=HFQPSSUC) “Autonomous Cyber-Physical Systems (CPSs) are a special type of CPS where human intervention is minimal or absent. These systems are emerging in numerous application domains, including autonomous vehicles, Industry 5.0 production systems, and many others. Autonomous CPSs bring forth numerous benefits, enabling tasks that were formerly reliant on human intervention to be automated, enhanced adaptability in control systems, and increased safety when appropriately designed. Designing such systems faces many challenges [35], including system complexity, heterogeneity, limited interpretability, and unpredictability due to Machine Learning (ML) methods.” ([Hamad and Steinhorst, 2023, p. 1](zotero://select/library/items/7879VL7A)) 

CPS, ML

![](TXIXS36V.png)  
>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=3&annotation=TXIXS36V)  
([Hamad and Steinhorst, 2023, p. 3](zotero://select/library/items/7879VL7A)) 

Challenges

>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=3&annotation=73RBRN7S) “To realize such capabilities, Security Operations Center (SOC) [38] or application specific SOCs, such as Vehicle Security Operation Center (vSOC) [34] [28], are utilized to facilitate monitoring and managing cybersecurity incidents. Within each SOC, numerous human experts and/or services collaborate to analyze and address reported incidents. These SOCs are generally centralized to serve multiple systems that share incident information with them [22] [2]. Nevertheless, this solution does not appear scalable or capable of delivering the near-real-time responses required for many autonomous systems, particularly within autonomous vehicles. This limitation can arise from various reasons: – Stable Connectivity: There is a crucial need for stable connectivity to facilitate the exchange of cybersecurity information data between the systems and the SOC. However, establishing and maintaining such connectivity can present challenges, especially in specific areas with mobile autonomous systems or where the connectivity becomes unavailable due to a cyberattack. – Data Volume: The substantial volume of data shared from a large number of systems can require significant processing resources and time within the SOC. – Extended Incident Response Time: The time required to address cybersecurity incidents might sometimes extend to days or weeks, even if the compromised component is critical [7].” ([Hamad and Steinhorst, 2023, p. 3](zotero://select/library/items/7879VL7A)) 

vSOC, SOC

>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=8&annotation=UTT9F4SK) “Autonomous CPSs may consist of various subsystems owned by different entities and suppliers. Take, for instance, an autonomous vehicle, which incorporates between 70 to 100 Electronic Control Units (ECUs) hosting over 100 Million lines of code. In the development of such a vehicle, numerous companies are typically involved. Within such complex systems, it’s imperative to ensure that all components, including hardware, firmware, and software, remain up-to-date, particularly in cases where patches are needed to address security vulnerabilities.” ([Hamad and Steinhorst, 2023, p. 8](zotero://select/library/items/7879VL7A)) 

Code, ECU, SupplyChain

>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=8&annotation=WHCFXKPE) “However, notable incidents like Stuxnet [24] and the WannaCry ransomware attacks [26] underscore the challenges of maintaining up-to-date systems. These attacks exploited unpatched vulnerabilities. The patches for these vulnerabilities were introduced in advance; however, many users did not adopt these updates. These examples highlight the impracticality of achieving this even when a small number of entities are responsible for the task. This raises concerns about the feasibility of keeping such systems updated, especially in scenarios where many entities need to be involved in providing updates, and no human is available to handle these updates.” ([Hamad and Steinhorst, 2023, p. 8](zotero://select/library/items/7879VL7A)) 

RealAttacks, Vulnerabilitites, Patching

>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=8&annotation=88F3M3GM) “Ensuring system updatability requires the existence of secure Over-the-Air (OTA) update mechanisms. Such mechanisms have already been developed or mandated in a few domains, such as autonomous vehicles [12]. However, in most cases, patching and software updates over-the-air are not feasible solutions for low-end devices, as they do not support such functionality [8]. Another challenge is to ensure that all components are up to date. The existence of components that use outdated software or libraries may serve as a gateway to compromise the entire system using different attacks, such as downgrade attacks. Considering the high number of entities responsible for providing security updates for differ ent components, it is possible that one or many of them may not provide such patches for various reasons. One of these reasons could be that the company no longer exists, without transferring the responsibility to update its components to another entity, or simply because the company has stopped supporting the old version of the software due to the release of a new version. To ensure continuous updatability, the autonomous system should be designed to support OTA capability, maintain upgrade dependencies, mitigate the presence of outdated components in the system (which may limit their interaction with critical components), and finally, this should be supported by standardization efforts and legal legislation to guarantee the provision of security updates for each part of the system for a particular time.” ([Hamad and Steinhorst, 2023, p. 8](zotero://select/library/items/7879VL7A)) 

OTA

>[Go to annotation](zotero://open-pdf/library/items/6PNQNQ9G?page=9&annotation=8C4CGD35) “In recent years, the concept of Zero Trust has emerged as a prominent approach in research and practical applications, particularly in response to the evolving security needs of complex systems [42]. At its core, Zero Trust challenges the traditional assumption of trust within an ecosystem. The fundamental premise is that no component or node within the autonomous system should be inherently trusted. To establish a zero trust framework, various technologies are required to support critical functions like user identification, authentication, and secure communication. This approach operates under the fundamental belief that trust cannot be assumed for any component or node within the autonomous system.” ([Hamad and Steinhorst, 2023, p. 9](zotero://select/library/items/7879VL7A)) 

ZeroTrust