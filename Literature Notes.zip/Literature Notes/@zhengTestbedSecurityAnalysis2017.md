---
title: A Testbed for Security Analysis of Modern Vehicle Systems
authors: Xi Zheng, Lei Pan, Hongxu Chen, Rick Di Pietro, Lynn Batten
year: 2017
---

# A Testbed for Security Analysis of Modern Vehicle Systems
##### Xi Zheng, Lei Pan, Hongxu Chen, Rick Di Pietro, Lynn Batten (2017)
[Zotero-Link](zotero://select/items/@zhengTestbedSecurityAnalysis2017)

Tags: #CAN #ECU #Vulnerabilities #Wireless #Infotainment #OTA #RealAttacks #RemoteAccess #RemoteAttack #Braking #BrakeAttack #FlexRay #LIN #MOST #Simulation #CANPackets #Remote #TestBeds #DDoS #StandardCAN 

>[!ABSTRACT]-
>


---

# Summary

- This paper presents a **testbed architecture** for investigating the security of modern vehicle systems, integrating real-time CAN bus simulation with a simulated infotainment system. The testbed aims to provide flexibility and configurability, allowing security experts to replicate different attack scenarios while maintaining accuracy and efficiency.
- The proposed testbed can **capture internal CAN messages** for security analysis and inject simulated attack CAN messages through the infotainment gateway. The architecture is built using **National Instruments hardware** and **LabVIEW software**, ensuring precise simulation and emulation capabilities.
- The study demonstrates the effectiveness of the testbed through an experiment involving a **Denial of Service (DoS)** attack on the CAN bus using an Android app connected to the infotainment system. The attack successfully flooded the CAN bus, causing the vehicle to stop responding to driver inputs, illustrating the testbed's capacity to simulate and analyze real-world attack scenarios.

# Relevancy

- **Focuses on CAN Traffic Manipulation**: The paper details methods for capturing and manipulating CAN messages, directly supporting your aim to simulate and test CAN vulnerabilities in environments like CARLA.
- **Demonstrates Real-World Attack Scenarios**: The experiment involving a DoS attack provides a practical example of how to structure similar tests within your simulation framework.
- **Highlights the Use of Simulation and Testbeds**: The emphasis on using hardware-in-the-loop (HIL) and software simulations aligns with your objective of testing CAN manipulation and validating vulnerabilities in a controlled, flexible environment.

# Notable Sections and Pages

- **Section III: Testbed Architecture (Pages 1091-1092)**: Details the testbed design and configuration, essential for understanding how to replicate and adapt the setup for your thesis experiments.
- **Section IV: Experiment Setup (Page 1093)**: Describes the hardware and software components used, providing a blueprint for structuring your simulation environment.
- **Experiment Results (Page 1094)**: Discusses the results of the DoS attack conducted using the testbed, relevant for validating your own CAN traffic manipulation tests.

# Recommendations

This paper is a crucial addition to your thesis literature. It offers a structured approach to developing a testbed for vehicle security testing, providing practical and detailed insights applicable to your work on simulating and manipulating CAN traffic. I recommend citing it for its comprehensive analysis of testbed architecture and real-world attack scenarios.

---

# Annotations  
(11/7/2024, 1:34:24 PM)

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1090&annotation=4UG466TZ) “Modern car systems are managed by a collection of networked Electronic Control Units (ECUs) over a network bus, the most common being the Controller Area Network (CAN) Bus. These systems manage driver displays, emission controls, engine timing and more, while also managing safety-critical functions such as braking and steering, etc. Modern cars can include up to 100 independent ECUs, or nodes, that work independently with no requirement for a central CPU, which enables a reliable communication network for the real time requirements of vehicles [16].” ([Zheng et al., 2017, p. 1090](zotero://select/library/items/8NRIFEU8)) 

CAN, ECU

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1090&annotation=SRI34J69) “However, with the advent of infotainment systems and more such systems have been integrated into vehicles (i.e., iDrive of BMW [3] and MMI of Audi [1]), which requires wireless connection to personal devices and vehicle communication with cellular networks, it has exposed the original vehicle system, especially the CAN bus, to significant external vulnerabilities that the underlying CAN bus protocol was never designed for. The potential damage that could occur from these exposures is immense, not only in regards to the cost of damages and recalls for manufacturers but also potential injury or even loss of life. Therefore, implementing security into the CAN bus should not be seen as an expense but rather an investment in order to avoid any situation where this could be possible.” ([Zheng et al., 2017, p. 1090](zotero://select/library/items/8NRIFEU8)) 

Vulnerabiltiites, Wireless, Infotainment

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1090&annotation=7LJ9IN8A) “In 2015 Chrysler had to recall over 1.5 million vehicles due to security vulnerabilities discovered in their vehicle systems, enabling remote code execution to security researchers who gained access through the cellular network [15]. In order to avoid this, several manufacturers are looking into OverThe-Air (OTA) update systems so they can patch potential vulnerabilities as they occur. OTA systems are potentially very valuable in avoiding incidents such as the one Chrysler faced and are predicted to become commonplace in infotainmentsystems, navigation, apps, telematics firmware and even individual node patching by 2022 [18]. However, the implementation of these systems, if not done correctly, could end up costing manufacturers more and expose cars to more vulnerabilities. Thus it is important to create a testbed to verify these systems in regard with security vulnerabilities. Some researchers have achieved this goal by using actual vehicles or vehicle components and although this is an effective way to produce an accurate testing environment it provides little or no flexibility in its configuration, and sometimes very costy and dangerous.” ([Zheng et al., 2017, p. 1090](zotero://select/library/items/8NRIFEU8)) 

OTA, Realattacks, remote access, attack

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1090&annotation=H962693T) “or the security analysis of modern vehicle systems which integrate original close-looped CAN bus with infotainmentsystems. We propose a novel testbed architecture for flexible, effective, and efficient vehicle security analysis. We also create a testbed prototype which is built on top of National Instruments dedicated hardware and LabVIEW software. The proposed testbed architecture is a real time simulation of a real electric vehicle system which integrates CAN bus with a simulated Infotainment system. The testbed is able to capture internal CAN messages for future security analysis and is also able to inject secuirty attack CAN messages from simulated infotainment terminals, which is one of the first kind in close loop security testbed for modern vehicle systems.” ([Zheng et al., 2017, p. 1090](zotero://select/library/items/8NRIFEU8))

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1091&annotation=54NRW8BZ) “Vehicles today have a plethora of networked independent electronic control units (ECUs) interconnected mostly by a communication message bus operating the CAN protocol. However, the security vulnerability of the underlying CAN bus has been demonstrated in many recent research [6], [9], [4], [13], [5], [14], [11], [15]. Among these work, Miller and Valasek [13], [14], [15] have presented technical solutions of compromising the security of vehicles via manipulating and hijacking on-board ECU. As a result of which, many vehicle vendors began to pay close attention to vehicular security subject to cyber attacks.” ([Zheng et al., 2017, p. 1091](zotero://select/library/items/8NRIFEU8))

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1091&annotation=ZF7UG3CA) “ubject to cyber attacks. In fact, Hoppe et al. [6] predicted the feasibility and practicality of such attacks against ECU in 2008; a simple example in [6] showed how an attacker may easily control the CAN bus and alert the driver through a message displayed on the CD player to switch off the engine. Koscher et al. [9] demonstrated in the lab that a malicious attacker can control most key vehicular functions like braking, accelerating and halting the engine despite of driver’s intervention; other auxiliary but important functions like speedometer display can also be tampered with by the attacker via a compromised ECU. In consequence, the safety of vehicle users will be severely endangered if attackers gains access to ECU” ([Zheng et al., 2017, p. 1091](zotero://select/library/items/8NRIFEU8)) 

braking

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1091&annotation=QSXRJQQK) “Furthermore, Miller et al. [15] showed that an attacker could successfully access ECU remotely. Enabling attacks from remote machine is the last straw to break the camel’s back, that is, attackers may exploit wifi to remotely crash a vehicle on the motor way at a high speed. More specifically, a communication system enabling wifi hot spot and bluetooth interconnected to an on-board ECU can be very vulnerable [15]. Because this communication system is used as a selfcontained package, there are many vehicles subject to this type of attack. According to [14], [15], there were more than 290,000 vulnerable vehicles in the United States alone.” ([Zheng et al., 2017, p. 1091](zotero://select/library/items/8NRIFEU8))

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1091&annotation=Y5BXDSRF) “A Controller Area Network (CAN) bus is a message-based protocol designed to allow devices such as microcontrollers to communicate with each other without a host computer. There are other popular in-vehicle network protocols such as FlexRay, LIN, or MOST deployed in today’s modern vehicles but CAN is one of the most prolific and so it is CAN that is the initial focus of this vehicle security testbed [12].” ([Zheng et al., 2017, p. 1091](zotero://select/library/items/8NRIFEU8)) 

Flexray, LIN, MOST

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1091&annotation=8MH7IGDC) “Real-time simulation is an "online" version of discrete-time simulation, where time moves forward in steps of pre-defined duration [17]. In our testbed, every CAN packet is an array of 6 unsigned 32 bit integers, giving a packet that’s 192 bits long. Each packet is captured inside the testbed and written to a log file on a new line as a series of 6 tab delineated 32 bit values that are displayed as a hexadecimal string. Hexadecimal was chosen as the display format as it is the default display in many dominating package sniffing tools (i.e., Wireshark). As shown in Fig. 1, the vehicle ECUs are strongly recommended to run on Field-Programmable Gate Array (FPGA) devices and a real time operating system environment for portability and avoid time synchroniation errors of the real-time simulation [2]. We also assume that in the testbed, functionality of each Electronic Control Unit (ECU) in the provided vehicle is modelled with LabVIEW software, and the specificiation of the vechile and ECUs is provided and verified by a real vehicle company to make sure the accuracy of the input specifciation to the testbed is guaranteed against the real vehicle and ECUs modelled. We also presume that the underlying simulation device vendor can also provide industrial grade add-on modules that are able to add other desired interfaces in the future, such as the FlexRay, LIN, or MOST as mentioned earlier, which can be achieved by National Instruments devices.” ([Zheng et al., 2017, p. 1091](zotero://select/library/items/8NRIFEU8)) 

Simulation, CANPacket

![](84ZYEK7Z.png)  
>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1092&annotation=84ZYEK7Z)  
([Zheng et al., 2017, p. 1092](zotero://select/library/items/8NRIFEU8)) 

Remote, testbed

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1092&annotation=8SZERC5W) “The infotainment unit receives every packet sent from the gateway and re-transmits telemetry data. Telemetry data is packaged into an array of six 32 bit signed integers. These arrays are then transmitted over UDP for the UI system on port number 8353. These arrive at the receiving port as twentyfour byte packets, that are processed and used to display the vehicles current state. The infotainment unit contains three main components CAN_UDP_Daemon, CAN_UDP_Server, and CAN_Telemetry. The Infotainment unit is running as a service and include no user interface. This unit simulates the infotainment system inside a vehicle. Start/Stop of the unit is executed from a console window within the containing operating system.” ([Zheng et al., 2017, p. 1092](zotero://select/library/items/8NRIFEU8))

infotainment

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1094&annotation=PL9SZX3Y) “To validate the effectiveness of a CAN bus attack, we conducted a number of test cases. In each of our cases, the malicious attacker could hijack the maneuver of a running vehicle. That is, the packets transmitted on the CAN bus were captured by the attacker when the attacker accessed the CAN bus via a compromised ECU component. The attacker launched an Android App which communicated to the infotainment system of our testbed. Subsequently, the vehicle navigation data will be intercepted by the attacker. In this case, we merely used the two important types — heading and acceleration data. Due to the openness of the CAN bus, the attacker can then inject forged CAN bus packets back to the testbed CAN bus. Such forged messages may perform any of the following sabotaging actions: 1) swerve to an arbitrary direction to drive the vehicle out of the road; 2) swerve back and forth to roll over the vehicle; 3) accelerate suddenly to crash the vehicle to the object in front; 4) deaccelerate suddenly to crash the vehicle to the object behind; 5) Denial of Service (DoS) attack or 6) a combination of above actions.” ([Zheng et al., 2017, p. 1094](zotero://select/library/items/8NRIFEU8))

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1094&annotation=XMBLGB6X) “In this paper, we successfully conducted DoS attack to the CAN bus on our testbed. Upon connection to the testbed, a malicious Android App began to broadcast a large number of fake CAN bus messages to the CAN bus. In fact, the App sent CAN bus packets of 6 bytes long with the arbitration id (the id for the ECU modelled) set to 1. The flood of such messages successfully disabled the routine operation of the CAN bus and caused the vehicle to stop responding to the driver’s inputs. Subsequently, the vehicle would probably to be involved with a severe traffic accident. A demo of this successful attack has been summarized in a 15 minute Youtube clip available at https://youtu.be/qm80H3sVYnE. More specifically, we captured the DoS attack packets at the gateway of our testbed. The captured data were in the string 0000 0006 0000 0000 0000 0000 0000 0001 0000 0000 0000 0000 0000 0000. That is, the DoS packets are of 6 bytes with arbitration id as 1 targeting the navigation unit on CAN0. During the period of the DoS attack, we recorded over 59, 000 CAN bus messages. The initial part of the dumped CAN bus messages looks as below: 2B D2DDE2B7 02 08 64007E99 00 2B D2DF0F57 02 08 64007E99 00 2B D2E05E31 02 08 64007E99 00 2B D2E18585 02 08 64007E99 00 2B D2E2C82E 02 08 64007E99 00 2B D2E410F0 02 08 64007E99 00 2B D2E536D9 02 08 66004870 00 2B D2E68CBB 02 08 66004870 00 2B D2E7A4E5 02 08 66004870 00 2B D2E8F460 02 08 66004870 00 2B D2EA2A12 02 08 66004870 00 2B D2EB4762 02 08 66004870 00 2B D2EC918F 02 08 66004870 00 2B D2EDB2EE 02 08 66004870 00 2B D2EEED02 02 08 66004870 00 2B D2F0449A 02 08 66004870 00 2B D2F172A5 02 08 66004870 00 2B D2F29C27 02 08 66004870 00 2B D2F3DB11 02 08 66004870 00 2B D2F5217A 02 08 66004870 00 2B D2F6338E 02 08 66004870 00” ([Zheng et al., 2017, p. 1094](zotero://select/library/items/8NRIFEU8)) 

DDoS

>[Go to annotation](zotero://open-pdf/library/items/LWZ9DK6Q?page=1095&annotation=Y6QR8GWR) “A complete copy of this dump is available at https://goo. gl/ucPmiQ. These messages clearly showed that the CAN bus was under a bombardment of regular CAN packets. It is worth noting that the first part of each CAN packet is slightly different to its neighbor message due to clock change. A complete version of the testbed prototype is available at https://github.com/bushman-rick/CAN_Gate. In summary, the above case clearly showed the effectiveness of our testbed. We also were able to spend as little as ten minutes when we switched between different attack scenarios, which is a significant improvement than the existing solutions. Furthermore, our testbed is flexible enough to be used to test any other attacks launched from the cyber space via remote connections.” ([Zheng et al., 2017, p. 1095](zotero://select/library/items/8NRIFEU8)) 

StandardCAN