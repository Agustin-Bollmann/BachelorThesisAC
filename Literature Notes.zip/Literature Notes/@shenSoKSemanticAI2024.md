---
title: "SoK: On the Semantic AI Security in Autonomous Driving"
authors: Junjie Shen, Ningfei Wang, Ziwen Wan, Yunpeng Luo, Takami Sato, Zhisheng Hu, Xinyang Zhang, Shengjian Guo, Zhenyu Zhong, Kang Li, Ziming Zhao, Chunming Qiao, Qi Alfred Chen
year: 2024
---

# SoK: On the Semantic AI Security in Autonomous Driving
##### Junjie Shen, Ningfei Wang, Ziwen Wan, Yunpeng Luo, Takami Sato, Zhisheng Hu, Xinyang Zhang, Shengjian Guo, Zhenyu Zhong, Kang Li, Ziming Zhao, Chunming Qiao, Qi Alfred Chen (2024)
[Zotero-Link](zotero://select/items/@shenSoKSemanticAI2024)

Tags: #Modules #SoK #OpenPilot #ODD #SAELevels #Perception #Localization #Prediction #Planning #Adversarial #AttackSurfaces #Status #Sensors #LiDAR #RADAR #GPS #Laser #ML #ROS #WhiteBox #GreyBox #BlackBox 

>[!ABSTRACT]-
>Autonomous Driving (AD) systems rely on AI components to make safety and correct driving decisions. Unfortunately, today’s AI algorithms are known to be generally vulnerable to adversarial attacks. However, for such AI component-level vulnerabilities to be semantically impactful at the system level, it needs to address non-trivial semantic gaps both (1) from the system-level attack input spaces to those at AI component level, and (2) from AI component-level attack impacts to those at the system level. In this paper, we define such research space as semantic AI security as opposed to generic AI security. Over the past 5 years, increasingly more research works are performed to tackle such semantic AI security challenges in AD context, which has started to show an exponential growth trend. However, to the best of our knowledge, so far there is no comprehensive systematization of this emerging research space.


---

# Summary

- The paper performs a **systematization of knowledge (SoK)** of semantic AI security in the context of autonomous driving (AD), focusing on the vulnerabilities and defenses related to AI components within these systems. It identifies the **semantic gaps** between AI component vulnerabilities and their system-level impacts, emphasizing the complexity of translating AI errors into system-wide threats.
- The authors collect and analyze **53 research papers** and categorize them based on critical security aspects like attack vectors, defense methodologies, and evaluation techniques. The paper highlights the need for improved system-level evaluations and proposes a framework called **PASS**, an open-source platform for testing and evaluating semantic AI security in AD.
- The work also identifies **six major scientific gaps**, such as the lack of system-level evaluation methodologies and the need for robust, adaptive defenses specifically targeting semantic AI vulnerabilities in autonomous vehicles.

# Relevancy

- **Covers Semantic AI Security**: The paper’s emphasis on semantic gaps in AI security for autonomous driving directly relates to your thesis's focus on testing and manipulating CAN traffic and understanding AI vulnerabilities.
- **Provides a Taxonomy of Attacks and Defenses**: The categorization of different attack vectors and defense strategies can inform the design of your experiments and testing methodologies in simulation environments like CARLA.
- **Proposes Evaluation Platforms**: The introduction of the PASS platform offers insights into developing standardized testing frameworks, relevant for structuring and validating your simulation experiments.

# Notable Sections and Pages

- **Section II: Background and Systematization Scope (Pages 2-5)**: Provides an overview of AI components in AD systems and the scope of semantic AI security, foundational for understanding how attacks target these components.
- **Section III: Systematization of Knowledge (Pages 6-11)**: Details the taxonomy of AI attacks and defense mechanisms, essential for structuring your thesis experiments on CAN traffic manipulation.
- **Section IV: Scientific Gaps and Future Directions (Pages 12-15)**: Discusses current limitations and future research areas, relevant for identifying how your work can contribute to filling these gaps.
- **Section V: PASS Evaluation Platform (Pages 16-20)**: Introduces the PASS platform for evaluating semantic AI attacks and defenses, offering a framework applicable to your CAN testing environment.

# Recommendations

This paper is a crucial addition to your thesis literature as it provides a comprehensive overview of AI vulnerabilities and defenses specific to autonomous vehicles. It offers both theoretical insights and practical recommendations for designing and testing security measures. I recommend citing it for its detailed examination of semantic AI security and its structured approach to developing testing frameworks.

---

# Annotations  
(11/3/2024, 6:02:21 PM)

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=1&annotation=29GWHG2M) “Autonomous Driving (AD) vehicles are now a reality in our daily life, where a wide variety of commercial and private AD vehicles are already driving on the road. For example, commercial AD services, such as self-driving taxis [1, 2], buses [3, 4], trucks [5, 6], delivery vehicles [7] are already publicly available, not to mention the millions of Tesla cars [8] that are equipped with Autopilot [9]. To achieve driving autonomy in complex and dynamic driving environments, AD systems are designed with a collection of AI components to handle the core decision-making process such as perception, localization, prediction, and planning, which essentially forms the “brain” of the AD vehicle.” ([Shen et al., 2024, p. 1](zotero://select/library/items/IAFR2769)) 

Modules, Taxis, Tesla

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=1&annotation=JLCGIVGH) “In this paper, we perform the first systematization of knowledge (SoK) of the growing semantic AD AI security research space. In total, we collect and analyze 53 such papers, with” ([Shen et al., 2024, p. 1](zotero://select/library/items/IAFR2769)) 

SoK

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=2&annotation=G6AF5V7G) “a focus on those published in (commonly-recognized) toptier venues across security, computer vision, machine learning, AI, and robotics areas in the past 5 years since the first one appeared in 2017 (§II-C). Next, we taxonomize them based on research aspects critical for the security field, including the targeted AI component, attack/defense goal, attack vector, attack knowledge, defense deployability, defense robustness, as well as evaluation methodologies (§III). For each research aspect, we emphasize the observed domain/problem-specific design choices, and summarize their current status and trends. Based on the systematization, we summarize 6 most substantial scientific gaps (§IV) observed based on quantitative comparisons both vertically among existing AD AI security works and horizontally with security works from closelyrelated domains (e.g., drone [24]). With these, we are able to provide insights and potential future directions not only at the design level (e.g., under-explored attack goals and vectors), but also at the research goal and methodology levels (e.g., the general lack of system-level evaluations), as well as at the community level (e.g., the substantial lacking of open-sourcing specifically for the works in the security community).” ([Shen et al., 2024, p. 2](zotero://select/library/items/IAFR2769))

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=2&annotation=3X7XDM67) “AD Levels and Deployment Status: The Society of Automotive Engineers (SAE) defines 6 AD levels – Level 0 (L0) to 5 (L5) [27], where as the level increasing, the driving is more automated. In particular, L0 refers to no automation. However, the vehicle may provide warning features such as Forward Collision Warning and Lane Departure Warning. L1 refers to driver assistance and is the minimum level of AD. In L1 vehicles, the AD system is in charge of either steering or throttling/braking. Examples of L1 features are Automated Lane Centering and Adaptive Cruise Control. L2 means partial automation, where the AD system controls both steering and throttling/braking. Although L1 and L2 can at least partially drive the vehicle, the driver must actively monitor and be ready to take over at any circumstances. When the autonomy level goes beyond L3, the driver does not need to be attentive when the AD system is operating in its Operational Design Domains (ODDs). However, in L3, the driver is required to take over when the AD system requests to do so. None of L4 and L5 vehicles require a driver seat. The difference is that L4 AD systems can only operate in limited ODDs whereas L5 can handle all possible driving scenarios. Currently, L2 AD is already widely available and targets consumer vehicles (e.g., Tesla Autopilot [9], Cadillac Super Cruise [28], OpenPilot [29]). L4 AD is under rapid deployment targeting transportation services such as self-driving taxis [1, 2], buses [3, 4], trucks [5, 6], and delivery robots [7], with some of them already entered the commercial operation stage that charges customers [30, 31].” ([Shen et al., 2024, p. 2](zotero://select/library/items/IAFR2769)) 

OpenPilot, ODD, SAELevels

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=3&annotation=D8AKGP58) “AI Components in AD Systems: The AD systems generally have multiple AI components, including perception, localization, prediction, and planning as the major categories, as shown in Fig. 2. Perception refers to perceiving the surrounding environments and extracting the semantic information for driving, such as road object (e.g. pedestrian, vehicles, obstacles) detection, object tracking, segmentation, lane/traffic light detection. Perception module usually takes diverse sensor data as the inputs, including camera, LiDAR, RADAR, etc. Localization refers to finding the position of the AD vehicle relative to a reference frame in an environment [32]. Prediction aims to estimate the future status (position, heading, velocity, acceleration, etc.) of surrounding objects. Planning aims to make trajectory-level driving decisions (e.g., cruising, stopping, lane changing, etc.) that are safe and correct (e.g., conforming to traffic rules). Besides such modular design, people also explored end-to-end DNN models for AD. Currently, since the modular design is easier to debug, interpret, and hard-code safety rules/measures, it is predominately adopted in industrygrade AD systems, while the end-to-end designs are only for demonstration purposes [33]. For more details, we refer the readers to recent surveys [32–35].” ([Shen et al., 2024, p. 3](zotero://select/library/items/IAFR2769)) 

Modules, percepion, localization, prediction, planning

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=3&annotation=TSHX9MZ2) “Recent works find that AI models are generally vulnerable to adversarial attacks [12, 36] Some works further explored such attacks in the physical world [18, 19, 37, 38]. With that, some defenses [39,40] are proposed recently to defend against such attacks. Such AI attacks/defenses are directly related to AD systems due to the high reliance on AI components (§II-A2). However, as described in §I, generic AI componentlevel vulnerabilities do not necessarily lead to system-level vulnerabilities due to the general system-to-AI and AI-tosystem semantic gaps. In this paper, we thus focus on the works that address semantic AI security in the AD context.” ([Shen et al., 2024, p. 3](zotero://select/library/items/IAFR2769)) 

Adversarial

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=4&annotation=5C83PI6G) “Status and trends. The targeted AI components in the existing works are summarized in Tables I and II. As shown in the tables and Fig. 6 in Appendix, most (>86%) of the existing works target perception, while localization, chassis, and endto-end driving are all less or equal to 6.2%. Among the perception works, the two most popular ones are camera (60.0%) and LiDAR (21.5%) perception. More detailed summary of their designs, applications in AD systems, and vulnerabilities are in Appendix A. Currently, none of the existing works study the downstream AI components such as prediction and planning, which will be discussed more in §IV-D.” ([Shen et al., 2024, p. 4](zotero://select/library/items/IAFR2769)) 

attacksurfaces

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=4&annotation=N8F9SGQW) “Status and trends. Vast majority (96.3%) of existing works focus on integrity, while only 3.7% are on confidentiality and so far none of them are on availability. More discussion on this are in §IV-E.” ([Shen et al., 2024, p. 4](zotero://select/library/items/IAFR2769)) 

satus

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=I56A4AQ7) “Sensor attack vectors: • LiDAR spoofing refers to injecting additional points in the LiDAR point cloud via laser shooting. Prior works carefully craft the injected point locations to fool the LiDAR object detection [19, 81, 85]. • RADAR spoofing refers to injecting malicious signals to RADAR inputs to cause it to resolve fake objects at specific distances and angles. Prior work [89] demonstrates RADAR spoofing capability in physical world and shows that it can cause AD system to recognize fake obstacles. • GPS spoofing refers to sending fake satellite signals to the GPS receiver, causing it to resolve positions that are specified by the attacker. Prior works leverage GPS spoofing to attack MSF localization [92], LiDAR object detection [86], and traffic light detection [80]. • Laser/IR light refers to injecting/projecting laser or light directly to the sensor rather than the environment. Prior works use such attack vector to project malicious light spots in the camera image such that it can misguide the camera localization [67] or object detection [67, 72]. Moreover, some prior works also use it to cause camera effects such as lens flare [58] and rolling shutter effect [68] in order to fool the object detection. • Acoustic signal has been shown to disrupt or control the outputs of Inertial Measurement Units (IMUs) [99, 100]. Prior work [65] used this attack vector to attack the camera stabilization system, which has built-in IMUs, to manipulate the camera object detection results. • Translucent patch refer to sticking translucent films with color spots on camera lens. It can cause misdetect road objects such as vehicles and STOP signs [70].” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

Sensors, LiDAR, RADAR, GPS, Laser

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=6Q8EXR3P) “ML backdoor is an attack that tampers the training data or training algorithm to allow the model to produce desired outputs when specific triggers are present. Prior work [93] leverages this to attack the end-to-end driving model by presenting the trigger on a roadside billboard.” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

ML

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=YICFC8XH) “Malware & software compromise is generic cyber-layer attack vectors assumed in prior works to eavesdrop or modify sensor data [75], or execute malicious programs alongside the AI components [59, 91]. Particularly, a domain-specific instance is the Robot Operating System (ROS) node compromises [59], which can modify intercomponent messages within ROS-based AD systems, e.g., Apollo v3.0 and earlier [101] and Autoware [102].” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

ROS

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=TYW2RISH) “Status and trends. As shown in Table I, existing works predominantly adopt physical-layer attack vectors, with 63.0% and 27.8% using physical-world and sensor attack vectors, respectively. Among the physical-world ones, object texture is the most popular (half of the all attacks). This is likely because such attack vectors are direct physical-world adaptations of the digital-space perturbations in general adversarial attacks. In contrast, only 6 (11.1%) attacks leverage cyber-layer attack vectors. More discussions on this are in §IV-C.” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

status

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=66U84VFS) “White-box. This setting assumes that the attacker has complete knowledge of the AD system, including the design and implementation of the targeted AI components, corresponding sensor parameters, etc. Among existing attacks, such whitebox setting is the most commonly-adopted (Table I).” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

whitebox

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=NY9RXA2G) “Gray-box. This setting assumes that part of the information required by white-box attacks is unavailable. Prior gray-box attacks all assume the lack of knowledge of AI model internals such as weights. However, some works still require confidence scores in the model outputs [56,63–65,71,79,83,84], and some require detailed sensor parameters [65, 67, 89].” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

grey box

[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=UF8RQ45A) “b” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769))

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=N7A35MHN) “Black-box. This is the most restrictive setting where the attacker cannot access any of the internals in the AD vehicle. Prior works that belong to this category are either transferbased attacks [66, 69], which generate attack inputs based on local white-box models, or the ones that do not require any model-level knowledge in attack generation [68, 81].” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

black box

>[Go to annotation](zotero://open-pdf/library/items/3URBRLFJ?page=6&annotation=X8S2IWH2) “Status and trends. As shown in Table I, existing works commonly assume the white-box settings in their attack designs (66.7%). However, in recent years, we start to see increasing research efforts in the more challenging but also more practical attack settings, i.e., gray-box (24.1%) and black-box (9.3%), mostly published in recent two years (except one). This greatly benefited the practicality and realism of this research space, and also shows that the community practices have evolved significantly from earlier years [22, 23].” ([Shen et al., 2024, p. 6](zotero://select/library/items/IAFR2769)) 

status