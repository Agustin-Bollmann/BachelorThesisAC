---
title: A Model-Based Security Testing Approach for Automotive Over-The-Air Updates
authors: Shahid Mahmood, Alexy Fouillade, Hoang Nga Nguyen, Siraj A. Shaikh
year: 2020
---

# A Model-Based Security Testing Approach for Automotive Over-The-Air Updates
##### Shahid Mahmood, Alexy Fouillade, Hoang Nga Nguyen, Siraj A. Shaikh (2020)
[Zotero-Link](zotero://select/items/@mahmoodModelBasedSecurityTesting2020)

Tags: #OTA #Patching #Vulnerabilities #ECU #CAN #LIN #MOST #OBD #OEM #Replay

>[!ABSTRACT]-
>Modern connected cars are exposed to various cybersecurity threats due to the sophisticated computing and connectivity technologies they host for providing enhanced user experience for their occupants by offering numerous innovative applications. While prior studies exist that explore cybersecurity challenges, tools and techniques for automotive systems, over-theair (OTA) software updates for automobiles can be exploited by the attackers to compromise vehicle security and safety has not been covered extensively. This paper presents our Model-Based Security Testing (MBST) approach, designed for cybersecurity evaluation of the OTA update system for automobiles, which has an integrated testbed and a software tool that is capable of automatically generating and executing test cases by using attack trees as an input. Integrating threat modelling in the testing provides several benefits, including clear and systematic identification of different threats. Automation of the test-case generation and execution has the obvious benefits of saving time and manual effort, as manual test-case generation is both a time-consuming and error-prone process (especially, when the testing involves several test-cases). A simple simulated attack is used to demonstrate the validity and effectiveness of our testing approach. To the best of our knowledge, there is no prior research that uses a testing approach similar to our approach for automotive OTA security evaluation.


---

# Summary

- The paper introduces a **Model-Based Security Testing (MBST)** approach for evaluating the security of automotive Over-The-Air (OTA) update systems. This approach integrates **threat modeling** using **attack trees** and automates the test-case generation and execution process. The authors use the **Uptane framework** as a reference implementation for their experiments.
- The MBST approach involves four key stages: **intelligence gathering**, **threat modeling**, **test-case generation**, and **test-case execution**. The integration of attack trees helps identify various potential threats systematically and generates test cases automatically, saving time and reducing errors.
- The authors present a simulated attack on the OTA system, demonstrating how attackers can compromise repositories hosting firmware image files and associated metadata. They highlight the effectiveness of their testbed and testing tool in identifying vulnerabilities and validating security measures.

# Relevancy

- **Focuses on Systematic Testing Approaches**: The MBST approach aligns with your goal of testing vulnerabilities in automotive systems systematically and efficiently.
- **Integrates Threat Modeling Using Attack Trees**: The use of attack trees for automatic test-case generation provides a structured methodology that you can adapt for your experiments in simulation environments like CARLA.
- **Demonstrates Real-World Scenarios**: The OTA update vulnerability assessment is an example of how the approach can be used to identify and test security weaknesses, relevant for your work on CAN traffic manipulation.

# Notable Sections and Pages

- **Section IV: MBST Approach (Pages 8-10)**: Describes the testing methodology and its integration with threat modeling, crucial for structuring your testing experiments.
- **Section V: Testbed Implementation (Pages 10-12)**: Explains the hardware and software setup of the testbed, providing insights into how to develop a similar environment for CAN traffic testing.
- **Section VI: Experimentation (Pages 12-13)**: Discusses the simulated attack on the OTA system using the Uptane framework, relevant for understanding practical applications of the testing approach.

# Recommendations

This paper is a crucial addition to your thesis literature. It offers a comprehensive and practical approach to security testing, particularly relevant for developing structured methodologies and test environments. I recommend citing it for its integration of attack trees and practical testing examples.

---

# Annotations  
(11/7/2024, 7:50:39 PM)

>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=6&annotation=7GU6SRQH) “Modern vehicles are increasingly vulnerable to cybersecurity attacks due to the embedded computing and internet connectivity capabilities they are equipped with. As cyberattacks have the potential to seriously undermine the safety of an automobile and its occupants, effective testing for detecting software flaws and weaknesses is crucial. The software and firmware installed on these in-vehicle embedded computing devices need regular updates, carrying critical security patches, bug fixes, and other enhancements for improved functionality. Previously, installation of these updates required the vehicles to visit the dealership’s service centres (which is still the case for updating the firmware of safety-critical components including braking, steering and engine control etc.), via onboard diagnostic ports. OTA software update system has emerged as a convenient, efficient, and cost-effective alternative for delivering updates to automobiles remotely, which offers many benefits including significantly reduced costs and opportunity for continuous, seamless improvement.” ([Mahmood et al., 2020, p. 6](zotero://select/library/items/F4VXEDE2)) 

OTA, Patching

>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=7&annotation=F94AQVQ5) “Santos et al. [29] propose their automotive cybersecurity testing framework, which uses CSP for representing the models of the vehicle’s bus systems as well as a set of attacks against these systems. CSP - a language with its own syntax and semantics - is a process-algebraic formalism used to model and analyze concurrent systems. Using CSP, they create architectures of the vehicle’s network and bus systems along with the attack models. One of the key challenges that authors claim to address in their work is the scalability of the testing in distributed environments. Their system model is comprised of networks, bus systems connected to each network, and the gateways. Additionally, network parameters, such as latency can also be modelled. An attack model is also created, defining the attackers’ capabilities as channels. An attacker’s capabilities may include command spoofing, communication disruption, eavesdropping and influencing behaviours of the system. According to the authors, the ability for a detailed definition of the scope of the attack and test cases is a key advantage of using these models for security testing.” ([Mahmood et al., 2020, p. 7](zotero://select/library/items/F4VXEDE2))


>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=7&annotation=7V5LTDLT) “Modern automobiles are exposed to numerous cybersecurity threats due to their builtin powerful computing and communication capabilities. Identifying vulnerabilities and security flaws in the communication and other onboard technologies in connected cars is critical, as cybercriminals can exploit those weaknesses for gaining access to the safety-critical systems of the vehicle.” ([Mahmood et al., 2020, p. 7](zotero://select/library/items/F4VXEDE2)) vulnerabiliites


>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=7&annotation=3EJ3PDJT) “Most cars today host many computing devices, known as Electronic Control Units (ECUs). Each ECU has specific responsibilities, and they may need to communicate with each other and with the external world for successful completion of their tasks. For local communication, they rely on one or more of the in-vehicle communication networks, such as Controller Area Network (CAN), Local Interconnect Network (LIN), FlexRay, and Media-Oriented Systems Transport (MOST). Each type of network has been designed to support applications with different needs. For example, while LIN is mostly used for low-speed applications, applications requiring high-speed data-transfers use MOST [14]. Legally mandated Onboard Diagnostic (OBD) ports in the modern vehicles are used for ECU firmware updates, repairing and inspections of the vehicle. They are also used for reporting the data gathered by various sensors in the car to the outside world, providing information on the health status of the vehicle [31].” ([Mahmood et al., 2020, p. 7](zotero://select/library/items/F4VXEDE2)) 

ECU, CAN, LIN, MOST, OBD

>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=7&annotation=X7IX2LGX) “There are several entry points that attackers can take advantage of for breaking into a vehicle’s internal system, which have been extensively explored and presented by previous studies. For example, [4], [16], [27] explore CAN exploitation, [24] reports attacks leveraging OBD port, and security issues related to in-vehicle infotainment are presented in [18]. Overthe-air (OTA) software update systems for automobiles can also be targeted by hackers in several different ways, as described in [20] for compromising the security and safety of the connected vehicles. While automotive OTA offers numerous benefits (e.g., seamless delivery of software updates remotely), presence of security flaws and vulnerabilities in such systems can be exploited by adversaries to undermine the security of connected cars. For example, attackers can compromise the repositories that host the software updates, as described by Kuppusamy et al. in [20]. Various testing methods (for example, [2], [3], [6][8], [11], [12], [15], [22], [29]) and testing environments (e.g., [10], [13], [32], [35], [36]) have been proposed for the security testing of automotive systems. These testbeds and techniques have been designed primarily for discovering security flaws in vehicular networks (e.g., CAN, MOST, LIN, etc.), ECUs, and IVIs. Cybersecurity testing of the automotive OTA software update systems has not been considered by these works.” ([Mahmood et al., 2020, p. 7](zotero://select/library/items/F4VXEDE2)) 

OTA

>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=10&annotation=AEMJFV78) “There are several types of potential attacks that could be launched against the OTA systems, including eavesdrop attack, replay attack, deny update installation attack, rollback attack, arbitrary software attack and so on. Our simulation attack attempts to compromise both the Image and Director repositories in order to add malicious contents to the firmware images (or new images with malicious contents embedded). Our threat model assumes that the attacker has gained full access to the OEM repositories (i.e. Image Repository and Director Repository), and has been able to compromise the keys. Following are the details of our attack that we launch by following the four stages of our testing approach (see Figure 2), comprising four different stages.” ([Mahmood et al., 2020, p. 10](zotero://select/library/items/F4VXEDE2)) 

OEM, Replay,

>[Go to annotation](zotero://open-pdf/library/items/HD4WKY6V?page=11&annotation=AR8JYET5) “To launch the attack, the XML version of the attack-tree (depicted in Figure 5) was supplied to our software tool followed by executing the script file test generator.py. The tool parses the attack tree and extracts the actions to be carried out as part of the exploitation to compromise the image repositories. As shown in the screenshot in Figure 6, the test script invokes the corresponding custom methods. For example, Action 1 involves creating a new image file for which the method create image will be executed by the script; similarly, the second action (i.e., Add Image to Image Repo) invokes the method named add image to imagerepo in the custom-code file. As a result of this action, the newly created firmware image (as shown in Figure 7) file is then added to the Image Repository as depicted in Figure 8. Subsequently, the image file is signed by the Image Repository and copied to and signed by the Director Repository as can be seen in Figure 9.” ([Mahmood et al., 2020, p. 11](zotero://select/library/items/F4VXEDE2))