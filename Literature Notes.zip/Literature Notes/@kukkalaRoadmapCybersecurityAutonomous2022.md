---
title: Roadmap for Cybersecurity in Autonomous Vehicles
authors: Vipin Kumar Kukkala, Sooryaa Vignesh Thiruloga, Sudeep Pasricha
year: 2022
---

# Roadmap for Cybersecurity in Autonomous Vehicles
##### Vipin Kumar Kukkala, Sooryaa Vignesh Thiruloga, Sudeep Pasricha (2022)
[Zotero-Link](zotero://select/items/@kukkalaRoadmapCybersecurityAutonomous2022)

Tags: #CAN #LIN #FlexRay #Vulnerabilities #RealAttacks #RemoteAttack #AttackSurfaces #IDS #CAV #Network #ADAS #AI #History #Timeline #RealAttacks #WhiteBox #PhysicalAttack #KeyFob #Theft #BCM #ADAS #LiDAR #Sensor #Perception #Jamming #Spoofing #Replay #Camera #DoppelPaymer #WiFi #Worm #VANET #Authentication #Detection #GAN #DDoS #ZeroTrust #Verification #Roadmap #SAELevels #ECU #HSM #TPM #Energy #Collision #PUF #MPC #Bosch #SDL #OTA #SOTA #FOTA #Randomization #WP29 #UNECE #CSMS #SUMS #RealAccident #Platform #AUTO-ISAC #OEM #DHS #CIA #DIE #Ridesharing #SupplyChain #

>[!ABSTRACT]-
>Autonomous vehicles are on the horizon and will be transforming transportation safety and comfort. These vehicles will be connected to various external systems and utilize advanced embedded systems to perceive their environment and make intelligent decisions. However, this increased connectivity makes these vehicles vulnerable to various cyber-attacks that can have catastrophic effects. Attacks on automotive systems are already on the rise in today’s vehicles and are expected to become more commonplace in future autonomous vehicles. Thus, there is a need to strengthen cybersecurity in future autonomous vehicles. In this article, we discuss major automotive cyber-attacks over the past decade and present state-of-the-art solutions that leverage artificial intelligence (AI). We propose a roadmap towards building secure autonomous vehicles and highlight key open challenges that need to be addressed.


---

# Summary

- The paper presents a comprehensive **roadmap** for achieving cybersecurity in autonomous vehicles (AVs). It reviews major automotive cyber-attacks from the past decade and discusses state-of-the-art AI-based intrusion detection systems (IDS) aimed at protecting in-vehicle networks and vehicular ad hoc networks (VANETs).
- The authors propose several elements for building secure AV systems, including **cybersecurity-aware design practices**, securing hardware and software stacks, implementing **advanced threat intelligence**, and integrating **AI standards and regulations**. They emphasize the need for proactive, layered security mechanisms that are designed from the beginning of vehicle development.
- The paper also highlights **open challenges** such as data protection, tamper-proof AI, and the security of automotive integrated circuit (IC) supply chains, stressing the importance of emerging technologies like **blockchain** and **WiGig networks** for future AV systems.

# Relevancy

- **Discusses CAN Bus Vulnerabilities**: The paper explores vulnerabilities in CAN networks and other protocols, directly supporting your work on testing and manipulating CAN traffic in simulation environments like CARLA.
- **Emphasizes AI-Based Security Solutions**: The discussion on AI-driven IDS solutions and their application in detecting anomalies in AV systems aligns well with your focus on integrating AI in simulated CAN manipulation experiments.
- **Provides a Comprehensive Security Framework**: The proposed roadmap for cybersecurity in AVs offers a structured approach that can guide the methodology of your thesis.

# Notable Sections and Pages

- **Section II: History of Automotive Cyber-Attacks (Pages 2-4)**: Details the timeline and evolution of cyber-attacks on automotive systems, providing a historical context and understanding of common vulnerabilities in AVs.
- **Section III: AI for Intrusion Detection (Pages 5-7)**: Discusses AI-based IDS systems designed for in-vehicle and VANET security, providing models and techniques relevant for integrating AI into your testing setup.
- **Section IV: Cybersecurity Roadmap for Autonomous Vehicles (Pages 8-10)**: Outlines a detailed framework for achieving cybersecurity goals, offering insights into best practices and methodologies for securing AV systems, relevant for structuring your experimental design.

# Recommendations

This paper is an essential addition to your thesis literature. It provides a thorough analysis of the challenges and solutions in AV cybersecurity, emphasizing AI and simulation-based approaches. I recommend citing it for its comprehensive roadmap and detailed discussion of IDS solutions applicable to your thesis experiments.

---

# Annotations  
(11/1/2024, 5:28:08 PM)

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=1&annotation=3A8EJ4XK) “To meet the needs across various subsystems, a diverse set of ECUs consisting of different compute and memory capacities are used in today’s vehicles. The ECUs are distributed across the vehicle and communicate using an invehicle network. Several in-vehicle network protocols are used in modern vehicles to meet the data rate, timing, and reliability requirements of automotive subsystems. Some of the most commonly used in-vehicle network protocols include controller area network (CAN), local interconnect network (LIN), FlexRay, and Ethernet. Both ECUs and in-vehicle networks are becoming more complex to satisfy emerging autonomy needs.” ([Kukkala et al., 2022, p. 1](zotero://select/library/items/GUWRB6YV)) 

CAN, LIN, Flexray

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=1&annotation=XL6FPJFK) “Additionally, a variety of automotive subsystems rely heavily on the data from external systems as shown in Fig. 1, which makes modern vehicles highly vulnerable to various security attacks. In the past decade (2010 onwards), nearly 79.6% of all automotive attacks have been remote attacks, which do not require the attacker to be within the vicinity of the vehicle [1].” ([Kukkala et al., 2022, p. 1](zotero://select/library/items/GUWRB6YV)) 

vulnerabilities, real attacks, remote

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=1&annotation=L3NKE4VT) “A variety of attack vectors have been used including WiFi, telematics, Bluetooth, keyless entry systems, and mobile applications. We discuss many of these attacks in this article, as well as techniques that have been proposed to protect the vehicles from cyber-attacks. However, due to the overall increase of the automotive system complexity (heterogeneous ECUs, network architectures/protocols, and applications), detecting cyber-attacks is not easy, which poses a major challenge for emerging connected and autonomous vehicles (CAVs). There is a critical need for a monitoring solution that can serve as an intrusion detection system (IDS) to detect cyberattacks in vehicles. Traditionally, such IDSs in computing systems have relied on using firewalls, or rule-based systems to detect cyber-attacks. These simple systems cannot detect highly complex modern automotive attacks.” ([Kukkala et al., 2022, p. 1](zotero://select/library/items/GUWRB6YV)) 

Attack Surfaces, IDS, CAV

![](WEJXGI3G.png)  
>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=1&annotation=WEJXGI3G)  
([Kukkala et al., 2022, p. 1](zotero://select/library/items/GUWRB6YV)) 

InVehicleNetwork

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=1&annotation=V3S8RVE8) “Another interesting trend in modern vehicles is the widespread adoption of AI techniques for advanced driver assistance subsystems (ADAS), where environmental perception is required [2]. Such AI techniques can also be deployed in powerful automotive ECUs to monitor and detect cyber-attacks. AI-based solutions are well known to be highly efficient in learning the complex patterns that exist in high dimensional time-series vehicular network data. They can observe for anomalous patterns on in-vehicle networks that connect all in-vehicle and external subsystems, to detect cyberattacks. With fully autonomous vehicles supporting increased connectivity to external subsystems on the horizon, having an efficient IDS that can detect a variety of cyber-attacks using AI techniques is crucial and an urgent requirement.” ([Kukkala et al., 2022, p. 1](zotero://select/library/items/GUWRB6YV)) 

ADAS, AI

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=2&annotation=HTUSECZF) “The researchers at the University of California at San Diego and the University of Washington demonstrated one of the first vehicle hacks in 2010 [3]. They exploited the onboard telematics system and reverse-engineered the system, and were able to gain full control of the vehicle. The researchers however worked with the manufacturer and did not disclose the full details of the vulnerability. Needless to say, this hack opened up a Pandora's box. Several other works followed this approach and tried to reverse engineer the ECUs in the vehicles in the following years. However, all of these attacks required the attacker to be physically present inside the target vehicle, which resulted in dismissing as an unlikely situation and these hacks not gaining much traction in the media.” ([Kukkala et al., 2022, p. 2](zotero://select/library/items/GUWRB6YV)) 

RealAttacks, white box, physical

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=2&annotation=74874ZLW) “This changed in 2015 when the first major remote attack was demonstrated on an unaltered 2014 Jeep Cherokee [4] by two security researchers. The researchers identified a software bug in the vehicle’s infotainment system that would allow them to connect to the vehicle remotely over the 4G LTE, and send CAN messages to the ECUs in the vehicle. They demonstrated a wide range of attacks ranging from remotely controlling simple functionality such as the vehicle radio, A/C, and windshield wipers to more critical functionalities such as controlling brakes, transmission, and even killing the engine while the vehicle was on a freeway. The attackers were able to launch these attacks on a remote vehicle from their home. This hack created a huge media outburst and the manufacturer had to issue a patch to fix the bug. The same researchers in 2016 exposed another bug that let them remotely control the acceleration, steering wheel, and cruise control systems. Similar attacks came into light in 2016, where an attacker was able to remotely control a Nissan Leaf in England from Australia. These attacks changed the landscape of how automotive cyber-attacks were carried out and highlighted the urgency to address cybersecurity in vehicles.” ([Kukkala et al., 2022, p. 2](zotero://select/library/items/GUWRB6YV)) 

Remote

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=2&annotation=RFXRANWJ) “Starting around 2016, a new type of attack emerged that focused on hacking the keyless entry system in vehicles. The goal of these attacks was to steal the vehicle rather than remotely control it. The researchers at the University of Birmingham showed how they were able to recover the cryptographic algorithms and keys from the ECUs and clone the VW group remote control by eavesdropping on a single signal sent by the original remote [5]. Several other attacks have emerged that targeted mobile applications that were used for remote start and immobilizer systems in vehicles. Some of the recent attacks in this class include cloning the Tesla Model S key fob in 2018 [6] and the Tesla Model X key fob in 2019 [7]. Researchers were able to clone key fobs by capturing the Bluetooth communication between the key fob and the body control module (BCM) and were able to use a bootleg BCM to replay it and steal the vehicle in under 90 seconds.” ([Kukkala et al., 2022, p. 2](zotero://select/library/items/GUWRB6YV)) 

KeyFob, Theft, BCM

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=2&annotation=9YWTBL7I) “A different class of attacks has gained popularity since 2018, mainly targeting the ADAS systems and the onboard sensors used for perception. In [8], researchers generated various robust visual adversarial perturbations to a stop sign that resulted in it being misidentified as a 45 mph speed limit sign. A few years before this, researchers were able to blind a Mobileye C2-270 camera and demonstrate jamming, spoofing, and relay attacks on an Ibeo LUX3 LiDAR sensor [9]. More recent attacks include tricking lane change system of a Tesla Model S with bright stickers on the road by Tencent Keen security lab in 2019 [10] and object removal attacks on LiDAR sensors in 2021 [11].” ([Kukkala et al., 2022, p. 2](zotero://select/library/items/GUWRB6YV)) 

ADAS, LiDAR, Sensor, perception, jamming, spoofing, relay, camera

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=2&annotation=VHFZNFLG) “Another recent attack that made the headlines was the T-BONE attack [12] where researchers were able to gain remote code execution (RCE) over WiFi on the infotainment system in a Tesla Model 3 using a drone. They were able to remotely open doors and trunk, change seat positions, steering, and acceleration modes. However, this exploit does not provide driving control of the vehicle. The researchers also highlighted that adding a privilege escalation exploit such as CVE-20213347 to T-BONE would weaponize this exploit and turn it into a worm. This would allow them to load new WiFi firmware and exploit other Tesla cars in the victim car’s proximity. More Fig. 2. Timeline of major automotive cyber-attacks. recently, in the beginning of 2021, an online hacking group by the name DoppelPaymer claimed to conduct a ransomware attack on KIA motors America and have stolen unencrypted confidential data [13]. Thus, cyber-attacks are becoming increasingly prevalent in modern vehicles. A comprehensive taxonomy of vehicular security attacks with details related to attacker types, attack tools and actions, and attack objectives are discussed in [31].” ([Kukkala et al., 2022, p. 2](zotero://select/library/items/GUWRB6YV)) 

DoppelPaymer, Remote, WiFi, Worm

![](83NBGJUW.png)  
>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=2&annotation=83NBGJUW)  
([Kukkala et al., 2022, p. 2](zotero://select/library/items/GUWRB6YV)) 

History, timeline

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=3&annotation=JKA27QUJ) “To protect vehicles from devastating cyber-attacks, it is crucial to address cybersecurity in the automotive domain. Several lightweight authentication mechanisms such as [25] and [33], and versatile automotive security frameworks such as [26] try to improve security in resource-constrained automotive ECUs. However, these techniques mainly focus on authenticating the ECUs during the initial setup phase and cannot detect the presence of an attacker in the later stages or when an already authenticated ECU gets compromised. Thus, there is a need for an intrusion detection system (IDS) that continuously monitors the vehicular network and detects any cyber-attacks. Moreover, an IDS is extremely crucial and often the last line of defense when the attacker breaks through defense mechanisms. Traditional IDS solutions relied on firewalls or rule-based (non AI-based) systems to detect cyber-attacks. However, they are not effective against detecting sophisticated automotive attacks as they fail to capture the complex dependencies in the time-series vehicular network data. With the availability of large troves of data in vehicles from communication between ECUs and external systems, and the increased computing capabilities of ECUs, AI-based solutions can be leveraged to parse high dimensional vehicular network data. Here we discuss some recent work on AI-based IDSs that encompass monitoring and attack detection at an in-vehicle network level and vehicular ad hoc network (VANET) level.” ([Kukkala et al., 2022, p. 3](zotero://select/library/items/GUWRB6YV)) 

VANET, IDS, Authentication, detection

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=3&annotation=EG9I2JXB) “A generative adversarial neural network (GAN) based IDS was introduced in [14] that tries to learn the patterns of the message identifier (ID) in CAN data, by transforming the ID data into “CAN images”, to detect attacks. This approach employs two discriminator models to detect known and unknown attacks, respectively. The former is trained using normal and abnormal CAN images from actual vehicle data, and the latter is trained simultaneously using the adversarial process (a mix of adversarial data from the generator and normal CAN images). The second discriminator learns to detect fake CAN image that looks similar to real CAN images. This approach showed high detection accuracy against distributed denial of service (DDoS), and message injection attacks.” ([Kukkala et al., 2022, p. 3](zotero://select/library/items/GUWRB6YV)) 

GAN, CAN, DDoS

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=4&annotation=MZVGBXI9) “The modern automotive system design process also needs to employ proactive security strategies such as a zero-trust security model. This model relies on never trust, always verify principle, where no participant or transaction is trusted by default, even if they were verified earlier. Zero trust practices advocate for mutual authentication and verifying their identity and integrity. This is a prominent strategy in cloud-based systems, data centers, and corporate IT, that needs to be customized for time-critical resource-constrained automotive systems. Lastly, designing lightweight security protocols will be crucial, especially with the adoption of 5G and newer networks in VANETs that will require security-specific processing to finish within microsecond latencies to avoid missing deadlines.” ([Kukkala et al., 2022, p. 4](zotero://select/library/items/GUWRB6YV)) 

ZeroTrust, VANET, Authentication, Verification

![](IAYICMD4.png)  
>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=4&annotation=IAYICMD4)  
([Kukkala et al., 2022, p. 4](zotero://select/library/items/GUWRB6YV)) 

Roadmap

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=4&annotation=E72PTGAB) “With level-3 and level-4 autonomous vehicles involving high and full automation (as defined in SAE J3016 [34]) expected to hit the roads soon, automotive hardware and software is experiencing a paradigm shift. Modern ECUs handle various safety-critical applications such as autonomous lane change, collision avoidance, airbag deployment, etc., which makes them an attractive target for malicious attackers. One of the popular approaches to protect ECUs from being attacked is by implementing security mechanisms to authenticate and verify the identity of the components. However, this incurs high overhead on the ECUs and can jeopardize real-time operations of the vehicle. To address this, future autonomous vehicles must utilize cryptographic accelerators called hardware security modules (HSMs) to offload security tasks. Moreover, future vehicles need to employ trusted platform modules (TPMs), which provide a hardware root of trust to enable secure computing and secure key storage. A comprehensive discussion of hardware security primitives for vehicles including HSMs and TPMs is discussed in [32].” ([Kukkala et al., 2022, p. 4](zotero://select/library/items/GUWRB6YV)) 

SAELevels, ECU, HSM, TPM, Energy, Authentication, Collision

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=4&annotation=UZJ8JCBA) “Moreover, recent works such as [33] that explored the use of physically unclonable functions (PUFs), and [26] that used meta-heuristics based keymanagement can help in achieving lightweight secure ECU authentication.” ([Kukkala et al., 2022, p. 4](zotero://select/library/items/GUWRB6YV)) 

PUF, Authenticaiton

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=5&annotation=EX83YCXU) “Various other security features will also need to be supported within ECUs, such as core isolation (which protects safetycritical processes by isolating them in memory), memory integrity (to ensure malicious code is not injected in the memory corresponding to critical processes), and address space layout randomization (to randomize memory locations where the applications are loaded and protect against buffer overflow attacks). Moreover, automotive application development should adopt security development lifecycle (SDL) [28] practices that involve including the security artifacts in the software development lifecycle. Automakers need to adopt the over the air (OTA) updates as a standard practice to provide patches to the software (SOTA) and firmware (FOTA) vulnerabilities and need to include the required hardware to enable this. Currently, SOTA updates are employed by multiple automakers but FOTA updates remain uncommon. Lastly, adopting secure multi-party computation (MPC) eliminates the need for sharing data with a trusted third-party and allows collaborators to work securely on encrypted data. In 2021, Bosch launched an open-source project called Carbyne stack [29] that enables secure data processing using MPC.” ([Kukkala et al., 2022, p. 5](zotero://select/library/items/GUWRB6YV)) 

MPC, Bosch, SDL, OTA, SOTA, FOTA,Randomization

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=5&annotation=YQUL8PS7) “In 2020, the world forum for harmonization of vehicle regulations (WP. 29) of the United Nations Economic Commission for Europe (UNECE) adopted two new regulations that mandate all automakers in the 54 contracting nations to adopt cybersecurity management systems (CSMS) and software update management systems (SUMS) by July 2022.” ([Kukkala et al., 2022, p. 5](zotero://select/library/items/GUWRB6YV)) 

WP.29, UNECE, CSMS, SUMS

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=5&annotation=KXCZHDMF) “The need for this was highlighted in 2018 when a ridesharing company’s autonomous vehicle testing resulted in a fatal crash leading to the death of a pedestrian. The company did not face any criminal charges but halted testing of the autonomous vehicles.” ([Kukkala et al., 2022, p. 5](zotero://select/library/items/GUWRB6YV)) 

Real accident

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=5&annotation=3GJCF5NR) “Conducting regular vulnerability assessments and penetration testing on vehicles will be crucial and should be made just as important (and frequent) as regular vehicle maintenance. It is also important to have a common platform to share this information between different organizations to effectively tackle cyber-attacks. To solve this, the automotive information sharing and analysis center (Auto-ISAC) was formed in 2015. It consists of 52 members ranging from OEMs to Tier-N suppliers actively sharing information about cyber-threats in vehicles. Auto-ISAC also works with the U.S. Department of homeland security (DHS) to share vulnerabilities with the federal government. Such advanced threat intelligence sharing across organizations will be crucial to ensure the security of future autonomous vehicles.” ([Kukkala et al., 2022, p. 5](zotero://select/library/items/GUWRB6YV)) 

Platform, Auto-ISAC, OEM, DHS

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=5&annotation=8Y9H6ACH) “With the recent introduction of next-generation driverless ridesharing services in places such as Phoenix and San Francisco, the stakes for user data privacy now is higher than ever. For instance, attackers can use stolen user information to launch more effective socially engineered attacks. The issues of security, trust, and privacy in autonomous vehicles are presented in detail in [24]. Techniques such as confidentiality integrity availability (CIA) and distributed immutable ephemeral (DIE) models need to be adopted in the automotive domain to ensure data protection and privacy of future autonomous vehicles.” ([Kukkala et al., 2022, p. 5](zotero://select/library/items/GUWRB6YV)) 

CIA, DIE, Ridesharing

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=6&annotation=U4M5ZAFT) “As different semiconductor integrated circuit (IC) components in a vehicle are manufactured in different parts of the world today, it is crucial to have a secure supply chain. Any vulnerability induced from the supply chain in any component of the vehicle will have disastrous effects on autonomous vehicles. This issue is further exacerbated with the increasing demand for the RSUs and 5G infrastructure to enable intelligent transportation systems. A comprehensive list of IC supply chain concerns and a logic obfuscation technique to overcome them is presented in [23]. Techniques such as digital watermarking, IC fingerprinting, IC metering, etc., need to be further explored to ensure a secure supply chain.” ([Kukkala et al., 2022, p. 6](zotero://select/library/items/GUWRB6YV)) 

SupplyChain

>[Go to annotation](zotero://open-pdf/library/items/K9LX6CP9?page=6&annotation=HF2Q3WTP) “The blockchain’s decentralized ledger provides accurate and simultaneous access to different types of data, such as traffic information and better vehicle tracking information for ride-sharing applications. A blockchain-based scheme to mitigate the security and privacy issues in autonomous vehicles is discussed in [37]. However, as these technologies are still in their infancy in the automotive domain, they need to be meticulously scrutinized by characterizing vulnerabilities and exploring security mechanisms to enhance security.” ([Kukkala et al., 2022, p. 6](zotero://select/library/items/GUWRB6YV))