---
title: Adventures in Automotive Networks and Control Units
authors: Dr Charlie Miller, Chris Valasek
year: 2013
---

# Adventures in Automotive Networks and Control Units
##### Dr Charlie Miller, Chris Valasek (2013)
[Zotero-Link](zotero://select/items/@millerAdventuresAutomotiveNetworks2013)

Tags: #CAN #CANPackets #DoS #Detection #SafetySecurity 

>[!ABSTRACT]-
>


---

# Summary

- The paper provides a **comprehensive analysis** of the vulnerabilities in automotive networks, focusing on hacking techniques for manipulating various vehicle functions through the CAN bus. It examines the **CAN protocol**, electronic control units (ECUs), and methods for injecting and manipulating CAN messages.
- The researchers tested their techniques on two vehicles: a **2010 Toyota Prius** and a **2010 Ford Escape**, demonstrating how they could control critical systems like **steering, braking, acceleration, and displays**.
- The study outlines the development of **tools and frameworks** (e.g., CARSHARK and EcomCat) for capturing, decoding, and injecting CAN traffic. It also discusses safety mechanisms and the challenges associated with bypassing them, including the need for **correct timing and valid checksums**.

# Relevancy

- **Details Practical Hacking Techniques**: The paper provides in-depth methods for capturing and manipulating CAN traffic, aligning perfectly with your thesis's focus on CAN manipulation in simulated environments.
- **Explores Security and Safety Mechanisms**: The analysis of safety mechanisms and how they can be bypassed offers valuable insights for structuring your experiments and understanding the challenges you may encounter.
- **Utilizes Testing Tools**: The paper’s development and use of custom tools for manipulating CAN messages can inform the tools and methods you plan to use in CARLA simulations.

# Notable Sections and Pages

- **Electronic Control Units (Pages 7-9)**: Explains the structure and role of ECUs, foundational for understanding how to interact with and manipulate vehicle networks.
- **Injecting CAN Data (Pages 30-35)**: Details specific methods for sending CAN messages to control vehicle functions like steering and braking, directly relevant for setting up CAN traffic manipulation tests.
- **Attacks via the CAN Bus (Pages 35-50)**: Provides examples of successful attacks on both vehicles, offering practical scenarios that you could replicate in your simulated environment.
- **Detecting Attacks (Page 84)**: Discusses methods for detecting CAN traffic manipulation, which may inform the defense mechanisms you explore or propose in your thesis.

# Recommendations

This paper is an essential addition to your thesis literature. It provides practical, technical insights into CAN bus vulnerabilities and hacking techniques, directly applicable to your work on autonomous vehicle cybersecurity testing. I recommend citing it for its detailed methodologies and real-world examples of vehicle manipulation.

---

# Annotations  
(11/4/2024, 10:47:08 PM)

>[Go to annotation](zotero://open-pdf/library/items/DJRHA5BA?page=9&annotation=82TFXN7Y) “At the application layer, CAN packets contain an identifier and data. The identifier may be either 11 or 29 bits long, although for our cars only 11 bit identifiers are seen. After the identifier, there are from 0 to 8 bytes of data. There are components such as a length field and checksums at a lower level in the protocol stack, but we only care about the application layer. The data may contain checksums or other mechanisms within the 8 bytes of application-level data, but this is not part of the CAN specification. In the Ford, almost all CAN packets contain 8 bytes of data. In the Toyota, the number of bytes varies greatly and often the last byte contains a checksum of the data. As we’ll see later, there is a standard way to use CAN packets to transmit more than 8 bytes of data at a time.” ([Miller and Valasek, 2013, p. 9](zotero://select/library/items/43UFAPSH)) 

CAN, CAN packets

>[Go to annotation](zotero://open-pdf/library/items/DJRHA5BA?page=9&annotation=3H6NMPWX) “The identifier is used as a priority field, the lower the value, the higher the priority. It is also used as an identifier to help ECUs determine whether they should process it or not. This is necessary since CAN traffic is broadcast in nature. All ECUs receive all CAN packets and must decide whether it is intended for them. This is done with the help of the CAN packet identifier.” ([Miller and Valasek, 2013, p. 9](zotero://select/library/items/43UFAPSH))

>[Go to annotation](zotero://open-pdf/library/items/DJRHA5BA?page=38&annotation=EFEQYF37) “In order to cause a denial of service, we can take advantage of the way CAN networks function. Remember, CAN IDs not only serve as an identifier but are also used for arbitration if multiple packets are being sent at the same time. The way it is handled is that lower CAN IDs receive high precedent than higher ones. So if one ECU was trying to send the CAN ID 0100 and another was going to send 0101, the first one will be able to send the packet as if no other packets are around and the ECU sending the one with 0101 will wait until the other packet is transmitted. While CAN IDs are essentially meaningless, heuristically this can be used to find out which CAN packets are "important" (see histoscan.py). Anyway, the easiest way to flood a CAN network is to send packets with the CAN ID of 0000. These will be considered the highest priority and all other packets will wait for them to be transmitted. If you never stop sending these packets, no other packets will be able to be transmitted, continuously waiting for the packets with CAN ID of 0000. If you play this packet before the car is started, the automobile will not start. See video ford-flood-cant_start.mov.” ([Miller and Valasek, 2013, p. 38](zotero://select/library/items/43UFAPSH)) 

DoS

>[Go to annotation](zotero://open-pdf/library/items/DJRHA5BA?page=84&annotation=85HLCDQS) “It is pretty straightforward to detect the attacks discussed in this paper. They always involve either sending new, unusual CAN packets or flooding the CAN bus with common packets. For example, we made a capture over 22 minutes in the Ford Escape on the high speed CAN bus. This included starting and stopping the engine, driving, braking, etc. During this time there were no diagnostic packets seen. Diagnostic packets when you are not in a repair shop are an easy indicator that something strange is happening in the vehicle. Additionally, the frequency of normal CAN packets is very predictable. There were four CAN packets used earlier in this paper, 0201, 0420, 0217, and 0081. The packet 0201 had the following distribution (0201 frequency per second):” ([Miller and Valasek, 2013, p. 84](zotero://select/library/items/43UFAPSH)) 

Detection

>[Go to annotation](zotero://open-pdf/library/items/DJRHA5BA?page=86&annotation=97X59C2B) “Automobiles have been designed with safety in mind. However, you cannot have safety without security. If an attacker (or even a corrupted ECU) can send CAN packets, these might affect the safety of the vehicle. This paper has shown, for two different automobiles, some physical changes to the function of the automobile, including safety implications, that can occur when arbitrary CAN packets can be sent on the CAN bus. The hope is that by releasing this information, everyone can have an open and informed discussion about this topic. With this information, individual researchers and consumers can propose ways to make ECU’s safer in the presence of a hostile CAN network as well as ways to detect and stop CAN bus attacks. This will lead to safer and resilient vehicles in the future.” ([Miller and Valasek, 2013, p. 86](zotero://select/library/items/43UFAPSH)) 

SafetySecurity