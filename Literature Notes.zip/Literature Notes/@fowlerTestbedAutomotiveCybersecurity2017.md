---
title: Towards a Testbed for Automotive Cybersecurity
authors: Daniel S. Fowler, Madeline Cheah, Siraj Ahmed Shaikh, Jeremy Bryans
year: 2017
---

# Towards a Testbed for Automotive Cybersecurity
##### Daniel S. Fowler, Madeline Cheah, Siraj Ahmed Shaikh, Jeremy Bryans (2017)
[Zotero-Link](zotero://select/items/@fowlerTestbedAutomotiveCybersecurity2017)

Tags: #CAN #ECU #SAEJ3061 #CAN #OBD #Injection #ReverseEngineering #StandardCAN #Simulation #ECU 

>[!ABSTRACT]-
>Modern automotive platforms are cyber-physical in nature and increasingly connected. Cybersecurity testing of such platforms is expensive and carries safety concerns, making it challenging to perform tests for vulnerabilities and refine test methodologies. We propose a testbed, built over a Controller Area Network (CAN) simulator, and validate it against a real-world demonstration of a weakness in a test vehicle using aftermarket On Board Diagnostic (OBD) scanners (dongles).


---

# Summary

- The paper highlights the increasing connectivity of modern automotive platforms and the need for comprehensive cybersecurity testing. It focuses on the vulnerabilities introduced by wireless interfaces and the CAN protocol, commonly used for communication between Electronic Control Units (ECUs) in vehicles.
- The authors propose a testbed built over a **CAN simulator**, validated by demonstrating a weakness in a real vehicle using aftermarket OBD scanners. The testbed allows for **hardware-in-the-loop (HIL)** testing and aims to mitigate the high costs and safety risks associated with testing on actual vehicles.
- The case study involves using OBD dongles to inject CAN messages, revealing the potential for message manipulation and remote access threats. The testbed was effective in simulating real-world attacks and testing countermeasures in a controlled environment.

# Relevancy

1. **Focuses on Simulation-Based Testing**: The development of a CAN simulator aligns with your thesis’s objective of using simulation environments like CARLA to test and manipulate CAN traffic.
2. **Explores Remote and Physical Attack Vectors**: The paper demonstrates how OBD dongles can be used for message injection and remote manipulation, providing practical examples and methods applicable to your experiments.
3. **Supports Development of Test Methodologies**: The structured approach to building and validating a testbed provides a framework that can inform your thesis, particularly in the setup and testing of CAN vulnerabilities.

# Notable Sections and Pages

- **Section III: A Potential Solution (Pages 540-541)**: Discusses the testbed development and the use of the CAN simulator for cybersecurity testing, directly relevant for your work on simulation-based testing.
- **Case Study on OBD Dongles (Page 540)**: Provides practical examples of using OBD dongles for CAN message injection, applicable for understanding and designing similar experiments in CARLA.
- **Discussion and Further Work (Pages 541)**: Outlines the benefits and future directions of using testbeds for testing and implementing countermeasures, offering insights for expanding your research.

# Recommendations

This paper is an essential addition to your thesis literature as it offers a comprehensive approach to developing and using a testbed for automotive cybersecurity. I recommend citing it for its practical insights into CAN manipulation testing and its application of HIL systems for validating vulnerabilities and defenses.

---

# Annotations  
(11/7/2024, 12:33:37 PM)

>[Go to annotation](zotero://open-pdf/library/items/XJEYKQAN?page=1&annotation=WTPWWIVS) “The Controller Area Network (CAN) is a well established, fault tolerant and reliable communications system, widely used for command and control in cars. It is designed for data transmission between Electronic Control Units (ECUs) used throughout a vehicle. However, CAN was designed prior to the widespread introduction of vehicular wireless interfaces. There is highly cited research [1], [2] on the cybersecurity vulnerabilities of the wireless interfaces, CAN and ECUs in vehicles. The research has increased the interest in hunting for vulnerabilities in automobile systems, however, it has given vehicle manufacturers a new testing problem. Research by the Cybersecurity Group at Coventry University, along with vehicle testing specialists HORIBA MIRA, is addressing automotive security testing.” ([Fowler et al., 2017, p. 1](zotero://select/library/items/DUV3C5TQ)) 

CAN, ECU

>[Go to annotation](zotero://open-pdf/library/items/XJEYKQAN?page=1&annotation=WSPALF47) “Comprehensive safety design and functional testing of vehicle systems is part of the normal life cycle of a car [3]. However, the new cybersecurity threat to connected vehicles means manufacturers must test for a vehicle’s cyber attack resilience. Organisations have begun to address this issue with the J3061 guidelines [4]. Despite this, research tends to be directed toward finding vulnerabilities and little is directed towards the practicalities of automotive cybersecurity testing.” ([Fowler et al., 2017, p. 1](zotero://select/library/items/DUV3C5TQ)) 

SAEJ3061

>[Go to annotation](zotero://open-pdf/library/items/XJEYKQAN?page=1&annotation=TGNF4BZ8) “The legally mandated OBD port provides a direct connection to a car’s CAN bus to provide diagnostic data. Dongles connect to the OBD port, facilitating data communication with a car’s systems. Vehicle data available through the OBD port is neither encrypted nor typically access controlled. This case study used OBD dongles for several reasons: first, prior research has shown that compromise through the OBD port is a real possibility [7]. Secondly, many studies consider the OBD port to be a viable target, both through wired [1] and wireless [8] means. Thirdly, remote access to the OBD port increases the security risk as the adversary does not have to be physically present within the vehicle cabin [9]. Finally, the OBD dongles themselves have little security [8]. An experiment in this research, performed on a small hatchback from a major manufacturer, confirmed the existing threats to vehicles via such dongles.” ([Fowler et al., 2017, p. 1](zotero://select/library/items/DUV3C5TQ)) 

CAN, OBD

>[Go to annotation](zotero://open-pdf/library/items/XJEYKQAN?page=1&annotation=DC4Z4LDA) “Five OBD dongles were connected in turn to the real test vehicle. Each dongle was used to test message injection into the vehicle’s internal CAN bus. The vehicle produced 10th IEEE International Conference on Software Testing, Verification and Validation errors and undesirable behaviours when non-standard diagnostic messages were introduced. Non-diagnostic CAN messages were also injected directly and accepted by the vehicle. The CAN message definitions for a vehicle are usually confidential, however, messages that have an effect on the vehicle can be reverse engineered given time and access to the vehicle. The ease of message injection from an external source highlights the essential need for security testing by vehicle manufacturers. The risk is also increased because the injections can happen from outside the vehicle, demonstrating that cars can no longer be considered as closed boxes.” ([Fowler et al., 2017, p. 1](zotero://select/library/items/DUV3C5TQ)) 

Injection, Reverse Engineering, Standard CAN

>[Go to annotation](zotero://open-pdf/library/items/XJEYKQAN?page=2&annotation=RZXS2HEW) “A vehicle simulation is configured on the testbed. A Bluetooth-enabled dongle is connected to an OBD port on the simulator (via a custom made cable with external power to replicate the vehicle power). An unauthorised pairing with the dongle is performed. We then inject a CAN message that affects an aspect of our simulated vehicle in an undesirable manner. Messages could be injected via the aftermarket device into our model system and we were able to turn the headlights on and off (thus achieving undesirable behaviour), although the headlight in our simulation “flickered”. This is similar to the real world demonstration, where sending the message once caused the vehicle’s electronics to flicker once. This is caused by the fact that our message had to contend with continuously generated ‘true’ messages from the attendant ECUs; behaviour that our simulation also displayed. Additionally, we only configured the head light to respond. However, by creating and linking other nodes together within our simulation, it is possible to increase the complexity of the testbed functionality.” ([Fowler et al., 2017, p. 2](zotero://select/library/items/DUV3C5TQ))

>[Go to annotation](zotero://open-pdf/library/items/XJEYKQAN?page=2&annotation=7NUSPP2M) “Performing a cyber attack on a real vehicle and then the simulator has given confidence to the ongoing research project, aimed at improving vehicle cyber defenses. Having a vehicle simulator to study attacks and countermeasures has the advantage of reducing costs (material and time) and providing a safe environment to test techniques. The use of equipment common in the industry validates the ability for manufacturers to begin implementing the J3061 guidelines and bring secure design and testing into existing engineering processes (designing security into system from the beginning rather than retrofitting). The primary concern is producing simulation with enough detail to allow for simulation accuracy. This should not be an issue for manufacturers as they have access to system design. A concern for researchers who reverse engineer vehicle systems is the possible omission of design subtleties. However, the testbed will be developed to replicate real ECUs and vehicles with enough detail for it to be a useful cybersecurity testing tool.” ([Fowler et al., 2017, p. 2](zotero://select/library/items/DUV3C5TQ)) 

Simulation, ECU