---
title: "Experimental Security Assessment of BMW Cars: A Summary Report"
Security Assessment of BMW Cars: A Summary Report
authors: Keen Lab
year: 2018
---

# Experimental Security Assessment of BMW Cars: A Summary Report
##### Keen Lab (2018)
[Zotero-Link](zotero://select/items/@labExperimentalSecurityAssessment2018)

Tags: #Vulnerabilities #RemoteAttack #BMW #Bluetooth #RemoteAccess 

>[!ABSTRACT]-
>


---

# Summary

- The report examines the **infotainment system**, **telematics control unit**, and **central gateway module** of BMW vehicles, exposing potential attack vectors such as **Bluetooth**, **cellular networks**, **OBD-II**, and **USB interfaces**. The research demonstrates that these components can be exploited remotely and locally to gain control over the vehicle’s CAN bus.
- The researchers discovered **14 vulnerabilities** that could be exploited to gain remote access to critical vehicle functions, including manipulating CAN traffic. These vulnerabilities were found in components like the **NBT head unit** and **Telematics Control Box (TCB)**, affecting multiple BMW models.
- The attack chains developed show how attackers could send **unauthorized diagnostic messages** and manipulate ECUs using these vulnerabilities, highlighting the feasibility of remote attacks using cellular networks and local attacks through OBD-II and USB interfaces.

# Relevancy

- **Details Real-World Vulnerabilities**: The in-depth analysis of CAN traffic manipulation and attack vectors aligns perfectly with your thesis’s focus on testing CAN vulnerabilities in simulated environments.
- **Provides Structured Attack Chains**: The outlined attack chains offer practical scenarios that could be adapted for your experiments using simulation tools like CARLA.
- **Explores Remote and Local Attack Techniques**: The research covers both remote (e.g., cellular) and physical (e.g., OBD-II, USB) methods, providing comprehensive insights into multiple testing approaches that you might use in your thesis.

# Notable Sections and Pages

- **Section 2: Research Description (Pages 2-12)**: Provides a breakdown of the target components and the in-vehicle network structure of BMW cars, essential for structuring your experimental setup.
- **Section 3: Vulnerability Findings (Page 15)**: Details the vulnerabilities discovered, including those affecting CAN bus communication, directly applicable for understanding weaknesses you might exploit in your simulations.
- **Section 4: Attack Chains (Pages 16-18)**: Describes the development and execution of both contacted and contactless attack chains, relevant for designing CAN manipulation scenarios.
- **Section 5: Vulnerable BMW Models (Page 19)**: Lists the BMW models tested, providing insights into how these vulnerabilities may extend across different vehicle platforms.

# Recommendations

This report is a critical addition to your thesis literature. It offers a thorough examination of real-world vulnerabilities and detailed methods for exploiting CAN traffic, directly applicable to your work. I recommend citing it for its comprehensive analysis and structured approach to testing automotive cybersecurity.

---

# Annotations  
(11/7/2024, 4:48:56 PM)

>[Go to annotation](zotero://open-pdf/library/items/S4LKUMNV?page=1&annotation=2PWUZ89S) “In recent years, more and more BMW cars have been equipped with the new generation of "Internet-Connected" Infotainment system (e.g. HU_NBT/HU_ENTRYNAV) – a.k.a Head Unit – and the Telematics Control Unit (e.g. TCB). While these components have significantly improved the convenience and performance of customers’ experience, they have also introduced the opportunity for new attacks.” ([Lab, 2018, p. 1](zotero://select/library/items/R68H3Z5K)) 

Vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/S4LKUMNV?page=1&annotation=9G3QZM9D) “In our work, we systematically performed an in-depth and comprehensive analysis of the hardware and software on Head Unit, Telematics Control Unit and Central Gateway Module of multiple BMW vehicles. Through mainly focusing on the various external attack surfaces of these units, we discovered that a remote targeted attack on multiple Internet-Connected BMW vehicles in a wide range of areas is feasible, via a set of remote attack surfaces (including GSM Communication, BMW Remote Service, BMW ConnectedDrive Service, UDS Remote Diagnosis, NGTP protocol, and Bluetooth protocol). Therefore, it’s susceptible for an attacker to gain remote control to the CAN buses of a vulnerable BMW car by utilizing a complex chain of several vulnerabilities existed in different vehicle components. In addition, even without the capability of Internet-Connected, we are also able to compromise the Head Unit in physical access ways (e.g. USB, Ethernet and OBD-II). Based on our testing, we confirm that all the vulnerabilities would affect various modern BMW models.” ([Lab, 2018, p. 1](zotero://select/library/items/R68H3Z5K)) 

RemoteAttack

>[Go to annotation](zotero://open-pdf/library/items/S4LKUMNV?page=2&annotation=WNDGVUT4) “From a security point of view, modern BMW Cars expose several remote attack surfaces, as well as physical ones. In this paper, we focused on three important vehicular components: Infotainment System (a.k.a Head Unit), Telematics Control Unit and Central Gateway Module, which are susceptible to be compromised from external attacks. Based on our research of BMW Car’s invehicle network, we found all the three components working very closely with others through physical buses (e.g. USB, CAN Bus, Ethernet).” ([Lab, 2018, p. 2](zotero://select/library/items/R68H3Z5K)) 

BMW

>[Go to annotation](zotero://open-pdf/library/items/S4LKUMNV?page=17&annotation=8HU5SU65) “The contactless attack is based on the wireless interfaces of the vehicle. And in such kinds of attack chains, attackers may impact the vehicle remotely. In this part, the attack chains via Bluetooth and Cellular network will be illustrated. 4.2.1 Bluetooth Channel Bluetooth is a typical short-range communication protocol of NBT in the vehicle. With the vulnerabilities in Bluetooth Stack mentioned earlier, an attacker could affect the availability of the head unit without authentication when the Bluetooth is the pairing mode. However, such an attack could happen only when the attackers are very close to the vehicle and make the NBT work abnormally.” ([Lab, 2018, p. 17](zotero://select/library/items/R68H3Z5K)) 

Bluetooth, remote

>[Go to annotation](zotero://open-pdf/library/items/S4LKUMNV?page=22&annotation=544KT32T) “In this report, we revealed all the vulnerabilities we found in the Head Unit, Telematics Control Unit and Central Gateway Module. The vulnerabilities can be exploited by an attacker via the vehicle’s external-facing I/O interfaces, including USB, OBD-II, and Cellular network. In particular, with the Telematics Control Unit being compromised without any physical access, the attacker can remotely trigger or control vehicular functions over a wide-range distance by sending malicious CAN messages to the BMW vehicle’s internal CAN bus, whenever the car is in parking or driving mode.” ([Lab, 2018, p. 22](zotero://select/library/items/R68H3Z5K))

>[Go to annotation](zotero://open-pdf/library/items/S4LKUMNV?page=22&annotation=4GK9KNWQ) “In conclusion, our research findings have proved that it is feasible to gain local and remote access to infotainment, T-Box components and UDS communication above certain speed of selected BMW vehicle modules and been able to gain control of the CAN buses with the execution of arbitrary, unauthorized diagnostic requests of BMW in-car systems remotely” ([Lab, 2018, p. 22](zotero://select/library/items/R68H3Z5K))