---
title: Approaching the Automation of Cyber Security Testing of Connected Vehicles
authors: Stefan Marksteiner, Zhendong Ma
year: 2019
---

# Approaching the Automation of Cyber Security Testing of Connected Vehicles
##### Stefan Marksteiner, Zhendong Ma (2019)
[Zotero-Link](zotero://select/items/@marksteinerApproachingAutomationCyber2019)

Tags: #Vulnerabilities #AttackSurfaces #ECU #ExternalCommunication 

>[!ABSTRACT]-
>The advancing digitalization of vehicles and automotive systems bears many advantages for creating and enhancing comfort and safety-related systems ranging from drive-by-wire, inclusion of advanced displays, entertainment systems up to sophisticated driving assistance and autonomous driving. It, however, also contains the inherent risk of being used for purposes that are not intended for, raging from small non-authorized customizations to the possibility of full-scale cyberattacks that affect several vehicles to whole fleets and vital systems such as steering and engine control. To prevent such conditions and mitigate cybersecurity risks from affecting the safety of road traffic, testing cybersecurity must be adopted into automotive testing at a large scale. Currently, the manual penetration testing processes cannot uphold the increasing demand due to time and cost to test complex systems. We propose an approach for an architecture that (semi-)automates automotive cybersecurity test, allowing for more economic testing and therefore keeping up to the rising demand induced by new vehicle functions as well as the development towards connected and autonomous vehicles.


---

# Summary

- The paper discusses a **semi-automated approach** for cybersecurity testing of connected vehicles. It emphasizes the need for automating cybersecurity testing processes to keep up with the growing complexity and attack surfaces of modern connected and autonomous vehicles.
- The authors propose a framework that integrates **orchestration services** with test interfaces and sources of vulnerabilities (e.g., CVE databases) to streamline testing. This approach aims to enhance efficiency and consistency by automating repetitive tests typically conducted manually by experts.
- The framework is designed to test various vehicle components, including ECUs, through both **white-box** and **black-box** methodologies, leveraging both customer requirements and external threat libraries.

# Relevancy

- **Focuses on Automation in Security Testing**: The semi-automated approach aligns well with your interest in using simulation environments like CARLA for testing CAN traffic and security measures in autonomous vehicles.
- **Incorporates White-Box and Black-Box Testing**: The paper’s methodology of combining white-box (requirement-based) and black-box (threat-based) testing techniques could inform your approach when designing experiments for manipulating CAN traffic.
- **Provides a Framework for Testing**: The proposed framework is applicable when setting up your tests in CARLA and Autoware, as it offers a structured approach to managing and executing cybersecurity testing.

# Notable Sections and Pages

- **Section 1: Introduction and Motivation (Pages 1-2)**: Highlights the challenges of testing complex automotive systems and the need for automation. This is useful for justifying the use of simulation environments like CARLA in your thesis.
- **Section 2: Semi-Automated Automotive Testing (Pages 2-3)**: Describes the architecture and components of the testing framework, including the use of orchestration services and vulnerability sources. This section provides a blueprint for how you might structure your experiments using similar automated processes in CARLA.
- **Section 3: Discussion and Outlook (Pages 3-4)**: Discusses the potential of scaling the framework to industrial levels and the challenges of implementing such a system. This offers insights into the limitations of simulation environments and how they could be translated to real-world scenarios.

# Recommendations

This paper is a valuable source for your thesis, particularly in the context of developing an automated testing framework for CAN traffic manipulation and cybersecurity analysis. I recommend citing it for its structured approach and detailed explanation of integrating white-box and black-box methodologies in automotive cybersecurity testing.

---

# Annotations  
(10/29/2024, 3:54:09 PM)

>[Go to annotation](zotero://open-pdf/library/items/6QWZYZBQ?page=1&annotation=I5J793JF) “Automotive systems mainly comprise of embedded devices called Electronic Control Units (ECUs) that control various parts and functions of a vehicle. The ECUs are organized into partitioned in-vehicle networks and interact with external entities through different physical and wireless interfaces such as OBDII diagnostic port, Bluetooth, WLAN and Cellular communication. With more and more connectivity-based functions and applications, automotive systems expose large attack surface shown to be vulnerable to direct and remote cyberattacks [2, 3].” ([Marksteiner and Ma, 2019, p. 1](zotero://select/library/items/9TTDKX7L)) 

Vulnerabilities, Attack Surfaces, ECU, External communication