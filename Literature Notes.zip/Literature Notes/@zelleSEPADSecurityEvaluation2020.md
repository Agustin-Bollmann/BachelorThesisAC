---
title: SEPAD – Security Evaluation Platform for Autonomous Driving
authors: Daniel Zelle, Roland Rieke, Christian Plappert, Christoph Kraus, Dmitry Levshun, Andrey Chechulin
year: 2020
---

# SEPAD – Security Evaluation Platform for Autonomous Driving
##### Daniel Zelle, Roland Rieke, Christian Plappert, Christoph Kraus, Dmitry Levshun, Andrey Chechulin (2020)
[Zotero-Link](zotero://select/items/@zelleSEPADSecurityEvaluation2020)

Tags: #SAELevels #AttackerTypes #Attackers #Ressources #AttackerLevel #AttackSurfaces #Sensor #LiDAR #Camera #Cellular #WiFi #DAB #FM/AM #GPS #RKE #TPMS #V2X #Bluetooth #PLC #RFID/NFC #USB #CD #SD #LIN #FlexRay #MOST #Ethernet #CAN #MAC #AUTOSAR #SecOC #IPsec #OEM #Segregation #IDS #SEPAD #Communication #Components #SecurityCycle #RemoteAttack #PhysicalAttack

>[!ABSTRACT]-
>The development and evaluation of security solutions for autonomous vehicles is a challenging task. Many researchers have no access to real vehicles to implement and test their solutions. In addition, vehicle E/E architectures of different brands or even model series of one car manufacturer differ significantly. Also, vehicles may be the source of physical hazards, e.g., an exploding airbag. To enable researchers to develop, implement, and evaluate new security solutions for autonomous vehicles, we propose a new security evaluation platform called SEPAD and a dedicated development process for testing security mechanisms with it. SEPAD allows to model realistic E/E architectures where the developed security solutions can be integrated and evaluated without causing safety risks for the researcher or other road users.


---

# Summary

- The paper introduces **SEPAD**, a security evaluation platform designed for autonomous driving systems. SEPAD models realistic Electrical/Electronic (E/E) architectures and allows the integration and testing of security mechanisms without posing risks to researchers or road users.
- It supports testing various components such as **ECUs**, **sensors**, and different automotive communication technologies like CAN, FlexRay, and Automotive Ethernet. The platform can simulate and evaluate the impact of various attack types, including sensor spoofing and ECU impersonation.
- SEPAD provides a **modular and scalable** approach, making it adaptable for different architectures and enabling comprehensive testing of security protocols, intrusion detection systems (IDS), and response mechanisms.

# Relevancy

- **Focuses on Security Testing in Simulation**: The SEPAD platform provides a controlled environment for testing security mechanisms, which aligns with your use of CARLA and Autoware for simulated CAN traffic manipulation experiments.
- **Covers Various Attack Scenarios**: SEPAD's ability to model attacks such as CAN spoofing, sensor manipulation, and ECU impersonation directly supports your exploration of vulnerabilities in CAN traffic.
- **Modular Architecture for Flexibility**: The platform’s flexibility to model different E/E architectures and test security solutions can inform your methodology when integrating and testing CANToolz and Scapy in your simulation setup.

# Notable Sections and Pages

- **Section II: Related Work (Pages 2-3)**: This section discusses previous automotive security testbeds and their limitations, providing context for why SEPAD’s approach is beneficial for realistic testing in simulation environments.
- **Section III: Requirements Analysis (Pages 3-5)**: Details the attacker model and types of security mechanisms (prevention, detection, and mitigation) that can be tested with SEPAD. This is valuable for understanding the scope of your CAN manipulation experiments.
- **Section IV: SEPAD Architecture (Pages 6-9)**: Outlines the components and communication technologies supported by SEPAD, including CAN, FlexRay, and Automotive Ethernet, relevant for your simulated testing of CAN vulnerabilities.
- **Section V: Development Process for Security Mechanisms (Pages 10-12)**: Describes the iterative process for testing and adapting security strategies using SEPAD, providing a structured methodology applicable to your experiments in CARLA.

# Recommendations

This paper is an excellent addition to your thesis literature. It offers a comprehensive platform for security testing in autonomous vehicles, with specific relevance to simulating CAN vulnerabilities and testing response strategies. I recommend citing it for its detailed explanation of E/E architectures and security mechanisms, as well as its modular approach to integrating and testing security protocols.

---

# Annotations  
(10/30/2024, 7:37:37 PM)

>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=1&annotation=LW723UX2) “To address this issue, a development and evaluation platform for autonomous driving is required. Vehicular autonomy has been categorized by the Society of Automotive Engineers (SAE) in six levels from Level 0 (no automation), via Levels 1–4 (increasing driver support by automation) to Level 5 (fully autonomous). Thus, the security evaluation platform should resemble currently available real vehicles as well as possible future vehicles with increasing levels of automation. Such a platform can be used for evaluating novel security mechanisms, e.g., hardware security solutions, security protocols, or mechanisms such as Intrusion Detection and Prevention Systems (IDPS).” ([Zelle et al., 2020, p. 1](zotero://select/library/items/WF233EZZ)) 

SAELevels

![](BRK2PU3N.png)  
>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=2&annotation=BRK2PU3N)  
([Zelle et al., 2020, p. 2](zotero://select/library/items/WF233EZZ)) 

AttackerTypes, Ressources

![](WTY7ZB4C.png)  
>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=2&annotation=WTY7ZB4C)  
([Zelle et al., 2020, p. 2](zotero://select/library/items/WF233EZZ)) 

AttackerLevel

![](YT9C5ZNK.png)  
>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=3&annotation=YT9C5ZNK)  
([Zelle et al., 2020, p. 3](zotero://select/library/items/WF233EZZ)) 

AttackSurfaces, Sensor, Lidar,  camera, cellular, wlan, dab, fm/am, gps, rke, tpms, v2x, bluetooth, plc, rfid/nfc key, USB, cd, sd, LIN, flexray, most, Ethernet, CAN

>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=4&annotation=XP7DJ6SA) “SEPAD must provide support for implementing and evaluating different security protocols in realistic E/E architectures in close to real conditions. The effectiveness against different types of attacks (cf. Section III-A) and efficiency (e.g., in terms of introduced additional communication overhead) of these protocols must be analyzable. Especially, the analysis of the impact of integrating security protocols in different automotive bus systems as well as the use of different hardware trust anchors should be analyzable. Typical security protocols include MAC-based authentication schemes such as AUTOSAR’s Secure Onboard Communication (SecOC) but also more sophisticated protocols such as Internet Protocol Security (IPsec), which has been proposed to use in automotive Ethernet networks. SEPAD also supports the communication with external entities, e.g., OEM backend servers or charge points for electric vehicles. Here, typically Transport Layer Security (TLS) is used to secure the communication.” ([Zelle et al., 2020, p. 4](zotero://select/library/items/WF233EZZ)) 

MAC, AUTOSAR, SecOC, IPsec, OEM

>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=4&annotation=KBB7FKZ5) “While mitigation approaches do not prevent the attack itself, they prevent the possible impact of an attack. SEPAD must be designed to support the integration and evaluation of different mitigation approaches. This includes especially separation approaches. For example, an E/E architecture can be designed to tolerate attacks on non-critical parts, e.g., infotainment, but still preventing successful attacks on safety-critical parts such as the braking system. Separation approaches are also applicable on host-systems. For example, modern vehicles consolidate (safety-critical and not safetycritical) functionalities on one ECU which have previously been realized with multiple different ECUs. By separating these functionalities in different compartments using technologies such as separation kernel, virtualization etc., attacks could still be executed within one compartment but their impact is limited to only this compartment and cannot spread to other compartments with safety-critical functionalities.” ([Zelle et al., 2020, p. 4](zotero://select/library/items/WF233EZZ)) 

Segregation

>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=4&annotation=CQLQAHPA) “Intrusion detection systems (IDS) which monitor and analyse host systems or network traffic are well know and used in classical networks, e.g., corporate networks. In the last years, many researches developed IDS solutions for analysing the communication within vehicles. A major challenge for these approaches are the resource constraints of the ECUs in a vehicle. Thus, SEPAD must support the integration of IDS approaches to evaluate their effectiveness and efficiency in typical automotive E/E architectures. Automotive IDS research did not yet consider the novel designs of E/E architectures and how it affects the different detection techniques or the placement of the IDS. For example, an IDS placed at a gateway as a correlation sensor as proposed in [41] would allow to observe and correlate sensor values from different networks. However, a recent review of work in this area [42] shows that the majority of papers do not analyze multiple data sources for attack detection. Most papers describe solutions targeting specific well-known types of attacks such as man-in-middle or denial-of-service. Because new attack techniques are discovered, and attacks are deployed long after a vehicle has been sold, it is imperative to detect new threats and address vulnerabilities affecting released vehicles [43]. For example, bus-off attacks [44] were not known until recently. Such novel attacks can only be found by realistic evaluation models of novel E/E architectures which must be supported by SEPAD.” ([Zelle et al., 2020, p. 4](zotero://select/library/items/WF233EZZ)) 

IDS

>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=5&annotation=4ED4XPVH) “SEPAD supports various automotive communication technologies both in the in-vehicle network as well as to external entities. In particular, SEPAD utilizes Automotive Ethernet which is expected to be the predominant technology in autonomous vehicles as well as CAN and CAN FD to support also legacy ECUs. Powerline communication is used to support electric charging via ISO15118 with a charge point. For external communication, SEPAD implements Bluetooth, WLAN and cellular communication to connect to various backend systems and external devices like smartphones.” ([Zelle et al., 2020, p. 5](zotero://select/library/items/WF233EZZ)) 

SEPAD Communicaiton

![](P6ZZS4SF.png)  
>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=6&annotation=P6ZZS4SF)  
([Zelle et al., 2020, p. 6](zotero://select/library/items/WF233EZZ)) 

Component Architecture

![](Q9BMZYBH.png)  
>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=6&annotation=Q9BMZYBH)  
([Zelle et al., 2020, p. 6](zotero://select/library/items/WF233EZZ)) 

CommunicationTech

![](IXXPELAK.png)  
>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=6&annotation=IXXPELAK)  
([Zelle et al., 2020, p. 6](zotero://select/library/items/WF233EZZ)) 

Security Cycle

>[Go to annotation](zotero://open-pdf/library/items/7NFMKQHD?page=6&annotation=HHC7LN7Z) “In addition to the possible impact, SEPAD gives information about the likelihood of an attack by providing information about the preconditions for an attack or how easy it is to execute in realistic environments. For example, it can be analyzed whether an attacker can be executed remotely or only via physical access. Obviously, the first results in a much higher risk. Using this information, the researcher can use for example the method described in [55] to determine the risk in an automotive scenario.” ([Zelle et al., 2020, p. 6](zotero://select/library/items/WF233EZZ)) 

Remote, physical