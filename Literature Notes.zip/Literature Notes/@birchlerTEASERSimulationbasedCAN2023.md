---
title: "TEASER: Simulation-based CAN Bus Regression Testing for Self-driving Cars Software"
authors: Christian Birchler, Cyrill Rohrbach, Hyeongkyun Kim, Alessio Gambi, Tianhai Liu, Jens Horneber, Timo Kehrer, Sebastiano Panichella
year: 2023
---

# TEASER: Simulation-based CAN Bus Regression Testing for Self-driving Cars Software
##### Christian Birchler, Cyrill Rohrbach, Hyeongkyun Kim, Alessio Gambi, Tianhai Liu, Jens Horneber, Timo Kehrer, Sebastiano Panichella (2023)
[Zotero-Link](zotero://select/items/@birchlerTEASERSimulationbasedCAN2023)

Tags: #SDC #ECU #TEASER #SDCScissor #CARLA #BeamNGtech #CANTools #Python #PythonCAN #DevOps

>[!ABSTRACT]-
>Software systems for safety-critical systems like selfdriving cars (SDCs) need to be tested rigorously. Especially electronic control units (ECUs) of SDCs should be tested with realistic input data. In this context, a communication protocol called Controller Area Network (CAN) is typically used to transfer sensor data to the SDC control units. A challenge for SDC maintainers and testers is the need to manually define the CAN inputs that realistically represent the state of the SDC in the real world. To address this challenge, we developed TEASER, which is a tool that generates realistic CAN signals for SDCs obtained from sensors from state-of-the-art car simulators. We evaluated TEASER based on its integration capability into a DevOps pipeline of aicas GmbH, a company in the automotive sector. Concretely, we integrated TEASER in a Continous Integration (CI) pipeline configured with Jenkins. The pipeline executes the test cases in simulation environments and sends the sensor data over the CAN bus to a physical CAN device, which is the test subject. Our evaluation shows the ability of TEASER to generate and execute CI test cases that expose simulation-based faults (using regression strategies); the tool produces CAN inputs that realistically represent the state of the SDC in the real world. This result is of critical importance for increasing automation and effectiveness of simulation-based CAN bus regression testing for SDC software.


---

# Summary

- The paper introduces **TEASER**, a tool designed for **simulation-based CAN bus regression testing** for self-driving car (SDC) software. It focuses on generating realistic CAN signals derived from simulation environments such as **CARLA** and **BeamNG.tech**.
- TEASER integrates into a **DevOps pipeline**, specifically demonstrated using Jenkins, to automate the testing of electronic control units (ECUs) by sending simulated sensor data as CAN inputs. This approach aims to reduce the manual effort typically required for generating realistic CAN messages.
- The tool’s architecture supports the use of **python-can** and **cantools** libraries, enabling flexible CAN message composition and interfacing. TEASER has been validated in an industrial setting, showing a significant reduction in time required for generating and testing CAN signals.

# Relevancy

- **Focuses on CAN Bus Simulation and Testing**: TEASER’s approach to generating and testing realistic CAN messages aligns perfectly with your objective of testing CAN traffic manipulation using simulation environments like CARLA.
- **Integrates Automation in Testing**: The use of a DevOps pipeline for automating CAN testing can inform the development of your own automated testing setup for CAN traffic manipulation experiments.
- **Utilizes Simulation Environments**: The integration of CARLA and BeamNG.tech for generating CAN signals provides a direct application to your experiments, supporting the validation of your testing framework.

# Notable Sections and Pages

- **Section I: Introduction (Pages 1-2)**: Describes the motivation and challenges of CAN bus testing for self-driving cars, providing context for your focus on CAN traffic manipulation.
- **Section II: TEASER Tool Architecture (Pages 3-5)**: Details the architecture of TEASER and its integration into a DevOps pipeline, relevant for understanding how to automate your testing process.
- **Section III: Simulation Environments (Pages 5-6)**: Discusses the use of CARLA and BeamNG.tech as environments for generating CAN data, directly applicable to your simulation experiments.
- **Section V: Evaluation and Industrial Application (Pages 8-9)**: Provides results of TEASER’s effectiveness in reducing testing time and increasing realism in CAN signals, which supports the validation of similar setups in your thesis.

# Recommendations

This paper is an essential addition to your thesis literature. It provides a comprehensive framework for CAN bus testing in simulation environments and demonstrates the integration of automation, which can enhance your methodology for testing CAN traffic manipulation. I recommend citing it for its in-depth explanation of the architecture and its practical application of simulation-based testing.

---

# Annotations  
(11/2/2024, 1:55:49 PM)

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=1&annotation=TFR4BKEQ) “Testing on the system level of SDCs focuses on the correct interaction of different components of the vehicle, such as the engine control module, transmission control module, brake control module, etc. Those components, also known as electronic control units (ECUs), interact with each other with a common protocol.” ([Birchler et al., 2023, p. 1](zotero://select/library/items/GESIBSDR)) 

SDC, ECU

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=1&annotation=YM43FRSJ) “In the automotive domain, the CAN bus protocol is a widely used communication standard for ECUs [6]. CAN bus allows the communication of different ECUs in a vehicle over a shared bus system by a standardized protocol [7]. The main challenge for SDC maintainers and testers is to generate realistic test CAN signals which accurately reflect the state of an SDC in the real world since CAN signals are still manually generated for testing purposes nowadays (e.g., at aicas GmbH).” ([Birchler et al., 2023, p. 1](zotero://select/library/items/GESIBSDR)) 

CAN

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=1&annotation=MNZGZG7F) “To enable research on this problem, we developed TEASER (simulaTion basEd cAn buS tEsting), a tool for simulationbased CAN bus testing that translates simulated sensor data of an SDC, obtained from a simulation environment, for the CAN bus transmission. We conjecture the use of sensor data from multiple different simulation environments produces more realistic CAN signals for testing, which helps to detect software defects of ECUs. Furthermore, TEASER mitigates the currently common practice of manually generating CAN signals to test ECUs (as done by aicas GmbH).” ([Birchler et al., 2023, p. 1](zotero://select/library/items/GESIBSDR)) 

TEASER

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=2&annotation=P38U5KK3) “The high-level architecture of the system is illustrated in Figure 1. TEASER is fully integrated as a component in SDC-SCISSOR [16], which is a tool that uses machine learning to select simulation-based test cases for SDCs, and extends the existing tool with CAN bus functionalities. With TEASER we can generate CAN signals based on simulated scenarios from different simulators such as BeamNG.tech and CARLA. Therefore, TEASER enables regression testing based on CAN signals which are now realistically simulated by the virtual environments.” ([Birchler et al., 2023, p. 2](zotero://select/library/items/GESIBSDR)) 

SDC Scissor, CARLA, BeamNG.tech

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=2&annotation=8P6QA9NB) “TEASER’s main objective is to extend the test runner of SDC-SCISSOR to enable CAN bus testing. The tool uses two open source python libraries; the python-can 2 and cantools 3 packages. The python-can library allows communication with the CAN bus over specific interfaces (e.g., sockets). Complementary to the first package, the cantools library provides functionality to compose the can messages to send on the CAN bus. Specifically, cantools allows the user to specify a CAN database file, which defines how signals are encoded into CAN messages. The Listing 1 illustrates how the wheel speed, throttle, brake, and steering angle are encoded in a CAN message by specifying it in a CAN database file.” ([Birchler et al., 2023, p. 2](zotero://select/library/items/GESIBSDR)) 

CANTools, Python

![](6LQEAICW.png)  
>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=2&annotation=6LQEAICW)  
([Birchler et al., 2023, p. 2](zotero://select/library/items/GESIBSDR)) TEASER

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=3&annotation=BGXRMZQW) “As demonstrated in [19], SDC-SCISSOR achieves an accuracy of 70%, a precision of 65%, and a recall of 80% in selecting tests leading to a fault and improved testing cost-effectiveness. The usefulness of SDC-SCISSOR with TEASER in an industrial context is also demonstrated and explained [19], where a tester at aicas GmbH requires two days to produce CAN signals manually for 15 test cases. The automation with TEASER significantly reduces the time to generate realistic CAN signals since they are generated at runtime, where on average, a single test case in simulation with BeamNG.tech requires 49 seconds [20].” ([Birchler et al., 2023, p. 3](zotero://select/library/items/GESIBSDR)) 

SDC Scissor results

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=4&annotation=YKZDHCI3) “Furthermore, with the modular architecture of TEASER, regression testing for SDCs can be enabled in co-simulation environments by implementing the given APIs. This enables future research on SDC testing involving cosimulation environments.” ([Birchler et al., 2023, p. 4](zotero://select/library/items/GESIBSDR))

>[Go to annotation](zotero://open-pdf/library/items/V4I6YB9F?page=4&annotation=C53YYW46) “The TEASER component extends the SDC-SCISSOR tool by supporting data transmission over the CAN bus to test CAN devices. We showed the usefulness of the tool in practice by integrating it into the DevOps pipeline of aicas GmbH. The tool enables regression testing for SDC CAN devices based on signals generated from simulators such as BeamNG.tech or CARLA. We believe that TEASER enables future research on testing CAN devices and SDCs in general based on stateof-the-art simulation data.” ([Birchler et al., 2023, p. 4](zotero://select/library/items/GESIBSDR)) 

DevOps