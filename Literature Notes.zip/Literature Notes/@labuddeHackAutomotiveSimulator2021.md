---
title: Hack the automotive simulator
authors: Dirk Labudde, Heiko Polster, Markus Straßburg
year: 2021
---

# Hack the automotive simulator
##### Dirk Labudde, Heiko Polster, Markus Straßburg (2021)
[Zotero-Link](zotero://select/items/@labuddeHackAutomotiveSimulator2021)

Tags: #Braking #Vulnerabilities #Wireless #Remote #Infotainment #RemoteAttack #CAN #AttackTypes #AttackVectors #AttackSurfaces #ECU #TPMS #WLAN #OBD #CANoe #CANUtils #CANTools #Forensics 

>[!ABSTRACT]-
>The paper describes a digital simulation environment to reproduce and test attacks on Controller Area Network (CAN) bus systems. Security researchers repeatedly find vulnerabilities in different software components of networked vehicles. Since investigations on the real system seem too costly, various vehicle functions are to be tested and analysed during attacks with the help of a CAN bus simulator. This simulation environment can also be used to conduct on-site and remote training. For the simulation environment, we use the software Vector CANoe as well as CANUTILS to control and analyse the CAN bus systems. In order to be able to analyse the effects and thus the interrelationships and make them comprehensible, a CAN bus simulator was built in the form of a model car. The connection to the model is realised by means of two ESP32-EVB development boards configured as WLAN CAN gateways and a VN1610 CAN-USB interface. In the model, an AT90CAN128 development board functions as a control unit, which controls the motors and the lighting on the model car. The procedure for setting up a CAN bus simulation environment and using it to analyse and evaluate hacker attacks on automotive bus systems is described. The application possibilities show that the simulation environment can not only be used on-site, but in combination with web conferencing systems for theoretical knowledge transfer with a remote connection for solving practical tasks. It represents the most effective methodology for imparting knowledge in the field of car forensics online. Technological obstacles make it difficult to easily integrate practical tasks on real CAN bus systems into conferencing tools, as this requires a connection to the simulation hardware used. Therefore, this paper also shows how, in addition to the BigBlueButton web conferencing system, the AnyDesk remote maintenance software can be used to establish a remote connection to the control machine. Audiovisual feedback is helpful to clarify the effects of the CAN commands sent. Here, webcams are used to control the model car and a remote connection is used to enter the commands.


---

# Summary

- The paper describes a **CAN bus simulation environment** designed to reproduce and test attacks on automotive systems. The environment is built using **Vector CANoe** and **CANUTILS** to control and analyze CAN traffic within a model car.
- The simulation setup includes **ESP32-EVB development boards** configured as WLAN CAN gateways and an **AT90CAN128 development board** functioning as a control unit for the model car. This environment is used to simulate attacks and evaluate their effects.
- The authors highlight the potential of the simulator to be used in both **on-site and remote training**. The environment integrates webcams to provide visual feedback, allowing participants to observe the impact of their CAN commands on the model car remotely.

# Relevancy

- **Focuses on CAN Traffic Manipulation**: The paper’s emphasis on simulating CAN bus attacks directly aligns with your objective of manipulating CAN messages in simulation environments like CARLA.
- **Uses Practical Tools and Methods**: The description of tools like CANoe and CANUTILS provides practical guidance on setting up a testing environment, applicable to your experiments.
- **Supports Remote Training and Analysis**: The remote capabilities of the simulator align with your aim to create a flexible, controlled environment for testing and observing the impact of CAN manipulations.

# Notable Sections and Pages

- **Introduction (Page 1)**: Discusses the necessity of using simulation environments for automotive cybersecurity testing due to the high cost and risks of real-world testing.
- **Tools for CAN-Simulation (Pages 2-4)**: Details the software and hardware components, including CANoe and CANUTILS, providing insights for setting up a similar environment.
- **Simulation Environment and Use Cases (Pages 5-7)**: Explains the structure of the simulation setup and the potential for remote learning applications, offering a blueprint for developing your testing framework.

# Recommendations


---

# Annotations  
(11/7/2024, 10:26:38 PM)

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=1&annotation=85GVWRS4) “Today's motor vehicles are no longer controlled by the driver himself using wire ropes, levers or hydraulics, but via digitally networked computer systems. A depressed brake pedal no longer necessarily means that the brakes are actually applied. In modern vehicles, the software systems decide whether this actually happens. Additionally, cars are becoming increasingly networked, both internally and in relation to the outside world. This makes it possible for hackers to locate cars from the network and penetrate their systems. In the worst case, this will make them able to take control of important control systems [21]. Meanwhile, 32% of vehicles in the US are connected to the Internet [1]. In terms of new registrations of the ten largest car brands in the US, 95% are connected cars. By 2020, the three largest manufacturers - General Motors, Toyota and Ford - which together represent almost half of the US car market, had set themselves the goal of installing hardware for connected services in every sold vehicle [2].” ([Labudde et al., 2021, p. 1](zotero://select/library/items/7IMW5E4R)) 

Brakes, vulnerabitlies

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=1&annotation=7LKIEXVX) “In recent years, more and more software vulnerabilities have been found [16]. As software is continously becoming an integral component in modern cars, especially in the area of networked services, it can be assumed that more software vulnerabilities can also be found in vehicles [1][3]. In most cases, attackers penetrate the infotainment centre of vehicles via mobile wireless connections (e.g. for location or emergency call systems), where most security vulnerabilities can be found [2]. From there, it is sometimes possible to penetrate the control electronics. The biggest challenge here is to send vehicle data to the infotainment system without allowing data flow in the other direction [19][20].In this context, the question arises as to what data is actually stored and transmitted in the vehicle? This can be location data, stored routes, telephone data, error messages, time stamps, kilometre statuses or even exact parking locations of a vehicle at a defined point in time [19].” ([Labudde et al., 2021, p. 1](zotero://select/library/items/7IMW5E4R)) 

wireless, remote, infotainment

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=2&annotation=29THTE25) “The motor vehicle and the automotive industry are undergoing a noticeable transformation: electric drives, autonomous driving and smart mobility require comprehensive networking of the vehicle with its environment. According to estimates, there will be 775 million connected vehicles in 2023, which will be connected by means of in-vehicle telematics or via a smartphone app [3]. The number of cyberattacks on motor vehicles is steadily increasing. For example, 73 attacks on vehicles were recorded in the whole of 2018 and 71 vehicles have been the victims of attacks in the first four months of 2019 [4].” ([Labudde et al., 2021, p. 2](zotero://select/library/items/7IMW5E4R)) 

realattacks

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=2&annotation=PN2HHTC9) “Due to the considerable increase in possible attack vectors resulting from the networking of vehicles and the serious security deficiencies in the implementation of the CAN bus protocol, a subdivision must be made based on the access possibilities [17]. For this purpose, the following classification was established for the differentiation of attacks: direct, short-range and longe-range. It matters how these can be carried out by the attacker. Figure 1 shows a summary of the most frequent attack targets.” ([Labudde et al., 2021, p. 2](zotero://select/library/items/7IMW5E4R)) 

CAN

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=2&annotation=LGESME8Z) “In this work, attacks targeting Electronic Control Units (ECU) and in-vehicle network are specifically addressed. However, the represented simulation environment shows the opportunities to address further attack targets. The distance between the attacker and the vehicle plays a decisive role in the attack targets. Therefore, the attacks are classified according to the distance between the attacker and the vehicle. Direct attacks require direct physical access. The attacker must expose himself to the danger of implementing his attack directly, even if sometimes only briefly, on the vehicle itself. In addition, an attacker cannot determine the timing of the attack himself, but is rather dependent on the behaviour of the vehicle owner. This further limits the potential for direct attacks. Short-range attacks, on the other hand, allow the attacker to keep a certain distance from the vehicle by compromising those interfaces of the vehicle that operate wirelessly within a radius (from a few metres for Bluetooth and Tyre Pressure Monitoring System (TPMS) to approx. 100m for WLAN or remote opening systems). Long-range attacks allow the attacker to connect to the vehicle from any point, via the Internet or the mobile network, and carry out an attack. Since the attacker no longer needs to be in the immediate vicinity of a vehicle to be attacked, this greatly increases the chances that a vehicle can be attacked (see Figure 2). Thus, short- and long-range attacks can be carried out remotely. In 2019, 82% of all attacks on motor vehicles were carried out remotely (short-range and long-range) [5]. The number of attacks on motor vehicles increased significantly over the years from 2013 to 2019.” ([Labudde et al., 2021, p. 2](zotero://select/library/items/7IMW5E4R)) 

ECU, TPMS, WLAN

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=2&annotation=YGT4EIB8) “Due to cost considerations and the dangers of manipulating vehicle systems during real-world use, a simulator offers a viable alternative to conducting hacking attacks on automotive bus systems. CAN bus simulation provides a safe way to analyse what-if scenarios. For example, the effects of sending CAN bus commands via the On-board Diagnostics (OBD) socket can be tested.” ([Labudde et al., 2021, p. 2](zotero://select/library/items/7IMW5E4R)) 

OBD

![](JRCAUITT.png)  
>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=2&annotation=JRCAUITT)  
([Labudde et al., 2021, p. 2](zotero://select/library/items/7IMW5E4R)) 

Attacks

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=3&annotation=T7AIDYGK) “When developing new control units for motor vehicles, it is possible to simulate CAN bus systems using professional simulation environments. One of the tools used for this is CANoe from Vector [35]. In this tool, virtual ECUs can be tested in real CAN bus environments via a hardware interface, e.g. Vector VN1610. Within the environment, all valid CAN messages for the respective CAN system are stored in a database. These messages can be sent and received in the simulation by means of interactive generators or by virtual ECUs. The virtual ECUs are equipped with their special functionality using Communication Access Programming Language (CAPL). This type of programming is eventoriented. The control of the environment is realised with panels in which corresponding control elements, such as buttons, switches, visual displays, etc., are used. Figure 3 shows a CAN bus simulation of a virtual motor vehicle.” ([Labudde et al., 2021, p. 3](zotero://select/library/items/7IMW5E4R)) 

CANoe

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=3&annotation=G5UFVKM9) “The following tools are integrated in the CANUTILS: • candump: with candump CAN data can be displayed, filtered, logged and saved in log files. • canplayer: CAN log files can be played back with canplayer. • cansend: this tool enables the transmission of individual CAN frames. • cangen: generates random CAN traffic. • cansniffer: with the cansniffer, the traffic on the bus can be displayed live. In addition, it is possible to filter out individual CAN frames from the data stream Within the simulation environment, the CANUTILS take care of the analysis of the CAN traffic.” ([Labudde et al., 2021, p. 3](zotero://select/library/items/7IMW5E4R)) 

CANutils

>[Go to annotation](zotero://open-pdf/library/items/YNTGPLPG?page=8&annotation=2DMTDMDV) “In this paper, it was shown that a real CAN system can be simulated with the help of the presented tools. In addition, it is possible to use this simulation environment to analyse and carry out cyberattacks on vehicle CAN bus systems. A methodology and a simulation environment were described which, in addition to the classical lecture and audiovisual media, also integrate the practical part with visual feedback. The simulation environment offers the possibility to manipulate the CAN bus of the model car from the outside. Students of general and digital forensics have already been able to test this setup. The feedback was consistently positive. In particular, solving practical tasks on the real CAN bus demonstrator was mentioned positively and motivated the participants to come up with creative solutions, despite the technological obstacles, when integrating it into an online learning environment. In addition to using this in the field of car forensics, it is conceivable that other subject areas can be applied with special hardware. Use in the area of IoT (Internet of Things) forensics is conceivable here. Furthermore, it is possible to use the setup to realise more attack vectors on automotive systems. For example, the CAN bus demonstrator can be equipped with a keyless go system, which would allow replay station attacks to be realised [18]. Additionally, it would be possible to implement an intrusion detection system to filter out malicious messages in the data stream of the CAN bus. With the solution shown, challenges could be solved to be able to integrate Windows and Linux tools in an online seminar.” ([Labudde et al., 2021, p. 8](zotero://select/library/items/7IMW5E4R)) 

CAN, forensics