---
title: "AV-FUZZER: Finding Safety Violations in Autonomous Driving Systems"
authors: Guanpeng Li, Yiran Li, Saurabh Jha, Timothy Tsai, Michael Sullivan, Siva Kumar Sastry Hari, Zbigniew Kalbarczyk, Ravishankar Iyer
year: 2020
---

# AV-FUZZER: Finding Safety Violations in Autonomous Driving Systems
##### Guanpeng Li, Yiran Li, Saurabh Jha, Timothy Tsai, Michael Sullivan, Siva Kumar Sastry Hari, Zbigniew Kalbarczyk, Ravishankar Iyer (2020)
[Zotero-Link](zotero://select/items/@liAVFUZZERFindingSafety2020)

Tags: #Sensor #IMU #GPS #RADAR #LiDAR #Modules #GeneticAlgorithm #Overtaking #RealAccident #HighSpeed #Cascade

>[!ABSTRACT]-
>This paper proposes AV-FUZZER, a testing framework, to find the safety violations of an autonomous vehicle (AV) in the presence of an evolving traffic environment. We perturb the driving maneuvers of traffic participants to create situations in which an AV can run into safety violations. To optimally search for the perturbations to be introduced, we leverage domain knowledge of vehicle dynamics and genetic algorithm to minimize the safety potential of an AV over its projected trajectory. The values of the perturbation determined by this process provide parameters that define participants’ trajectories. To improve the efficiency of the search, we design a local fuzzer that increases the exploitation of local optima in the areas where highly likely safetyhazardous situations are observed. By repeating the optimization with significantly different starting points in the search space, AV-FUZZER determines several diverse AV safety violations. We demonstrate AV-FUZZER on an industrial-grade AV platform, Baidu Apollo, and find five distinct types of safety violations in a short period of time. In comparison, other existing techniques can find at most two. We analyze the safety violations found in Apollo and discuss their overarching causes.


---

# Summary

- The paper introduces **AV-FUZZER**, a testing framework designed to find safety violations in autonomous vehicle (AV) systems by manipulating the behavior of other traffic participants in the simulated environment. It uses **genetic algorithms** and domain knowledge about vehicle dynamics to create scenarios where the AV encounters safety-critical situations.
- AV-FUZZER is demonstrated using the **Baidu Apollo** platform and finds several previously undetected safety violations, showing the efficiency and effectiveness of the framework compared to other methods like random fuzzing and reinforcement learning.
- The study details how AV-FUZZER identifies different categories of safety violations and optimizes the testing process using local fuzzer and restart mechanisms.

# Relevancy

- **Focuses on Simulation-Based Testing**: The use of AV-FUZZER in a simulation environment aligns with your objective of testing autonomous vehicle systems like CARLA and Autoware for CAN traffic manipulation.
- **Explores Genetic Algorithms and Optimization**: The genetic algorithm approach to finding safety violations could inform your experimentation method when testing CAN message manipulation in various driving scenarios.
- **Provides Practical Examples**: The use of the Baidu Apollo platform and LGSVL simulator offers concrete examples of how simulation tools can be leveraged to discover AV vulnerabilities.

# Notable Sections and Pages

- **Section II: Background (Pages 2-3)**: Describes the architecture of autonomous driving systems, focusing on sensor and control modules like the CAN bus, which are relevant to your experiments.
- **Section III: AV-FUZZER Overview (Pages 4-6)**: Explains the framework’s architecture, including how the genetic algorithm works to optimize NPC (non-player character) maneuvers for testing safety violations. This is valuable for understanding how you might structure similar testing scenarios in CARLA.
- **Section V: Results (Pages 9-11)**: Details the outcomes of applying AV-FUZZER to Apollo, including the discovery of specific safety violations. This section can inform how similar results might be translated and verified in your work with CAN traffic and simulated testing environments.

# Recommendations

This paper is an excellent resource for your thesis, providing a comprehensive framework for testing autonomous vehicles and identifying software vulnerabilities using genetic algorithms. I recommend citing it for its innovative approach to using simulations for testing AV safety and for examples that demonstrate the use of simulation software effectively.

---

# Annotations  
(10/30/2024, 12:25:29 PM)

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=1&annotation=YTBV94Q4) “We demonstrate AV-FUZZER on Baidu Apollo, an industrialgrade, level-4 AV software stack widely used to control AVs on public roads [10], [11]. We find several safety-critical deficiencies in Apollo that have not been discovered or reported before, and we are able to find these safety violations in a relatively short period of search time. Specifically, we find 13 critical scenarios in which Apollo runs into hazardous situations that lead to crashes. In contrast, other techniques, such as random fuzzing and adaptive stress testing [4], find only 1 and 5 safety violations, respectively, in the same amount of search time. We then analyze the overarching causes of the safety violations AV-FUZZER reports in Apollo and characterize them into 5 distinct types that map to various categories of software deficiencies in that system. Of the 5 types, 2 mimic real-world AV accidents reported to the California DMV [12] in the past. While AV-FUZZER finds all 5 types within 20 hours of search, existing techniques [4] can find at most 2 distinct types, even given 10x the search time (200 hours).” ([Li et al., 2020, p. 1](zotero://select/library/items/I7ELCA32)) 

AV-Fuzzer, Apollo,

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=2&annotation=6BY4GJNZ) “The sensor layer preprocesses input data and filters sensor noise. An ADS supports a wide range of sensors, such as cameras, inertial measurement units (IMU), Global Positioning Systems (GPS), sonar, RADAR, and LiDAR. In this study, we use the prototype vehicle Baidu Apollo, which is equipped with two camera sensors (one at the top and another in front of the vehicle) and one LiDAR [9].” ([Li et al., 2020, p. 2](zotero://select/library/items/I7ELCA32)) 

Sensor, IMU, GPS, RADAR, LiDAR

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=2&annotation=CSYV6A6Q) “Perception Module: The perception module reads data from the sensor layer to detect static objects (e.g., lanes, traffic signs, or barriers) and dynamic objects (e.g., passenger vehicles or trucks) in the traffic environment using computer 1AV-FUZZER can be downloaded at https://github.com/cclinus/AV-Fuzzer vision and deep-learning techniques. The object detection algorithm performs tasks, such as segmentation, classification, and clustering, based on the sensor data from individual sensors. Then it uses fusion techniques such as extended Kalman filters [14], to merge the data and generate a final track list of objects. Localization Module: The localization module is responsible for providing the location of the AV. It fuses multiple sets of input data from various sources to locate the AV in the world model. It does so via aggregation of input data from GPS, IMU, and LiDAR sensors. Prediction Module: The prediction module is responsible for studying and predicting the behavior of all the objects detected by the perception module in the world model. It generates basic information on objects, such as their positions, headings, velocities, and accelerations, and then uses this data to generate predicted trajectories with probabilities for those objects. Routing Module: The routing module generates high-level navigation information based on the current location and destination of the AV. The output of the module, passage lanes, and roads are computed based on the HD map. Planning Module: The planning module generates navigation plans based on the origin and destination of the AV and computes a safe (i.e., collision-free) driving trajectory for the AV using the output data from the localization and prediction modules. Control Module: The control module takes the planned trajectory as input and generates control commands (e.g., actuation, brake, steer) to pass to the CAN bus, which delivers the information to the AV’s mechanical system.” ([Li et al., 2020, p. 2](zotero://select/library/items/I7ELCA32)) 

Modules

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=2&annotation=VMRWR9ZG) “Genetic algorithm (GA) [15], [16] is a meta-heuristic search algorithm inspired by natural evolution. The algorithm starts with an initial set of candidate solutions, which are collectively called the population. The algorithm is driven by a fitness function that computes the fitness score of a candidate. The fitness score reflects how good the candidate is at solving the problem. At each stage, some candidate solutions are chosen from the population for recombination operations. There are two types of recombination operations: (a) crossover and (b) mutation. In crossover, two candidates are randomly chosen and exchanged in the hope of generating a better solution from a good one. This operation tends to narrow the search and move toward an optimal solution. In mutation, one candidate is randomly selected. The operation flips a bit or an entity in a solution, which expands the search exploration of the algorithm. In general, recombination operations give rise to new, betterperforming members, which are then added to the population. In contrast, members that have poor fitness scores are gradually eliminated. Each such processes is called a generation and is repeated until either a population member has the desired fitness score (hence a solution is found) or the algorithm terminates upon exceeding the time allocated to it.” ([Li et al., 2020, p. 2](zotero://select/library/items/I7ELCA32)) 

Genetic Algorithm

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=8&annotation=KP5RKCWJ) “in Fig. 10 is a scenario in which the AV rearends an NPC that is trying to overtake the AV. From the AV’s perspective, the NPC is detected, moving at high speed, as early as the time the NPC came to be behind the AV. However, the AV is not able to predict the NPC’s intention to cut in front of it, and hence does not take preemptive measures to slow down and yield to the NPC. The NPC then starts merging into the AV’s lane, but the AV is moving too fast to maintain at a safe distance from the NPC, leading to the rear-end collision. Usually, this type of accident can be avoided by humans drivers, as humans can identify intentions based on early aspects of the overtaking. Those early hints enable human drivers to apply brakes earlier and likely avoid the mishap. One way to mitigate this problem in AVs is to identify such NPC maneuvers based on their trajectories and reduce speed accordingly to cooperate in the merge-in maneuver of the NPC, just as human drivers would commonly do. Unfortunately, Apollo is not equipped with such safety measures. We observe that a similar accident was recently reported by Pony.AI in Fremont, California, to the California DMV [12]. As stated in the report, a Tesla Model 3 tried to overtake the AV that Pony.Ai is test driving and to merge into the AV’s lane. Unfortunately, the AV failed to identify the intention of the Tesla and caused a rear-end collision. This indicates that the kinds of deficiencies AV-FUZZER found do exist in real-world AV systems and traffic environments.” ([Li et al., 2020, p. 8](zotero://select/library/items/I7ELCA32)) 

Overtaking, RealACcident

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=9&annotation=8EXXIYX4) “in Fig. 10 shows a generic case of an accident that Apollo usually fails to avoid. While the AV is cruising at high speed, if an NPC cuts in at very low speed from the adjacent lane, it may lead to a rear-end collision. The reason can be a combination of several possible problems in Apollo. (1) We observe that in such scenarios, Apollo usually mispredicts the future trajectory of the NPC, failing to identify the intention to overtake. The NPC trajectory prediction is done by machinelearning-based models in the Prediction Module (Section II-A). Fig. 12 shows the moment before the accident happens. As seen, the AV is not able to predict the future trajectory (which should be shown as a long tail) of the NPC, and hence fails to take preemptive action to decelerate to avoid the collision. We notice that in this case, the NPC is predicted by Apollo to have a speed of 0 m/s by Apollo at that moment, whereas the actual NPC speed was 4.56 m/s, as measured from the simulator. (2) We also observe that Apollo’s planner can be wrong even when the NPC trajectory is predicted correctly. Fig. 12 (b) shows this case. As seen, Apollo’s planner issues an overtaking action (shown in a blue fence) that crosses the NPC’s estimated trajectory. Therefore, the AV starts accelerating, leading to an accident.” ([Li et al., 2020, p. 9](zotero://select/library/items/I7ELCA32)) 

High Speed, Brake

>[Go to annotation](zotero://open-pdf/library/items/A9E8PTLG?page=9&annotation=FVVMISAF) “illustrates a cascade accident. As shown in Fig. 10, Apollo is following TV2. TV2 starts accelerating, and so does Apollo. At some point, TV2 rear-ends TV1, which is stationary. As a result, the speed of TV2 is suddenly reduced to zero, leaving Apollo little time to react. Apollo starts applying the brake when it is only 7.3 m from TV2, and the speed of Apollo is 41 km/h. Based on our profiling, Apollo would need at least 8.75 m to come to a complete stop, so a rear-end collision occurs. Similar problems have been revealed in Tesla Autopilot [27]. One way to mitigate them is to steer the AV to the adjacent lane (if available) to avoid the accident.” ([Li et al., 2020, p. 9](zotero://select/library/items/I7ELCA32)) 

Cascade
