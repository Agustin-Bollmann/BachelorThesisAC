---
title: "CARLA: Car Learning to Act — An Inside Out"
ARLA: Car Learning to Act — An Inside Out
authors: Sumbal Malik, Manzoor Ahmed Khan, Hesham El-Sayed
year: 2022
---

# CARLA: Car Learning to Act — An Inside Out
##### Sumbal Malik, Manzoor Ahmed Khan, Hesham El-Sayed (2022)
[Zotero-Link](zotero://select/items/@malikCARLACarLearning2022)

Tags: #HumanError #Energy #CARLA #Perception #Control #Simulation #SimulationEngine #TCP #Commands #Sensors #Pyhton #API #ClientServer #Architecture #Towns 

>[!ABSTRACT]-
>Training autonomous vehicles require rigorous and comprehensive testing to deal with a variety of situations that they expect to undergo on roads in real-time. The physical testing of autonomous driving on roads has always been hindered; by the infrastructure costs, high-performance systems, sensors, communication devices, and jeopardizing the safety of people in the real world. That is where the testing in the simulation helps in filling the gap and democratizes autonomous driving research. There are plenty of simulators to test autonomous driving solutions, and CARLA is one of them. CARLA is a powerful simulator that encompasses tools to develop, train and validate the systems in controlled scenarios. This paper presents a detailed overview of the CARLA, discussing its simulation engine, client-server architecture, urban environment, and a variety of sensors. The wide range of features and modules of each CARLA release has also been reviewed helping the research community to choose the suitable CARLA release meeting best their requirements. Moreover, the comparative analysis of CARLA with well-known open-source and commercial simulators is also presented. The analysis shows that CARLA and LGSVL are currently state-of-the-art open-source simulators for end-to-end testing of autonomous driving solutions. Finally, we discuss the various research applications and use case scenarios where the CARLA has been implemented and extended by the research community.


---

# Summary

- The paper discusses CARLA’s role as an open-source simulator designed for developing and validating autonomous driving systems. CARLA supports training, prototyping, and testing in urban environments and includes diverse scenarios, sensor setups, and weather conditions.
- The authors present CARLA’s **client-server architecture**, allowing multiple client connections to interact with the simulation environment, control agents, and modify environmental conditions through a Python API.
- The paper provides a **comparative analysis** of CARLA with other open-source and commercial simulators, highlighting its capabilities in simulating complex urban environments, dynamic objects like vehicles and pedestrians, and integrating weather and time-of-day conditions.
- The paper also explores **various research applications** of CARLA, including cooperative autonomous driving, deep reinforcement learning, and semantic segmentation, emphasizing its adaptability for different autonomous driving research domains.

# Relevancy

- **Details CARLA’s Capabilities**: The comprehensive explanation of CARLA’s architecture, sensor suite, and environmental control directly supports your use of CARLA for simulating and testing CAN traffic manipulation.
- **Highlights Comparative Strengths**: The comparative analysis with other simulators (e.g., LGSVL) offers insight into why CARLA is suitable for your testing needs in manipulating CAN traffic within realistic urban driving scenarios.
- **Explores Research Applications**: The examples of research applications using CARLA provide a foundation for structuring your experiments, especially in testing control strategies and environmental perception.

# Notable Sections and Pages

- **Section 2: The CARLA Simulator - An Overview (Pages 742-744)**: Offers detailed insights into the client-server architecture and sensor configuration, essential for understanding how to manipulate the environment for CAN testing.
- **Section 5: Applications (Pages 747-748)**: Discusses specific research domains and applications where CARLA has been used, relevant for understanding its potential use cases in autonomous driving scenarios.
- **Comparative Analysis (Section 4, Pages 745-746)**: Provides a comparative look at other simulators, useful for positioning CARLA as the primary testing platform in your thesis.

# Recommendations

This paper is an essential addition to your thesis literature as it offers detailed insights into CARLA’s features, applications, and suitability for autonomous vehicle testing. I recommend citing it for its in-depth explanation of the simulator's capabilities and the comparative analysis with other platforms.

---

# Annotations  
(11/4/2024, 1:33:31 PM)

>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=1&annotation=4KAN2H7X) “Transportation systems all around the world experience several challenges such as road safety, underuse roadway infrastructure, excessive fuel consumption, and increased CO2 emission. Concerning road safety, it is estimated that more or less 92% of the accidents are mainly caused by human recognition and decision errors [13]. Furthermore, these erroneous decisions lead to the driving styles encountering traffic congestion, frequent acceleration/deceleration, and CO2 emission.” ([Malik et al., 2022, p. 1](zotero://select/library/items/E8JQ2XY8)) 

Human Error, Energy

>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=2&annotation=4HARWKI9) “Car Learning to Act (CARLA) [5], is an open-source simulator for autonomous urban driving. It is developed from scratch to support training, prototyping, and validation of autonomous driving solution approaches including both perception and control. Therefore, CARLA attempts to meet the requirements of various use cases of advanced driver assistance systems, i.e., training the perception algorithms or learning driving policies. In addition to the open-source nature and protocols, the urban digital content in the CARLA is also free to use, i.e., urban layouts, vehicle models, buildings, pedestrians, and infrastructure, etc. Fig.1. Fig. 1. CARLA Weather Conditions The simulator supports the flexible setup, configurations of the sensor suite and provides signals that can be used to train the driving strategies. The CARLA allows customizing a wide range of environmental options such as change the weather (rainy, sunny), time of the day, and lightning to test various driving policies. Some of the environmental conditions are shown, in” ([Malik et al., 2022, p. 2](zotero://select/library/items/E8JQ2XY8)) 

CARLA, Perception, control

>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=2&annotation=BUHY5IS4) “CARLA simulation engine aims to provide flexibility and fidelity in the rendering and physics simulation serving as an open-source layer over the Unreal Engine 4 (UE4) [18]. It enables the community to upgrade it with new features, plugins, and extensions leveraging the OpenDRIVE standard [2] to define the roads and urban settings. The UE4 is free of charge for noncommercial use and provides high rendering quality, realistic vehicle physics, non-player character (NPC) logic, and an ecosystem of interoperable plugins.” ([Malik et al., 2022, p. 2](zotero://select/library/items/E8JQ2XY8)) 

SimulationEngine

![](JW8VNB96.png)  
>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=3&annotation=JW8VNB96)  
([Malik et al., 2022, p. 3](zotero://select/library/items/E8JQ2XY8)) 

CARLA

>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=3&annotation=4TDJQIYG) “CARLA, a scalable client-server architecture shown in Fig.2. communicates over transmission control protocol (TCP). This client-server architecture makes it possible to create multiple clients in the same or different nodes [15]. It simulates an open, dynamic world implementing an interface between the world and an agent which interacts with the world. The server is in charge of running the simulation, rendering the scenes, sensor rendering, computation of physics, and providing the information to the client, etc. Whereas the client-side comprised of some client modules aims to control the logic of agents appearing in the scenes. The client sends the commands and meta-commands to the server and receives the sensors’ messages in return. The commands are used to control the vehicle including steering, acceleration, and braking. However, the meta-commands are used to control the behavior of the server, modify the sensor suite, specify the environmental properties such as weather conditions, illumination, number of vehicles, and pedestrians. To implement; this client-server functionality, the client API is implemented in Python to establish the interaction between the agent and the server via Sockets.” ([Malik et al., 2022, p. 3](zotero://select/library/items/E8JQ2XY8)) 

TCP, commands, sensors, python, api, clientserver, architecture

![](6B4PGJMI.png)  
>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=4&annotation=6B4PGJMI)  
([Malik et al., 2022, p. 4](zotero://select/library/items/E8JQ2XY8)) 

CARLATowns

>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=4&annotation=63FLKDF9) “A sensor is an actor connected to a parent vehicle, follows the vehicles around, and gathers the information of the surrounding environment. It waits for some events to happen and then collects the data from the simulation based on the function defining how to manage the data. CARLA allows for flexible configuration of the agents’ sensor suite and provides realistic sensory data. It provides access to RGB cameras, Lidar point clouds, RADAR, inertial measurement unit (IMU), pseudo-sensors, global navigation satellite system (GNSS) measurements, lane invasion detector, and obstacle detector, where the number, type, and position of each sensor can be configured by the client. Furthermore, the semantic segmentation pseudo-sensor provides access to twelve semantic classes such as roads, lane-marking, traffic sign, sidewalk, fence, pole, building, vegetation, vehicle, and pedestrian, etc. Besides the sensor readings, CARLA also provides a wide range of measurements associated with an agent’s state such, as vehicle location, orientation, speed, acceleration, compliance with traffic rules. Some of the measurements related to the traffic rules are the percentage of the vehicle’s footprint that traveled on the wrong-way lanes, pavements, and the speed limit for a vehicle at a specific location. CARLA also provides the exact location, 2D and 3D bounding boxes of the dynamic objects in the environment which, play a crucial role in training and validating the driving policies.” ([Malik et al., 2022, p. 4](zotero://select/library/items/E8JQ2XY8)) 

Sensors

![](XGUB69HG.png)  
>[Go to annotation](zotero://open-pdf/library/items/2IPWL3CR?page=7&annotation=XGUB69HG)  
([Malik et al., 2022, p. 7](zotero://select/library/items/E8JQ2XY8)) 

Simulators