---
title: Towards a Simulation-based Framework for the Security Testing of Autonomous Vehicles
authors: Eduardo dos Santos, Dominik Schoop
year: 2018
---

# Towards a Simulation-based Framework for the Security Testing of Autonomous Vehicles
##### Eduardo dos Santos, Dominik Schoop (2018)
[Zotero-Link](zotero://select/items/@dossantosSimulationbasedFrameworkSecurity2018)

Tags: #AttackSurfaces #Vulnerabilities #Sensors #LiDAR #ADAS #SAELevels #Perception #Consequences #Attackers #ReverseEngineering #AttackersMotive #Camera #GPS #Countermeassures #RealAccident 


>[!ABSTRACT]-
>


---

# Summary

- The paper proposes a framework for security testing of autonomous vehicles (AVs) using a simulation-based approach. It focuses on **attacks on perception systems**, such as LiDAR and camera sensors, and how these attacks can be modeled and tested in simulation environments like CARLA.
- The framework uses **Communication Sequential Processes (CSP)** for modeling and testing sensor attacks systematically. It integrates simulation scripts that replicate real-world sensor attack scenarios, providing a safe and cost-effective testing method.
- The paper includes a **case study using CARLA**, demonstrating how attacks such as camera blinding and GPS spoofing can be simulated to assess the impact on AV control algorithms.

# Relevancy

- **Directly Aligns with Simulation Testing**: The use of CARLA to simulate and test sensor attacks fits well with your objective of manipulating CAN traffic and testing autonomous systems in a virtual environment.
- **Focuses on Sensor Attacks and Mitigation**: It explores various attack types (e.g., camera blinding, GPS spoofing) that affect AV decision-making, providing insights that could inform the experimental design for your CAN bus manipulation tests.
- **Provides a Formal Framework**: The use of CSP offers a structured approach that can be applied to your work with CARLA, helping you develop robust test scenarios for evaluating AV security.

# Notable Sections and Pages

- **Section 2.2: The Threat Model (Pages 3-4)**: Describes the threat assessment and risk analysis for AV systems, providing context for testing and evaluating vulnerabilities in CAN and sensor networks. This is valuable for understanding the scope of threats to be simulated in your experiments.
- **Section 6: Case Study: CARLA (Pages 8-9)**: Demonstrates how the CARLA simulator is used to model attacks like **camera blinding** and **sensor jamming**, directly applicable for your thesis when simulating and testing CAN traffic manipulation.
- **Section 6.1: Simulating Attacks in CARLA (Pages 9-10)**: Details the specific simulation setups for various attacks, including the configuration of CARLA’s scripts and sensor effects, which is essential for implementing and translating your findings from the simulated environment to real-world scenarios.

# Recommendations

This paper is an excellent source for your thesis as it provides both a **methodological framework** and a **practical case study** using CARLA. I recommend citing it for its structured approach to simulating AV sensor attacks and integrating formal testing methods like CSP. This will support the experimental design and validation aspects of your work.

---

# Annotations  
(10/28/2024, 8:51:41 PM)

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=1&annotation=6DF278JJ) “Despite being a promising new technology, the security of autonomous vehicles has attracted attention from the cybersecurity community. As an example, Petit et al. identify 12 sub-systems that are likely to be target to attacks, including: infrastructure signs, machine vision, GPS, Lidar and Radar [22].” ([Santos and Schoop, 2018, p. 1](zotero://select/library/items/3QF5JZUG)) 

Attack Surfaces, Vulnerabitlities

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=1&annotation=7Z8TDPJY) “Because of their over-reliance on sensors and computing, there is the fear that autonomous vehicles might be easily fooled [22]. This might lead to various consequences, one of which is the vehicle making the wrong decision based on incorrect data. This can have potential safety consequences for its occupants, the occupants of other vehicles and nearby pedestrians.” ([Santos and Schoop, 2018, p. 1](zotero://select/library/items/3QF5JZUG)) 

Vulnerabitlities

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=1&annotation=7PPI79SB) “Given that abnormal data (or, in our context, insecure data) is not easily found in the environment, and, as a result, is not usually incorporated into training datasets, there is the risk a vehicle’s perception systems will not be able to detect such discrepancies. An example is the situation illustrated in Figure 1. A stereo (3D) binocular camera uses two or more image sensors to create a 3D view of the environment (top image). If one of its sensors captures too much noise, as in the form of a red laser beam pointed at it [40], the resulting 3D view may equally be noisy or, even, incomprehensible (bottom image). This can have a severe impact on systems that depend on good quality image data to make decisions.” ([Santos and Schoop, 2018, p. 1](zotero://select/library/items/3QF5JZUG)) 

Sensors, LiDAR

![](YT8LU4JM.png)  
>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=2&annotation=YT8LU4JM)  
([Santos and Schoop, 2018, p. 2](zotero://select/library/items/3QF5JZUG)) 

Sensors

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=2&annotation=9RA55DAI) “Modern road vehicles incorporate a number of advanced driver assistant systems (ADAS) that make use of a variety of sensors to offer functions making driving safer and more convenient. Examples of such ADAS include adaptive cruise control, automatic emergency braking, lane departure warnings, and parking pilots. The latter function is also available when the driver is outside the vehicle and has a wireless control channel to the vehicle. Currently, these functions require the driver to be observant and to be able to take over control of the vehicle in an instant. The functions are only partly autonomous.” ([Santos and Schoop, 2018, p. 2](zotero://select/library/items/3QF5JZUG)) 

ADAS

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=2&annotation=6NUX48MV) “The Society of Automotive Engineers (SAE) defines five levels of autonomy in vehicles. To be considered fully autonomous (Level 5), cars must operate autonomously in any kind of environment and under any weather condition [6]. Currently, cars are in the middle of the level spectrum (Level 3, conditional automation), with only some autonomy available.” ([Santos and Schoop, 2018, p. 2](zotero://select/library/items/3QF5JZUG)) 

SAE Levels

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=2&annotation=ZWPTS37F) “An AV’s perception system is commonly composed by any of the following classes of sensors: 1. Lidar: up to 300 metres range, can provide 2D and 3D surface models, used for object recognition, e.g. pedestrian detection; 2. Long-range radar: 40 to 300 metres range, used for distance measurements of objects, e.g. adaptive cruise control; 3. Short-/Medium-range radar: used for e.g. blind spot detection; 4. Cameras: 2D or 3D, used for e.g. lane departure warning and for relative positioning in known environments 5. Ultrasonic sensor: used for detection of close obstacles, for e.g. parking pilot;” ([Santos and Schoop, 2018, p. 2](zotero://select/library/items/3QF5JZUG)) 

Perception Sensors

![](JH3PN9KD.png)  
>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=JH3PN9KD)  
([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Perception system

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=WLWS3D3J) “Satellite positioning system: e.g. GPS, provides global location information with accuracy up to several meters; differential GPS (dGPS) has precision in few centimetres but is still too expensive to be used in general; positioning data has to be augmented with camera, IMS, map data and/or dead reckoning from wheel rotation; 7. Inertial Movement Sensor (IMS): measures changes in directional velocity” ([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Perception Sensors

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=P5AXIGWY) “Each sensor class has its strengths and weaknesses, expressed in their range, the materials and shapes they can observe, how they cope with signal reflections and so on. Initially, the AV has to identify objects (perception). The data of the sensors might augment or contradict each other in this step. The data of all sensors has to be consolidated to detect and to identify individual objects and their properties such as stationary, speed, soft/hard, etc. (sensor fusion). In a second step, the identified objects have to be interpreted to understand the current scenario. This interpretation can make use of historic data and will lead to an action planning, which has to be carried out eventually by the vehicle controls (Figure 2). Note that this processing has to be done in real time as far as possible. This real-time constraint in addition to the computational restrictions of an automotive system makes the correct interpretation of sensor data even more challenging.” ([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Perception process

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=5LKAL8UJ) “The minimal asset categories to consider are human health, hardware, functionality and electronic data. An attack that interferes with the data input of sensors of the AV can cause the AV to behave inappropriately in the given physical environment and therefore can cause an accident, endangering human health. An attack might lead to the permanent malfunction (non-availability of functionality) or destruction of a sensor, possibly de-calibrating the sensor or destroying its physical components. Malicious input might lead to integrity loss of data stored in the car, e.g. a falsified dynamic map (Table 1). Other assets such as the privacy of personal data do not seem to be directly relevant here.” ([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Consequences

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=IQBJG8BU) “The attackers (threat agents) we consider are possibly active road users but do not have access to the internal systems of the AV they want to attack. The attack is purely carried out by providing data input to the external sensors of the AV. Following an attacker categorization inspired by [24], we assume that an attacker is not in control of global data input, i.e. the attacker does not control the navigation satellites. Therefore, any individual attack is limited to an individual sensor or a limited geographic area where a small number of vehicles is affected. However, we can assume that attackers are colluding and therefore can attack several sensors at the same time as well as carry out a sequence of attacks in time and space. These attacks are active and dynamic in the sense that the attacker can adapt its attack in real time dependent on the behaviour of the AV. The attacker might be malicious, i.e. not caring about resource use or consequences, or rational. As a rational attacker they would target their goal with the minimal effort possible.” ([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Attacker

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=NL6LUAR6) “The sensors of an AV will have to deal with erroneous data of many kind. A successful attack will, therefore, need to use specialized attack tools with the specific knowledge how to use them. Although design information of automotive systems are usually proprietary, attackers can carry out reverse engineering with some effort and therefore obtain detailed knowledge about the systems to attack.” ([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Reverse Engineering

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=3&annotation=UAQCLBP9) “An attacker might attack an AV just for fun, to stop the ve hicle and rob the passengers, to car-jack, with the intention to endanger specific road users, or for terrorist attacks.” ([Santos and Schoop, 2018, p. 3](zotero://select/library/items/3QF5JZUG)) 

Attackers Motive

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=4&annotation=FV3E8F66) “Lidar. Relay attacks to Lidar scanners can cause objects to be detected at the wrong position: far away objects are detected as being closer to the scanner (car) and vice-versa [23]. On the other hand, spoofing attacks can introduce non-existing objects to the scanner and tracking[23]. Besides spoofing and relay attacks, Lidar scanners are also subject to jamming, relay, and denial-of-service (saturating) attacks [32]. A common issue with Lidar attacks is the need for synchronicity. To be successful, an attacker needs to inject fake light pulses at a very short time interval[23, 32] . However, as this technology becomes cheaper and more accessible, so does its use by attackers.” ([Santos and Schoop, 2018, p. 4](zotero://select/library/items/3QF5JZUG)) 

LiDAR, Sensors

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=4&annotation=U6KDKMSI) “Camera. Camera blinding can confuse the auto controls [23]. Moreover, evidence suggests that pointing a laser beam to a camera may permanently damage its CMOS/CCD sensors [40]. A common drawback of camera attacks is aim[23]. Because of the distance and the size of the camera lens aperture, it is difficult to aim the laser beam precisely from the distance [23]. However, a practical assessment with a Tesla Model S unit revealed permanent damage to the sensor can be caused while the car is parked. Custom-built Arduino devices mounted on the front or rear car may be used as a tool to track and automatically direct a laser beam towards a camera while on the move[23] .” ([Santos and Schoop, 2018, p. 4](zotero://select/library/items/3QF5JZUG)) 

Camera

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=4&annotation=ITFZTQCT) “GPS. Spoofing attacks to GPS systems have been known since 2002 [38]. On another study, Yan et al. [40] measure the impact of sensor attacks against a Tesla Model S unit equipped with Autopilot and self-parking features. Their attack surface was broad, considering a wide set of sensors, comprising millimetric wave, radars, ultrasonic sensors, and cameras. All attacks were able to confuse the vehicle while its autonomous features were being executed. Outside the automotive domain, there have been advances on sensor security. Bezemskij et al. [2] develops a method to distinguish between normal and changed inputs to sensors. Moreover, Pustogarov et al. [26] use program analysis to synthesize sensor spoofing attacks, with a view to security testing.” ([Santos and Schoop, 2018, p. 4](zotero://select/library/items/3QF5JZUG)) 

GPS

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=4&annotation=GVQHFWIP) “Countermeasures at both software- and hardware-levels have been proposed to mitigate against sensor attacks. For GPS, Warner and Johnston [38] suggest the monitoring of GPS signal strength as well as timing analysis as a way to mitigate against GPS spoofing attacks. Mitigation strategies against Lidar attacks include random probing or shortening pulse periods [23]. Blinding attacks against cameras, in turn, can be mitigated via near-infrared light filters and the use of photochromic lenses [23]. One study observed permanent damage to the camera after a blinding attack even while the vehicle was turned off [40].” ([Santos and Schoop, 2018, p. 4](zotero://select/library/items/3QF5JZUG)) 

Camera Defense

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=4&annotation=2MMCT4CT) “Implementation of software countermeasures may be easier in comparison to hardware countermeasures. However, the implementation of sensor processing software can vary across different hardware suppliers. Sensors manufactured by different suppliers need tp interoperate with each other. Plus, even though countermeasures have been proposed, they may not be definitive. Depending on environmental conditions, certain countermeasures may be more adequate than others. Furthermore, one should not underestimate the odds that the countermeasures themselves introduce new vulnerabilities.” ([Santos and Schoop, 2018, p. 4](zotero://select/library/items/3QF5JZUG)) 

Countermeassures

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=8&annotation=YXADNUZ7) “CARLA (CAR Learning to Act) is an open-source simulator project for autonomous driving research [9]. The project started in late 2017, and has had an active repository since then [11]. CARLA can be used as tool for data collection and training of learning-based algorithms. CARLA inherits the physics dynamics and environment models from Unreal Engine version 4.17 [1]. It can run as a single instance or as a client-server architecture. At the time of writing, three types of sensors are currently supported by CARLA1: RGB cameras and pseudo-sensors 1Version 0.7.1 (February 2018). that provide ground-truth depth, and semantic segmentation. Number and position of sensors can be specified by the client. There is support for 2D and 3D camera modes.” ([Santos and Schoop, 2018, p. 8](zotero://select/library/items/3QF5JZUG)) 

Case Study CARLA

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=9&annotation=E76YPM2C) “At present, the following effects have been modelled: black screen (Figure 7(a)), intense white LED (Figure 7(b)), and broken lens (Figure 7(c)). The black screen effect is useful to represent a situation in which the assigned camera has gone completely dark. This can be the consequence of either a remote attack shutting off the camera, or simple camera malfunction. Cameras are an easy target by vandals as they are accessible from the outside to the vehicle (i.e. while the vehicle is parked). A white LED effect represents the situation in which a camera is subject to intense lighting, as to mess with the camera’s auto-exposure controls [23]. Finally, a broken glass effect simulates the situation in which a camera lens has been broken, followed a physical attack to it. Admittedly, this effect is not realistic enough, as we have skipped modelling light distortion caused by the broken glass. Attacks, such as the white LED and red laser beam above, can be directed towards any one of the simulated cameras in CARLA. In an stereo-vision setting, for instance, if any of the lenses is attacked, the resulting three-dimensional image can be distorted. There is a need to understand how perception and control system algorithms react to such disturbing events. Making cameras redundant has been proposed as a mitigation technique to physical attacks. However, the close proximity between main and redundant cameras makes it easy for the second to be targeted as well. Cameras can be the target of vandals, while the vehicle is parked, therefore we deem the black screen and broken lens effect feasible.” ([Santos and Schoop, 2018, p. 9](zotero://select/library/items/3QF5JZUG)) 

Simulating Attacks on Camera

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=9&annotation=DLPV62JL) “Although attacks to sensors might seem unlikely at the moment, they may become popular as soon as autonomous driving starts to grow. The cost of purchasing some attack materials, e.g. other Lidar scanners, make it impractical for the average attacker. However, this can change. As sensors become cheaper and more widely available, so does tools that exploit vulnerabilities on them.” ([Santos and Schoop, 2018, p. 9](zotero://select/library/items/3QF5JZUG)) 

Attacker Cost, ressources

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=9&annotation=P8DUDWB7) “The use of Tesla Autopilot has already been involved in two deaths. In one of the accidents’ official report [19], it was shown that Autopilot failed to detect the approaching of a heavyweight white trailer while its sensors were exposed to direct bright sunlight . There is a strong parallel here between this incident and the white LED camera blinding attack, idealised and tested by other researchers — and replicated by us via simulation.” ([Santos and Schoop, 2018, p. 9](zotero://select/library/items/3QF5JZUG)) 

Attack on Camera, real accident

>[Go to annotation](zotero://open-pdf/library/items/QM8A9QKX?page=10&annotation=Y87B2SAZ) “The growing link between safety and security is present here[12]. Our options for modelling simulated sensor attacks were constrained by the options offered by current tools(i.e. CARLA had not been implemented support to Lidar scanners).” ([Santos and Schoop, 2018, p. 10](zotero://select/library/items/3QF5JZUG)) 

Safety and Security

