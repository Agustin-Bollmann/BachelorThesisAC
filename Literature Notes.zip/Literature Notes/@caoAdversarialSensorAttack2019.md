---
title: Adversarial Sensor Attack on LiDAR-based Perception in Autonomous Driving
authors: Yulong Cao, Chaowei Xiao, Benjamin Cyr, Yimeng Zhou, Won Park, Sara Rampazzi, Qi Alfred Chen, Kevin Fu, Z. Morley Mao
year: 2019
---

# Adversarial Sensor Attack on LiDAR-based Perception in Autonomous Driving
##### Yulong Cao, Chaowei Xiao, Benjamin Cyr, Yimeng Zhou, Won Park, Sara Rampazzi, Qi Alfred Chen, Kevin Fu, Z. Morley Mao (2019)
[Zotero-Link](zotero://select/items/@caoAdversarialSensorAttack2019)

Tags: #LiDAR #Spoofing #Vulnerabilities #BrakeAttack #FreezingAttack #Modules #Sensor #Perception #Prediction #Planning #LiDARSignal #MachineLearningModel #Defense #Randomization #RealAttacks 

>[!ABSTRACT]-
>In Autonomous Vehicles (AVs), one fundamental pillar is perception, which leverages sensors like cameras and LiDARs (Light Detection and Ranging) to understand the driving environment. Due to its direct impact on road safety, multiple prior efforts have been made to study its the security of perception systems. In contrast to prior work that concentrates on camera-based perception, in this work we perform the first security study of LiDAR-based perception in AV settings, which is highly important but unexplored. We consider LiDAR spoofing attacks as the threat model and set the attack goal as spoofing obstacles close to the front of a victim AV. We find that blindly applying LiDAR spoofing is insufficient to achieve this goal due to the machine learning-based object detection process. Thus, we then explore the possibility of strategically controlling the spoofed attack to fool the machine learning model. We formulate this task as an optimization problem and design modeling methods for the input perturbation function and the objective function. We also identify the inherent limitations of directly solving the problem using optimization and design an algorithm that combines optimization and global sampling, which improves the attack success rates to around 75%. As a case study to understand the attack impact at the AV driving decision level, we construct and evaluate two attack scenarios that may damage road safety and mobility. We also discuss defense directions at the AV system, sensor, and machine learning model levels.


---

# Summary

- The paper presents a study on **LiDAR-based sensor spoofing attacks** in autonomous vehicles (AVs), specifically targeting the Baidu Apollo system. It focuses on strategically manipulating the LiDAR input to create fake obstacles and influence the AV’s decision-making process.
- The research demonstrates that **blindly applying existing LiDAR spoofing techniques** is insufficient to produce significant security consequences. Instead, the authors propose a method combining **optimization algorithms and global sampling** to improve the success rate of such attacks.
- The paper includes a **case study** simulating two scenarios: an emergency brake attack and an AV freezing attack. Both attacks were conducted using simulation data from Baidu Apollo, demonstrating the effectiveness of the proposed methodology.

# Relevancy

- **LiDAR and Sensor Attack Techniques**: It provides an in-depth analysis of sensor spoofing attacks, relevant for understanding how to manipulate sensor input in simulations like CARLA.
- **Integration with Machine Learning**: The study explores how to craft adversarial examples that fool perception models, which aligns well with your aim to manipulate CAN traffic and simulate these effects in AV environments.
- **Simulation Approach**: The use of Baidu Apollo’s simulation environment for testing and demonstrating attacks offers insights that could be applied when using CARLA and Autoware in your experiments.

# Notable Sections and Pages

- **Section 2.2: LiDAR Sensor and Spoofing Attacks (Pages 2-3)**: Explains the mechanics of LiDAR spoofing, detailing how attackers can manipulate LiDAR data. This is critical for the technical background of sensor-based attacks.
- **Section 5: Attack Methodology (Pages 6-8)**: Describes the optimized approach using adversarial machine learning and global sampling. This section is useful for designing your experiments when manipulating CAN and sensor data.
- **Section 9: Case Study: Driving Decision Impact (Pages 12-13)**: Demonstrates how the spoofed data affects AV driving decisions, providing a practical application that could inform your testing setup in CARLA.

# Recommendations

This paper is an excellent addition to your thesis as it offers a structured approach to simulating and testing sensor attacks. I recommend citing it for its in-depth methodology on spoofing LiDAR systems and integrating these techniques into machine learning-based perception models. It is particularly valuable for understanding the translation of simulation results into real-world scenarios.

---

# Annotations  
(10/29/2024, 2:21:52 PM)

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=1&annotation=ZWDE53YG) “Despite the research efforts in camera-based perception, there is no thorough exploration into the security of LiDAR-based perception in AV settings. LiDARs, which measure distances to surrounding obstacles using infrared lasers, can provide 360-degree viewing angles and generate 3-dimensional representations of the road environment instead of just 2-dimensional images for cameras. Thus, they are generally considered as more important sensors than cameras for AV driving safety [3, 13] and are adopted by nearly all AV makers today [4, 5, 7, 11]. A few recent works demonstrated the feasibility of injecting spoofed points into the sensor input from the LiDAR [42, 44]. Since such input also needs to be processed by an object detection step in the AV perception pipeline, it is largely unclear whether such spoofing can directly lead to semantically-impactful security consequences, e.g., adding spoofed road obstacles, in the LiDAR-based perception in AV systems.” ([Cao et al., 2019, p. 1](zotero://select/library/items/PXL5ZRNF)) 

LiDAR, Spoofing, Vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=2&annotation=EF4Q5J67) “As a case study for understanding the impact of the discovered attack input at the AV driving decision level, we construct two attack scenarios: (1) emergency brake attack, which may force a moving AV to suddenly brake and thus injure the passengers or cause rear-end collisions, and (2) AV freezing attack, which may cause an AV waiting for the red light to be permanently “frozen” in the intersection and block traffic. Using real-world AV driving data traces released by the Baidu Apollo team, both attacks successfully trigger the attacker-desired driving decisions in Apollo’s simulator.” ([Cao et al., 2019, p. 2](zotero://select/library/items/PXL5ZRNF)) 

Brake Attack, Freezing Attack

![](SZ3WWBJK.png)  
>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=3&annotation=SZ3WWBJK)  
([Cao et al., 2019, p. 3](zotero://select/library/items/PXL5ZRNF)) 

LiDAR processing pipeline Apollo

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=3&annotation=7HEF9ZM7) “With the information of perceived obstacles such as their positions, shapes, and obstacle types, the Apollo system then uses such information to make driving decisions. The perception output is further processed by the prediction module which predicts the future trajectories of perceived obstacles, and then the planning module which plans the future driving routes and makes decisions such as stopping, lane changing, yielding, etc.” ([Cao et al., 2019, p. 3](zotero://select/library/items/PXL5ZRNF)) 

Modules

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=3&annotation=HTICN99B) “LiDAR sensor. A LiDAR sensor functions by firing laser pulses and capturing their reflections using photodiodes. Because the speed of light is constant, the time it takes for the echo pulses to reach the receiving photodiode provides an accurate measurement of the distance between a LiDAR and a potential obstacle. By firing the laser pulses at many vertical and horizontal angles, a LiDAR generates a point cloud used by the AV systems to detect objects.” ([Cao et al., 2019, p. 3](zotero://select/library/items/PXL5ZRNF)) 

LiDAR, Sensor

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=3&annotation=IQFTIN6E) “LiDAR spoofing attack. Sensor spoofing attacks use the same physical channels as the targeted sensor to manipulate the sensor readings. This strategy makes it very difficult for the sensor system to recognize such attack, since the attack doesn’t require any physical contact or tampering with the sensor, and it doesn’t interfere with the processing and transmission of the digital sensor measurement. These types of attacks could trick the victim sensor to provide seemingly legitimate, but actually erroneous, data. LiDAR has been shown to be vulnerable to laser spoofing attacks in prior work. Petit et al. demonstrated that a LiDAR spoofing attack can be performed by replaying the LiDAR laser pulses from a different position to create fake points further than the location of the spoofer [42]. Shin et al. showed that it is possible to generate a fake point cloud at different distances, even closer than the spoofer location [44]. In this paper, we build upon these prior works to study the effect of this attack vector on the security of AV perception.” ([Cao et al., 2019, p. 3](zotero://select/library/items/PXL5ZRNF)) 

Spoofing, Laser

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=4&annotation=MW2LV3IZ) “The prior work of Shin et al. is able to spoof a maximum of 10 fake dots in a single horizontal line. With our setup improvements (a faster firing rate and a lens to focus the beam), fake points can be generated at all of the 16 vertical viewing angles and an 8 ◦ horizontal angle at greater than 10 meters away. In total, around 100 dots can be spoofed by covering these horizontal and vertical angles (illustrated in Fig. 14 in Appendix). These spoofed dots can also be shaped by modifying the custom pulse waveform used to fire the attack laser. Notice that even though around 100 dots can be spoofed, they are not all spoofed stably. The attacker is able to spoof points at different angles because the spoofed laser pulses hit a certain area on the victim LiDAR due to the optical lens focusing. The closer to the center of the area, the stronger and stabler laser pulses are received by the victim LiDAR. We find that among 60 points at the center 8-10 vertical lines can be stably spoofed with high intensity.” ([Cao et al., 2019, p. 4](zotero://select/library/items/PXL5ZRNF)) 

Results

![](S7VD4RCG.png)  
>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=5&annotation=S7VD4RCG)  
([Cao et al., 2019, p. 5](zotero://select/library/items/PXL5ZRNF)) 

Driving decision, Spoofing

![](HUR4PXNL.png)  
>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=5&annotation=HUR4PXNL)  
([Cao et al., 2019, p. 5](zotero://select/library/items/PXL5ZRNF)) 

Spoofing

![](FTQY2MBV.png)  
>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=5&annotation=FTQY2MBV)  
([Cao et al., 2019, p. 5](zotero://select/library/items/PXL5ZRNF)) 

LIDAR Signal

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=5&annotation=BZVA2PEK) “Figure 4: The consistent firing sequence of the LiDAR allows an attacker to choose the angles and distances from which spoofed points appear. For example, applying the attacker signal, fake dots will appear at 1◦, 3◦, -3◦, and -1◦ angles (0◦ is the center of the LiDAR)” ([Cao et al., 2019, p. 5](zotero://select/library/items/PXL5ZRNF)) 

LIDAR Signal

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=6&annotation=UTB4CSNJ) “As discussed in §4, without considering the machine learning model used in LiDAR-based perception, blindly applying existing LiDAR spoofing attacks can hardly achieve the attack goal of generating front-near obstacles. Since it is known that machine learning output can be maliciously altered by carefully-crafted perturbations to the input [18, 20, 29, 41, 57], we are then motivated to explore the possibility of strategically controlling the spoofed points to fool the machine learning model in LiDAR-based perception.” ([Cao et al., 2019, p. 6](zotero://select/library/items/PXL5ZRNF)) 

Need to consider Machine learning model

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=11&annotation=36SSRQS3) “(1) Emergency brake attack. In this attack, we generate adversarial 3D point cloud that spoofs a front-near obstacle to a moving victim AV. We find that the AV makes a stop decision upon this attack. As illustrated in Fig. 12, the stop decision triggered by a spoofed front-near obstacle causes the victim AV to decrease its speed from 43 km/h to 0 km/h within 1 second. This stop decision will lead to a hard brake [1], which may hurt the passengers or result in rear-end collisions. Noticed that, Apollo does implement driving decisions for overtaking. However, for overtaking, a minimum distance is required based on the relative speed of the obstacle. Therefore, with our near spoofed obstacle, the victim AV makes stop decisions instead of overtaking decisions.” ([Cao et al., 2019, p. 11](zotero://select/library/items/PXL5ZRNF)) 

BrakeAttack

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=11&annotation=ETPSURUS) “(2) AV freezing attack. In this attack, we generate an adversarial 3D point cloud that spoofs an obstacle in front of an AV victim when it is waiting at a red traffic light. We simulate this scenario with the data trace at an intersection with a traffic light. As shown in Fig. 13, since the victim AV is static, the attacker can constantly attack and” ([Cao et al., 2019, p. 11](zotero://select/library/items/PXL5ZRNF)) 

FreezingAttack

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=12&annotation=ILPHG2MV) “prevent it from moving even after the traffic signal turns green, which may be exploited to cause traffic jams. Noticed that, Apollo does implement driving decisions for deviating static obstacles. However, for deviation or side passing, it requires a minimum distance (15 meters by default). Therefore, with our near spoofed obstacle, the victim AV makes stop decisions instead of side passing decisions.” ([Cao et al., 2019, p. 12](zotero://select/library/items/PXL5ZRNF)) 

Freezing Attack

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=12&annotation=W4CDF4KS) “One major limitation is that our current results cannot directly demonstrate attack performance and practicality in the real world. For example, performing our attack on a real AV on the road requires dynamically aiming an attack device at the LiDAR on a victim car with high precision, which is difficult to prove the feasibility without road tests in the physical world. In this work, our goal is to provide new understandings of this research problem. Future research directions include conducting real world testing. To demonstrate the attack in the real world, we plan to first conduct the sensor attack with LiDAR on top of a real vehicle in outdoor settings. In this setting, the sensor attack could be enhanced by: 1) enlarging the laser spoofing area to solve the aiming problem; 2) adjusting the delay time so that the attacker could spoof points at different angles without moving the attack devices. Then we could apply our proposed methodology to conduct drive-by experiments in different attack scenarios mentioned in §9.” ([Cao et al., 2019, p. 12](zotero://select/library/items/PXL5ZRNF)) 

LimitationsSensorAttack

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=13&annotation=LYALPFJB) “Sensor fusion, which intelligently combines data from several sensors to detect anomalies and improve performance, could be adopted against LiDAR spoofing attacks. AV systems are often equipped with sensors beyond LiDAR. Cameras, radars, and ultrasonic sensors provide additional information and redundancy to detect and handle an attack on LiDAR. Different sensor fusion algorithms have been proposed focusing on the security and safety aspects [56] [33]. However, the sensor fusion defense requires the majority of sensors to be functioning correctly. While not a perfect defense, sensor fusion approaches can significantly increase the effort of an attacker.” ([Cao et al., 2019, p. 13](zotero://select/library/items/PXL5ZRNF)) 

Defense, Detection

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=13&annotation=U6R4227T) “Another defense is adding randomness to how the LiDAR fires laser pulses. The attacker cannot know when to and what laser pulses to fire if the LiDAR fires laser pulses with an unpredictable pattern. A solution could be firing a random grouping of laser pulses each cycle. An attacker would not know which reflections the LiDAR would be expecting. Another alternative would be randomizing the laser pulses waveform. With sensitive equipment, it would be possible to only accept reflection waveforms that match randomized patterns uniquely produced by the LiDAR laser. Another solution, proposed by Shoukry et al. [46], consists of randomly turning off the transmitter to verify with the receiver if there are any unexpected incoming signals. Adding randomness makes it difficult for an attacker to influence the measurements, but this approach also adds significant complexity to the overall system and trades off with performance.” ([Cao et al., 2019, p. 13](zotero://select/library/items/PXL5ZRNF)) 

Randomization

>[Go to annotation](zotero://open-pdf/library/items/V48FZ77V?page=13&annotation=F9H4RVYF) “The sensors commonly used in traditional vehicles have been shown to be vulnerable to attacks. Rouf et al. showed that tire pressure sensors are vulnerable to wireless jamming and spoofing attacks [43]. Shoukry et al. attacked the anti-lock braking system of a vehicle by spoofing the magnetic wheel speed sensor [45]. As AVs become popular, so have attacks against their perception sensors. Yan et al. used spoofing and jamming attacks to attack the ultrasonic sensors, radar, and camera on a Tesla Model S [55]. There have also been two works exploring the vulnerability of LiDAR to spoofing and jamming attacks [42, 44]. In this work, we build on these prior work to show that LiDAR spoofing attacks can be used to attack the machine learning models used for LiDAR-based AV perception and affect the driving decision.” ([Cao et al., 2019, p. 13](zotero://select/library/items/PXL5ZRNF)) 

Real Attacks
