---
title: "ANTI-CARLA: An Adversarial Testing Framework for Autonomous Vehicles in CARLA"
authors: Shreyas Ramakrishna, Baiting Luo, Christopher B. Kuhn, Gabor Karsai, Abhishek Dubey
year: 2022
---

# ANTI-CARLA: An Adversarial Testing Framework for Autonomous Vehicles in CARLA
##### Shreyas Ramakrishna, Baiting Luo, Christopher B. Kuhn, Gabor Karsai, Abhishek Dubey (2022)
[Zotero-Link](zotero://select/items/@ramakrishnaCARLAAdversarialTesting2022)

Tags: #RealAccident #ISO #ISO26262 #SDL #MSDL #SceML #ANTICARLA #LBC 

>[!ABSTRACT]-
>Despite recent advances in autonomous driving systems, accidents such as the fatal Uber crash in 2018 show these systems are still susceptible to edge cases. Such systems must be thoroughly tested and validated before being deployed in the real world to avoid such events. Testing in open-world scenarios can be difficult, time-consuming, and expensive. These challenges can be addressed by using driving simulators such as CARLA instead. A key part of such tests is adversarial testing, in which the goal is to find scenarios that lead to failures of the given system. While several independent efforts in testing have been made, a well-established testing framework that enables adversarial testing has yet to be made available for CARLA. We therefore propose ANTI-CARLA, an automated testing framework in CARLA for simulating adversarial weather conditions (e.g., heavy rain) and sensor faults (e.g., camera occlusion) that fail the system. The operating conditions in which a given system should be tested are specified in a scenario description language. The framework offers an efficient search mechanism that searches for adversarial operating conditions that will fail the tested system. In this way, ANTI-CARLA extends the CARLA simulator with the capability of performing adversarial testing on any given driving pipeline. We use ANTICARLA to test the driving pipeline trained with Learning By Cheating (LBC) approach. The simulation results demonstrate that ANTI-CARLA can effectively and automatically find a range of failure cases despite LBC reaching an accuracy of 100% in the CARLA benchmark.


---

# Summary

- The paper highlights **CARLA** as an open-source simulator developed to support the training, prototyping, and validation of autonomous driving systems, especially in urban environments. It is built on Unreal Engine 4 (UE4) and supports realistic vehicle physics and high-fidelity 3D rendering, making it suitable for developing advanced driver assistance systems (ADAS).
- It discusses the **client-server architecture** of CARLA, which uses Transmission Control Protocol (TCP) to connect the simulation server and client modules. This setup allows flexible configurations, where users can control agent behaviors (e.g., vehicle movements) and environment settings (e.g., weather conditions) via a Python API.
- The paper provides a **comparative analysis** of CARLA with other open-source and commercial simulators, demonstrating that CARLA and LGSVL are state-of-the-art for end-to-end testing of autonomous driving solutions.
- Additionally, the document covers CARLA’s capabilities, such as **sensor configuration** (e.g., RGB cameras, LiDAR, RADAR) and **scenario generation** tools (e.g., Scenario Runner) for testing diverse driving policies and ADAS features.

# Relevancy

- **Provides a Comprehensive Overview of CARLA**: The detailed explanation of CARLA's architecture and features supports your aim to use CARLA for CAN traffic manipulation experiments.
- **Focuses on Flexibility and Realism**: The paper’s emphasis on flexible environment configuration and realistic sensor setups aligns with your requirement for a simulation environment that can replicate various attack and test scenarios.
- **Highlights Scenario-Based Testing**: The integration of Scenario Runner and the support for scripting complex urban scenarios are crucial for designing and executing the controlled tests you plan to conduct in your thesis.

# Notable Sections and Pages

- **Section 2.2: Environment (Pages 744-745)**: Discusses CARLA's environment configuration, detailing the range of available assets, sensor setups, and simulation customization options, which are key for structuring your tests.
- **Section 2.4: Salient Features (Pages 746-748)**: Highlights CARLA’s advanced tools, including the Traffic Manager and Scenario Runner, directly applicable for creating adversarial scenarios and testing CAN manipulation.
- **Table 2: CARLA Versions and Features (Pages 748-749)**: Reviews various CARLA releases, offering insights into the most suitable versions for implementing specific testing methodologies.

# Recommendations

This paper is a valuable addition to your thesis literature as it provides comprehensive insights into CARLA’s capabilities, making it an ideal reference for simulation-based testing and CAN traffic manipulation experiments. I recommend citing it for its detailed explanation of CARLA’s simulation architecture and tools for autonomous driving development.

---

# Annotations  
(11/4/2024, 2:45:53 PM)

>[Go to annotation](zotero://open-pdf/library/items/2968YH2Y?page=2620&annotation=LWLCAVS8) “Despite recent advances in autonomous driving systems, accidents such as the fatal Uber crash in 2018 show these systems are still susceptible to edge cases.” ([Ramakrishna et al., 2022, p. 2620](zotero://select/library/items/URDQUVNK)) 

RealAccident

>[Go to annotation](zotero://open-pdf/library/items/2968YH2Y?page=2620&annotation=GARKUBXM) “Advancements in Machine Learning (ML) have led to considerable progress in the levels of autonomy achieved by Autonomous Vehicles (AVs) [1]. However, recent accidents such as Tesla’s autopilot crashes [2] and the fatal Uber selfdriving car accident [3] demonstrate that current AV systems still can fail.” ([Ramakrishna et al., 2022, p. 2620](zotero://select/library/items/URDQUVNK)) 

RealAccident

>[Go to annotation](zotero://open-pdf/library/items/2968YH2Y?page=2620&annotation=G37AVSGJ) “Traditionally, testing is restricted to a set of handmade scenarios with the goal of satisfying safety standards such as ISO26262 [14]. However, manually creating test cases is tedious and requires significant human labor.” ([Ramakrishna et al., 2022, p. 2620](zotero://select/library/items/URDQUVNK)) 

ISO26262

>[Go to annotation](zotero://open-pdf/library/items/2968YH2Y?page=2621&annotation=LGR9DKWJ) “For testing software, test case generation has been a relevant research field for decades [22]. The field of AV testing has only recently started gathering interest. Domainspecific SDLs have been increasingly used for specifying the testing conditions [15], [23], [24]. For example, Scenic [15] is a popular language integrated with the CARLA simulator for setting up different scenarios. MSDL [16] is a language predominantly used in the industry to specify scenarios. Over the last years, languages such as SceML [24] have been developed to enhance the capabilities during testing.” ([Ramakrishna et al., 2022, p. 2621](zotero://select/library/items/URDQUVNK)) 

SDL, MSDL, SceML

>[Go to annotation](zotero://open-pdf/library/items/2968YH2Y?page=2626&annotation=98JYUD7G) “In this paper, we introduced the ANTI-CARLA framework for the CARLA simulator that allows to automatically generate test cases that fail an arbitrary AV system. Testing frameworks available in the literature are either tailor-made for a specific use case or built on proprietary simulators. In contrast, ANTI-CARLA is an open-source extension to an open-source simulator. The framework integrates a Scenario Description Language for modeling test scenarios in terms of the system’s operating conditions, sensor, and actuator faults. A test specification file is used to specify and select the test conditions, infraction metrics, and samplers required for generating the test cases. The SDL is driven by an adversarial sampler that searches across the specified operating conditions space. We used this framework to test the popular Learning By Cheating controller and to compare different samplers. We also used ANTI-CARLA to compare the performance of LBC to the Transfuser approach, allowing us to identify the weaknesses of each controller.” ([Ramakrishna et al., 2022, p. 2626](zotero://select/library/items/URDQUVNK)) 

ANTICARLA, LBC, SDL