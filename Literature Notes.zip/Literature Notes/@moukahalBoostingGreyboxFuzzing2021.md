---
title: Boosting Grey-box Fuzzing for Connected Autonomous Vehicle Systems
authors: Lama J. Moukahal, Mohammad Zulkernine, Martin Soukup
year: 2021
---

# Boosting Grey-box Fuzzing for Connected Autonomous Vehicle Systems
##### Lama J. Moukahal, Mohammad Zulkernine, Martin Soukup (2021)
[Zotero-Link](zotero://select/items/@moukahalBoostingGreyboxFuzzing2021)

Tags: #GreyBox #Fuzzing #VulFuzz #OpenPilot #Concolic 

>[!ABSTRACT]-
>Assuring the cybersecurity of Connected Autonomous Vehicles (CAVs) entails protecting the data, devices, network connectivity, and, most importantly, autonomous vehicles’ software. Software security testing aims to minimize the attack surface of CAVs by identifying security vulnerabilities at an early stage. One of the most robust and efficient security testing methods is fuzzing. Though fuzz testing can validate the system with various scenarios, its blindness prevents it from exploring the deep paths of the system. Hence, the automotive industry needs a reliable security testing tool that dynamically explores the system and assures a comprehensive evaluation. This paper presents a hybrid fuzz testing framework (VulFuzz++) that unites the efficiency of fuzzing and the precision of concolic execution to provide the automotive industry a reliable security testing tool. VulFuzz++ offloads most of the exploration process to the vulnerability-oriented fuzzer (VulFuzz) explicitly designed for automotive systems. When the fuzzer halts failing to explore different paths, VulFuzz++ examines the untraversed branches and prioritizes them based on their potential to expose vulnerabilities. It utilizes a tailored, targeted concolic engine that limits the symbolic exploration to only specific functions. When the concolic engine discovers new system inputs, testing is handed over again to the fuzzer to perform a quick and efficient evaluation of the newly explored region. We implemented and experimented with the VulFuzz++ framework on a driving assistance system. VulFuzz++ boosted the vulnerability exposure process of grey-box fuzzing, increasing the obtained crashes by 50%. It dramatically outperforms traditional concolic engines in assisting fuzzers, exposing 50 times more unique crashes. VulFuzz++ extends the testing time moderately but assures a comprehensive examination covering 96.7% of the automotive system branches.


---

# Summary

- The paper presents **VulFuzz++**, a hybrid fuzz testing framework combining grey-box fuzzing with targeted symbolic (concolic) execution to improve testing coverage for Connected Autonomous Vehicles (CAVs). The framework focuses on evaluating and expanding the vulnerability exposure process in automotive systems.
- VulFuzz++ prioritizes the exploration of specific components based on vulnerability metrics, selectively applying symbolic execution to those with the highest potential for exposure. The authors demonstrate that VulFuzz++ outperforms traditional fuzzers by discovering more vulnerabilities and increasing code coverage.
- The framework is validated on an autonomous driving assistance system, showing a **50% increase in discovered crashes** and achieving **96.7% branch coverage**.

# Relevancy

- **Focuses on Automotive Fuzz Testing**: The discussion of grey-box and hybrid fuzz testing directly aligns with your goal of testing CAN traffic vulnerabilities using simulation tools like CARLA.
- **Highlights Symbolic Execution Techniques**: VulFuzz++’s concolic testing approach offers insights into how symbolic and fuzz testing methods can be combined to test CAN traffic and other AV components in your simulation.
- **Evaluates Specific Vulnerabilities**: The focus on identifying and exploiting vulnerabilities in CAV systems provides a structured approach that could inform your CAN traffic manipulation experiments.

# Notable Sections and Pages

- **Section II: Motivation and Background (Pages 516-518)**: Details the limitations of traditional fuzz testing techniques and the need for hybrid approaches. This is useful for framing your simulation testing methodology.
- **Section IV: The VulFuzz++ Framework (Pages 519-523)**: Describes the architecture and components of VulFuzz++, relevant for designing a hybrid testing setup in your experiments with CARLA and CANToolz.
- **Section V: Evaluation (Pages 524-525)**: Provides an evaluation of VulFuzz++’s performance on an autonomous driving assistance system, demonstrating its effectiveness. This section is valuable for understanding how similar testing methods can be validated in your environment.

# Recommendations

This paper is an excellent source for your thesis, particularly in the context of developing and validating hybrid testing methods for autonomous vehicles. I recommend citing it for its in-depth explanation of VulFuzz++ and its insights into enhancing vulnerability discovery using a combination of grey-box fuzzing and symbolic execution.

---

# Annotations  
(10/31/2024, 12:00:10 PM)

>[Go to annotation](zotero://open-pdf/library/items/LNF44DWD?page=516&annotation=DRAXPUKG) “In contrast to black-box fuzz testing, grey-box fuzz testing [7]–[13] validates automotive systems while acquiring some knowledge about the system. Such a testing method collects information during an execution to expand the testing coverage, assuring a thorough evaluation of various components. Grey-box fuzzers can run automatically without increasing the testing complexity, promising efficient evaluation of automotive systems. One robust fuzzer for automotive systems is Vulnerability-Oriented Fuzz Testing (VulFuzz) [13], which leverages security vulnerability metrics to direct and prioritize the testing towards the weakest components, enabling an efficient vulnerability identification. VulFuzz is explicitly designed to accommodate security testing challenges in automotive systems. Nevertheless, similar to black-box fuzzers, grey-box fuzzers fail to evaluate deep paths with complex checks, potentially leaving a large number of vulnerabilities undiscovered. For this reason, it is vital to complement greybox testing with another testing method that guarantees a comprehensive and deep evaluation of weak components.” ([Moukahal et al., 2021, p. 516](zotero://select/library/items/NV7UUZA7)) 

Grey-box Fuzzing, VulFuzz

>[Go to annotation](zotero://open-pdf/library/items/LNF44DWD?page=527&annotation=TBZZFXXB) “This research work proposes a hybrid fuzz testing framework, VulFuzz++, that combines grey-box fuzzing and concolic exploration in one tool. VulFuzz++ has three stages that expand the coverage and boost vulnerability identification while assuring minimum overhead. We evaluated VulFuzz++ against an autonomous driving system, OpenPilot. VulFuzz++ successfully achieves its goals without causing significant overhead. It augments the greybox fuzzer results and increases the discovered crashes by 50%. Moreover, it accomplishes 96.7% branch coverage. The results show that supporting grey-box fuzzing with traditional concolic execution cannot enhance crash identification; it only increases crash identification by 1%. Though VulFuzz++ increases processing time moderately, the benefits of VulFuzz++ exceed the shortcoming. For safety-critical subsystems, a comprehensive evaluation is vital to offer a reliable system.” ([Moukahal et al., 2021, p. 527](zotero://select/library/items/NV7UUZA7)) 

VulFuzz Results