---
title: "Cybersecurity of Autonomous Vehicles: A Systematic Literature Review of Adversarial Attacks and Defense Models"
authors: Mansi Girdhar, Junho Hong, John Moore
year: 2023
---

# Cybersecurity of Autonomous Vehicles: A Systematic Literature Review of Adversarial Attacks and Defense Models
##### Mansi Girdhar, Junho Hong, John Moore (2023)
[Zotero-Link](zotero://select/items/@girdharCybersecurityAutonomousVehicles2023)

Tags: #History #RealAccident #AttackerTypes #Modules #Sensor #Jamming #Spoofing #Infrastructure #Architecture #Braking #Spoofing #DoS #DDoS #RSU #Manipulation #Hijacking #Vulnerabilities #SafetySecurity #CIA #SAELevels #Adversarial #MachineLearning #AI 

>[!ABSTRACT]-
>


---

# Summary

- The paper provides a **systematic literature review** of adversarial attacks and defense models in the context of autonomous vehicles (AVs). It examines the integration of **deep learning (DL)** in AVs and the associated cybersecurity challenges, emphasizing how AI models' vulnerabilities expand the attack surface in autonomous driving.
- The authors explore different types of **adversarial machine learning (AML)** attacks and the effectiveness of various defense strategies. They highlight several documented instances of AV crashes due to AI misclassification and emphasize the need for more robust defenses against AI-targeted threats.
- The review also discusses **AI-based intrusion detection systems (IDS)** and defensive models to counter these attacks, stressing the importance of **explainable AI** and model interpretability for effective defense strategies.

# Relevancy

- **Focuses on AI and CAN Vulnerabilities**: The emphasis on adversarial attacks targeting AI components in AVs aligns with your work on manipulating CAN traffic and testing AV vulnerabilities in simulated environments like CARLA.
- **Presents Defensive Strategies**: The discussion of AI-based IDS and AML defense models provides insights into how similar methodologies could be integrated into your experiments with CAN traffic manipulation.
- **Provides a Comprehensive Review**: The systematic overview of AML in AVs offers a rich source of background information that could strengthen the theoretical foundation of your thesis.

# Notable Sections and Pages

- **Section II: Overview of AI in Autonomous Vehicles (Pages 2-4)**: Provides context on the role of AI in AV systems, foundational for your exploration of CAN vulnerabilities and AI integration in AV security.
- **Section IV: Adversarial ML Attacks (Pages 6-8)**: Details the different AML attack types and their impact on AV systems, directly applicable for designing and understanding attack scenarios in your simulations.
- **Section VI: Defense Models (Pages 10-12)**: Outlines various AI-based defensive models and their effectiveness, which is valuable for developing and testing your defense strategies in CARLA.
- **Section VII: Future Challenges (Pages 13-14)**: Highlights the gaps in current defense mechanisms and future research directions, relevant for identifying areas where your thesis can contribute new insights.

# Recommendations

This paper is a crucial addition to your thesis literature. It offers a comprehensive review of adversarial attacks and defense strategies specific to AI in autonomous vehicles, which can support both the theoretical and practical aspects of your work. I recommend citing it for its in-depth exploration of AI vulnerabilities and defense mechanisms relevant to your experiments with CAN traffic manipulation.

---

# Annotations  
(11/2/2024, 7:27:05 PM)

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=417&annotation=Y4LCFA9Z) “For instance, Google, one of the most extensive networks, developed and outfitted an autonomous car with lane keeping and lane changing applications in 2010 [3]. General Motors (GM) developed the internet of vehicles (IoV)-based ENV series of smart cars to achieve automatic driving and parking in 2017. In a similar vein, Toyota debuted the Lexus LS460 L in 2010, which had an advanced parking assist system [4]. Tesla, an American automotive company, launched the Autopilot 8.1 system, enhancing the performance of existing autonomous cars [5]. Additionally, it currently offers “full self-driving” to owners of private vehicles and provides “self-driving mode” in its automobiles. Hence, these events mark a remarkable landmark in AV development.” ([Girdhar et al., 2023, p. 417](zotero://select/library/items/U5Z2AKK7)) 

History

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=418&annotation=AIEB4APW) “For instance, 6 million car accidents happen annually in the USA, and the primary reasons behind these crashes include speeding, distraction, alcohol, and reckless driving [8], although these crashes can be dramatically reduced by using AD technology as supporting tools for drivers or in full automation. Contrary to the claims, however, even AVs are not safe from external threats [9]. Several crash incidents have been reported due to AVs’ erroneous or abnormal behavior in uncertain, complex, and unseen environments. There are some specific examples of notable crashes. For instance, a Tesla AV operating in “Autopilot” mode resulted in a death in Florida on May 7, 2016 [10]. Similarly, an Uber with a self-driving system collided with a pedestrian in Tempe, Arizona, on November 20, 2018 [11]. Also, Uber had been involved in 37 other crashes before the fatal accident in 2018.” ([Girdhar et al., 2023, p. 418](zotero://select/library/items/U5Z2AKK7)) 

RealAccidents

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=418&annotation=KU5QRFSZ) “It can be assumed that attackers could identify the existing vulnerabilities and hack the AI applications to initiate a car accident or steal confidential information. So, it is not wrong to assume that if defenders can utilize ML technology to protect the system, it will not be long before it is in the hands of an adversary to evade detection. In these applications, an adversary could be a hostile force intent on causing congestion or accidents or could even simulate peculiar circumstances that reveal weaknesses in a particular AI application. In other words, an attacker may design specific attacks to deceive the AI systems by disseminating carefully crafted patterns in the environment and thus induce unexpected behavior of the AV [17].” ([Girdhar et al., 2023, p. 418](zotero://select/library/items/U5Z2AKK7)) 

AttackerTypes

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=420&annotation=3XXB42VE) “The ML pipeline of an AV, as illustrated in Fig. 2, utilizes four primary interconnected modules, namely, 1) environmental perception, 2) prediction, 3) planning, and 4) decision-making and control, to link unprocessed sensory inputs and actuator control outputs [42]. These ML-based modules define the driving task elements of the AVs. They are in charge of reproducing complex data-processing and decision-making capabilities that combine to provide a feedback mechanism for supporting self-driving.” ([Girdhar et al., 2023, p. 420](zotero://select/library/items/U5Z2AKK7)) 

Modules

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=426&annotation=GE4WR8AU) “Sensor Jamming or Spoofing Attacks: One could jam or blind AV sensors [189]. Hence, the attacker may tamper with the AI model, feed erroneous data into the algorithm, or purposefully give inadequate data, reducing the efficacy of automated decision-making. For instance, by directly reflecting light back at the scanner unit that has the same frequency as the laser reflecting on the target, one may show how the LiDAR sensor could be interfered with [190]. A similar attack is performed in [191], where a LiDAR sensor is compromised. Additionally, the vehicle’s control unit is misled into thinking a big item is in front of the car, which makes it halt. Further, recent works have” ([Girdhar et al., 2023, p. 426](zotero://select/library/items/U5Z2AKK7)) 

Sensor, Jamming, Spoofing

![](8QPEELVC.png)  
>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=426&annotation=8QPEELVC)  
([Girdhar et al., 2023, p. 426](zotero://select/library/items/U5Z2AKK7)) 

Infrastructure, Architecture

![](VTHTUZW7.png)  
>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=426&annotation=VTHTUZW7)  
([Girdhar et al., 2023, p. 426](zotero://select/library/items/U5Z2AKK7)) 

braking, spoofing

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=426&annotation=DWQQTL5Q) “demonstrated the possibility of saturating LiDAR sensors [192]. In [193], the authors spoofed LiDAR sensors and their underlying ML-based perception method. An adversarial ML attack is demonstrated in Fig. 4, where spoofing is executed. In this adversarial ML attack, camera signals are re-transmitted to provide false information to the camera, thereby misleading it in target detection and, as a result, confusing the detection of the actual target and increasing the risk of collision.” ([Girdhar et al., 2023, p. 426](zotero://select/library/items/U5Z2AKK7))

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=426&annotation=KPSPSCUN) “Denial of Service (DoS)/Distributed DoS (DDoS) Attacks: DoS attacks involve flooding a host with an enormous amount of information to overload it, effectively preventing it from receiving or processing information coming in from legitimate users. A variety of communication routes are available to AVs, all of which are intended to receive and transmit the data required for safe navigation and motoring. Vehicle-tosatellite, vehicle-to-vehicle (V2V), vehicle-to-internet, and other communication technologies are among them. Additionally, there is internal communication through the controller area network (CAN). Any of these communication channels can be broken, which can impair the car’s ability to function properly and effectively render it blind to its surroundings. This adversely affects its accessibility and impedes necessary operations for AD. DDoS attacks attempt to block these lines of communication. The authors of [194] studied DoS attacks against a platoon of intelligent vehicles. Another work [195] shows a GNSS DoS attack on an AV. Attackers can obstruct the camera’s ability to recognize objects, roads, and warning signs by using DoS attacks. DoS attacks can potentially negatively impact the braking system, resulting in the automobile stopping abruptly or being unable to stop.” ([Girdhar et al., 2023, p. 426](zotero://select/library/items/U5Z2AKK7)) 

DoS, DDoS

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=427&annotation=58JX6RCC) “Manipulating Vehicle Communications: Hijacking and manipulating communication channels can affect AD operations. This enables an attacker to alter sent sensor readings or incorrectly decipher messages from the road infrastructure. As a result, a vehicle may act differently from what was planned or designed for it. The hacker might inject malicious messages and manipulate the communication between the two entities. This way, they might get unauthorized access to vehicle electronic control units (ECUs) or the roadside unit (RSU).” ([Girdhar et al., 2023, p. 427](zotero://select/library/items/U5Z2AKK7)) 

RSU, Manipulation, Hijacking

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=427&annotation=SGRC9T2Y) “Information Disclosure: Given the large amount of private and sensitive data saved and used by vehicles for AD, including vital information on the AI components, a specific incentive emerges for prospective adversaries to obtain this kind of data and trigger a data breach.” ([Girdhar et al., 2023, p. 427](zotero://select/library/items/U5Z2AKK7)) 

data breach

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=429&annotation=K2XG4ZEL) “An increase in electronic components in a vehicle corresponds to a growth in the number of attack vectors through which an attacker might endeavor to get access to the vehicle’s information and data or even modify its operations. Automobile manufacturers strive to produce AVs that follow a security cycle of design and development, which involves planning, manufacturing, and monitoring software and hardware throughout the vehicle’s lifespan to mitigate cybersecurity threats. Certain automakers’ mechanisms to deal with cybersecurity issues are diverse and numerous, including assessing threat data, sharing them with external partners, and designing and pushing out security upgrades to vehicles. Comprehensive cybersecurity techniques are required to deal with an increasingly complex cyber-threat scenario (e.g., interference related to driving securely, manipulation, and fraud), which is becoming more prevalent.” ([Girdhar et al., 2023, p. 429](zotero://select/library/items/U5Z2AKK7)) 

Vulnerabilities

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=429&annotation=VXZWWNPY) “AV safety is highly influenced by the integrity of signal transmissions, which implies that signals from vehicles usually are acted upon only if they are authentic and transmitted and received correctly. The availability of secure vehicle functionality is the primary aim of safety, which frequently necessitates the design of a system that is both efficient and fail-safe (i.e., redundant). Therefore, an emphasis on the confidentiality, integrity, and availability (CIA) of a system or information is essential for cybersecurity efforts. As a result, cybersecurity evaluates whether a system may be controlled in a way that compromises these features. Overall, technology has evolved to the point where vehicles cannot maintain a safe condition unless they also operate correctly in a secure way. Hence, cybersecurity concepts and practices are necessary during the production development processes to guarantee that attackers do not obtain arbitrary control over a vehicle’s driving systems [230].” ([Girdhar et al., 2023, p. 429](zotero://select/library/items/U5Z2AKK7)) 

SafetySecurity, CIA

>[Go to annotation](zotero://open-pdf/library/items/M9XTQIR7?page=431&annotation=N7QKB5M7) “In order to help human drivers in specific situations, such as preventing lane drift or assisting the driver in coming to a complete halt in time to avoid a potential AV crash, the thriving automated vehicles currently come equipped with ADAS safety capabilities. The future L4 and L5 vehicles, on the other hand, will be equipped with advanced ADS functionality, which relies solely on sophisticated AI/ML algorithms for sensor processing, sensor fusion, scene creation, and motion planning, hence allowing the vehicle to sense its environment and make informed decisions. This article has therefore outlined the importance of ML and DL technologies in AVs in, for instance, object classification and detection, SS, etc. However, recent investigations and groundwork on adversarial attacks elicit suspicions about AVs’ security and potency. It is inferred that the uptake of these advanced AI technologies has introduced a range of vulnerabilities in the AVs featuring them. This article presented a detailed investigation of adversarial attacks on the automated driving ecosystem. In addition, a survey of adversarial defense models for improving resistance against adversarial attacks on ML components in AVs has been discussed. In order to strengthen resilience and secure the ML and training data for AVs, the authors have especially addressed the significance of generic defense techniques. Finally, the authors expect that the academic community will use this study to help discover any loopholes and withholdings in the existing studies on adversarial attacks and defense strategies for ADSs.” ([Girdhar et al., 2023, p. 431](zotero://select/library/items/U5Z2AKK7)) 

SAELEvels, Adversarial, ML, AI