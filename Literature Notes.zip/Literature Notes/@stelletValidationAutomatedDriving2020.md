---
title: Validation of automated driving – a structured analysis and survey of approaches
authors: Jan Erik Stellet, Matthias Woehrle, Tino Brade, Alexander Poddey, Wolfgang Branz
year: 2020
---

# Validation of automated driving – a structured analysis and survey of approaches
##### Jan Erik Stellet, Matthias Woehrle, Tino Brade, Alexander Poddey, Wolfgang Branz (2020)
[Zotero-Link](zotero://select/items/@stelletValidationAutomatedDriving2020)

Tags: #SAELevels #PEGASUS

>[!ABSTRACT]-
>


---

# Summary

- The paper provides a comprehensive analysis of the current validation approaches for automated driving (AD) systems, focusing on the challenges and complexities of ensuring safety for **SAE Level 3-5** vehicles. It highlights the limitations of statistical field tests and emphasizes the need for advanced methods such as scenario-based and simulation-driven validation.
- It discusses various challenges in validation, such as the **representativeness challenge** (ensuring that test scenarios accurately represent real-world conditions), the **closed-loop challenge** (addressing interactions between the vehicle and its environment), and the **modelling challenge** (ensuring accuracy in simulation models).
- The paper also presents specific validation frameworks like **PEGASUS** (a German project focusing on scenario-based validation) and **shadow mode testing**, which utilize real-world driving data combined with simulation.

# Relevancy

- **Explores Simulation Approaches**: The emphasis on simulation-based validation and scenario generation aligns with your objective of using CARLA and Autoware to test CAN traffic manipulation.
- **Addresses Validation Challenges**: The paper's discussion on validation challenges, especially related to sensor interactions and system modeling, is valuable for understanding the limitations of using simulation environments and how these can be addressed.
- **Provides Framework Examples**: It details frameworks like PEGASUS that combine field and simulation tests, offering a structured approach that could be adapted for your experiments in assessing the impact of CAN traffic manipulation on vehicle behavior.

# Notable Sections and Pages

- **Section 3: Problem Description and Challenges (Pages 4-6)**: This section discusses key validation challenges, including the closed-loop and modeling challenges, which are crucial for setting up accurate simulations in CARLA.
- **Section 4.3: PEGASUS: Scenario-Based Approach (Pages 8-9)**: Describes the PEGASUS framework and its use of scenario-based testing, providing insights into building effective test cases in simulation environments.
- **Section 4.1: Passive AD (Shadow Mode) (Pages 7-8)**: Explains the use of shadow mode testing, which combines real-world driving data with simulation. This method is particularly useful for understanding how real data can validate or enhance simulation-based tests.

# Recommendations

This paper is an excellent addition to your thesis literature. It provides a detailed examination of simulation-based validation, focusing on the challenges and frameworks that align with your goals of testing CAN traffic manipulation and validating results in a controlled environment. I recommend citing it for its insights into simulation limitations and best practices for creating realistic test scenarios.

---

# Annotations  
(10/30/2024, 6:25:35 PM)

>[Go to annotation](zotero://open-pdf/library/items/6YRIK9FL?page=1&annotation=SM6FUL3Z) “Although modern driver assistance systems (SAE L2 [1]) can temporarily take over control of the vehicle, they do not actually take over the responsibility which remains with the human driver. Thus, advancing to automated driving (AD) of SAE L3 and beyond poses much higher requirements for the development and validation of safe systems. Over the last years, this topic has received remarkable attention in industry and academia. However, there seems to be no consensus yet.” ([Stellet et al., 2020, p. 1](zotero://select/library/items/NWQTSDZT)) 

SAELevels,

>[Go to annotation](zotero://open-pdf/library/items/6YRIK9FL?page=6&annotation=3FTG2CIL) “PEGASUS4, a German publicly funded project, aimed at developing methods for ensuring the safety of automated driving on the example of a SAE L3 (conditional automation) ‘highway chauffeur’ function. The core of PEGASUS approach are scenarios. Their description is based on a six-layer model to compositionally model static and dynamics aspects in a joint description [21]. Scenarios can be identified from system knowledge [22], domain modelling [21,23] and field observation [17]. Scenarios feature parameters that can be varied in order to increase their coverage. Scenarios are used as test cases that are executed and evaluated in simulation or on test tracks. Corresponding criticality metrics are used to determine the automated driving capabilities. Virtual testing enables reproducible tests and large scale parameter variations. One goal of test track testing is a point-wise validation of the simulation model. Additionally, real-world drive tests are conducted.” ([Stellet et al., 2020, p. 6](zotero://select/library/items/NWQTSDZT)) 

SAELevels, PEGASUS
