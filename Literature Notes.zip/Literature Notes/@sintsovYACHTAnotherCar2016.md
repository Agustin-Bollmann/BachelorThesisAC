---
title: YACHT - Yet Another Car Hacking Tool
authors: Alexey Sintsov
year: 2016
---

# YACHT - Yet Another Car Hacking Tool
##### Alexey Sintsov (2016)
[Zotero-Link](zotero://select/items/@sintsovYACHTAnotherCar2016)

Tags: #CANTools #CAN #CANStructure 

>[!ABSTRACT]-
>


---

# Summary

- The presentation introduces **YACHT**, an open-source Python-based tool designed for automotive penetration testing. The tool aims to simplify **CAN bus reverse engineering**, **black-box analysis**, and **fuzz testing** using a modular framework that supports multiple interfaces and buses.
- Sintsov describes the **attack surfaces** in modern vehicles, including local interfaces (e.g., CAN, OBD-II, and Ethernet), and remote components (e.g., GSM, Bluetooth, and Wi-Fi). The talk emphasizes both **direct and remote attack vectors** and discusses methods like **man-in-the-middle (MITM)** attacks and CAN message injection.
- The presentation also highlights **CANToolz**, a component within YACHT, showcasing how it supports different testing modules, including firewalls, fuzzing modules, CAN traffic emulation, and UDS scanning for vulnerabilities.

# Relevancy

- **Explores Reverse Engineering Techniques**: The focus on CAN bus reverse engineering aligns with your interest in manipulating CAN traffic and testing vulnerabilities within simulators like CARLA.
- **Provides Tools and Methodologies**: The introduction of CANToolz as part of YACHT provides practical tools and methods that you could use or adapt in your thesis experiments involving CAN traffic manipulation.
- **Details Multiple Attack Vectors**: The paper discusses both local and remote attack vectors, directly supporting your aim to test CAN vulnerabilities and explore both physical and remote access methods.

# Notable Sections and Pages

- **Attack Surface Overview (Pages 8-10)**: Lists potential attack vectors and interfaces, providing a comprehensive view of possible vulnerabilities relevant for testing in simulation environments.
- **CANToolz Features and Use Cases (Pages 15-20)**: Details the features of CANToolz, including CAN message manipulation and fuzzing, essential for understanding how to implement and test CAN traffic manipulation.
- **Demonstrations and Scenarios (Pages 25-28)**: Shows real-world examples and simulations using YACHT and CANToolz, which can inform the design of your experiments and provide a benchmark for testing methodologies.

# Recommendations

This presentation is a critical addition to your thesis literature as it provides hands-on tools and methods for automotive security testing, particularly focused on CAN bus reverse engineering. I recommend citing it for its practical insights into penetration testing techniques and the detailed demonstration of tools like CANToolz.

---

# Annotations  
(11/5/2024, 10:51:37 PM)

![](DCME68BC.png)  
>[Go to annotation](zotero://open-pdf/library/items/Q68P63HE?page=8&annotation=DCME68BC)  
([Sintsov, 2016, p. 8](zotero://select/library/items/4K93R87T)) 

CAN Topology

![](9JLM26YM.png)  
>[Go to annotation](zotero://open-pdf/library/items/Q68P63HE?page=9&annotation=9JLM26YM)  
([Sintsov, 2016, p. 9](zotero://select/library/items/4K93R87T)) 

CAN Bus

