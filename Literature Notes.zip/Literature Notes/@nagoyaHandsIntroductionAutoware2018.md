---
title: Hands-on Introduction to Autoware
authors: University Nagoya, Autoware
year: 2018
---

# Hands-on Introduction to Autoware
##### University Nagoya, Autoware (2018)
[Zotero-Link](zotero://select/items/@nagoyaHandsIntroductionAutoware2018)

Tags: #Autoware #ROS #Topics #Localization #TrafficCongestion #TrafficLight

>[!ABSTRACT]-
>


---

# Summary

- This tutorial introduces **Autoware** as an open-source platform for developing and testing autonomous vehicle technologies, highlighting its applications in perception, planning, and control systems. The software integrates well with the **Robot Operating System (ROS)**, making it a versatile tool for researchers and developers.
- It covers the **architecture of autonomous systems**, discussing how Autoware uses various sensors (e.g., LiDAR, cameras, IMU) for object detection, localization, and decision-making processes.
- The document details the implementation and configuration of **3D map generation**, **path planning**, and **sensor fusion** modules, providing insights into how these elements work together to enable autonomous driving capabilities.

# Relevancy

1. **Offers Practical Insights into Autoware’s Capabilities**: Given your focus on using CARLA and Autoware for simulation, this tutorial provides foundational knowledge on setting up and using Autoware’s components.
2. **Covers Perception, Planning, and Control**: Understanding these elements is crucial when manipulating CAN traffic and testing how the software reacts, aligning with your thesis experiments.
3. **Illustrates System Configuration and Testing Methods**: The detailed guidance on configuring Autoware for various scenarios can help you design and execute CAN manipulation tests effectively.

# Notable Sections and Pages

- **Introduction and Autoware Architecture (Pages 1-5)**: Provides an overview of the software stack and how each module contributes to the autonomous driving process.
- **Sensor Integration and Perception (Pages 10-20)**: Describes the setup of sensors and perception algorithms, useful for understanding how the system processes input data for autonomous functions.
- **Planning and Decision-Making (Pages 30-40)**: Discusses how Autoware generates paths and makes driving decisions, relevant for your experiments manipulating CAN messages and observing system responses.

# Recommendations

This tutorial is a valuable resource for your thesis. It offers practical knowledge on the configuration and capabilities of Autoware, directly supporting your research on simulating and testing CAN traffic in autonomous vehicles. I recommend citing it for its detailed explanation of autonomous vehicle software stack implementation and testing.

---

# Annotations  
(11/4/2024, 6:40:36 PM)

>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=2&annotation=SYISYYQE) “Vehicles capable of perceiving and understanding it’s environment to autonomously navigate through it.” ([Nagoya and Autoware, 2018, p. 2](zotero://select/library/items/VJIRGM8N))

![](LFYXXNBD.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=41&annotation=LFYXXNBD)  
([Nagoya and Autoware, 2018, p. 41](zotero://select/library/items/VJIRGM8N)) 

Autoware High Level

![](DXQZ39W6.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=42&annotation=DXQZ39W6)  
([Nagoya and Autoware, 2018, p. 42](zotero://select/library/items/VJIRGM8N)) 

AutowareandROS

![](88KPKVAU.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=45&annotation=88KPKVAU)  
([Nagoya and Autoware, 2018, p. 45](zotero://select/library/items/VJIRGM8N)) 

ROS Topics

![](K7F9WFQ8.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=46&annotation=K7F9WFQ8)  
([Nagoya and Autoware, 2018, p. 46](zotero://select/library/items/VJIRGM8N)) 

ROS Topics

![](ELTXV78M.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=49&annotation=ELTXV78M)  
([Nagoya and Autoware, 2018, p. 49](zotero://select/library/items/VJIRGM8N)) 

ROS Topics

![](IKT8ET3Z.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=117&annotation=IKT8ET3Z)  
([Nagoya and Autoware, 2018, p. 117](zotero://select/library/items/VJIRGM8N)) 

Autoware Localization

![](9Z9U7MCX.png)  
>[Go to annotation](zotero://open-pdf/library/items/B62THXPF?page=149&annotation=9Z9U7MCX)  
([Nagoya and Autoware, 2018, p. 149](zotero://select/library/items/VJIRGM8N)) 

Autoware Traffic Light