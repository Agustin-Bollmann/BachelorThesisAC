---
title: Winning the 3rd Japan Automotive AI Challenge – Autonomous Racing with the Autoware.Auto Open Source Software Stack
authors: Zirui Zang, Renukanandan Tumu, Johannes Betz, Hongrui Zheng, Rahul Mangharam
year: 2022
---

# Winning the 3rd Japan Automotive AI Challenge – Autonomous Racing with the Autoware.Auto Open Source Software Stack
##### Zirui Zang, Renukanandan Tumu, Johannes Betz, Hongrui Zheng, Rahul Mangharam (2022)
[Zotero-Link](zotero://select/items/@zangWinning3rdJapan2022)

Tags: #Autoware #ROS2 #Modules #Perception #Planning #Control 

>[!ABSTRACT]-
>The 3rd Japan Automotive AI Challenge was an international online autonomous racing challenge where 164 teams competed in December 2021. This paper outlines the winning strategy to this competition, and the advantages and challenges of using the Autoware.Auto open source autonomous driving platform for multi-agent racing. Our winning approach includes a lane-switching opponent overtaking strategy, a global raceline optimization, and the integration of various tools from Autoware.Auto including a Model-Predictive Controller. We describe the use of perception, planning and control modules for high-speed racing applications and provide experience-based insights on working with Autoware.Auto. While our approach is a rule-based strategy that is suitable for non-interactive opponents, it provides a good reference and benchmark for learning-enabled approaches.


---

# Summary

- The paper describes the implementation of **Autoware.Auto** in the 3rd Japan Automotive AI Challenge, where the software stack was adapted for racing at speeds up to 160 km/h. The authors highlight how they modified perception, planning, and control modules for this high-speed application.
- The racing setup included a **lane-switching and overtaking strategy**, integrating a **Model Predictive Controller (MPC)** for dynamic vehicle control. The authors detail how the LiDAR sensor was used for obstacle detection and how data processing was optimized to minimize latency, crucial for real-time control in high-speed environments.
- The paper also discusses the **limitations** of the Autoware.Auto stack for high-speed racing, noting that some modules originally designed for low-speed applications (e.g., valet parking) needed significant tuning to be effective in racing scenarios.

# Relevancy

- **Demonstrates Autoware.Auto’s Adaptability**: The modifications made for high-speed racing provide insights into how Autoware can be configured for testing CAN traffic manipulation and autonomous control in dynamic environments like CARLA.
- **Explores Advanced Control Techniques**: The use of an MPC and optimized data processing aligns with your focus on manipulating and testing CAN traffic efficiently in simulated environments.
- **Highlights Real-Time Challenges**: Understanding the latency and performance challenges faced in high-speed scenarios can inform your approach to ensuring realistic and effective simulations when testing CAN vulnerabilities.

# Notable Sections and Pages

- **Section II-A: Autoware Open Source Stack (Pages 2-3)**: Details the architecture and components used, essential for understanding how to implement and adapt Autoware in your experiments.
- **Section II-B: Opponent Detection (Pages 3-4)**: Explains how LiDAR data is processed for obstacle detection, which is relevant for designing and evaluating perception systems in simulations.
- **Section III: Results (Page 5)**: Provides performance outcomes and insights into the effectiveness of the approach, which can guide the development of your testing methodology.

# Recommendations

This paper is a valuable addition to your thesis literature. It offers practical insights into adapting Autoware for high-speed racing, applicable to configuring and testing the software for CAN traffic manipulation in CARLA. I recommend citing it for its detailed evaluation of Autoware.Auto’s capabilities and limitations in dynamic environments.

---

# Annotations  
(11/4/2024, 6:24:39 PM)

>[Go to annotation](zotero://open-pdf/library/items/SHI79HRU?page=2&annotation=PSNT25V9) “Autoware is the world leading open-source autonomous driving software that combines implementations of perception, planning and control for autonomous vehicle development into one coherent software platform (see Fig. 2). There are two releases of this software, Autoware.AI, which runs on Robot Operating System version 1 (ROS1), and the newer Autoware.Auto, which runs on ROS2 (https://ros.org). Autoware.Auto improves reproducibility and determinism across different system levels, provides modular design, productiongrade code and review practices, as well as integrated testing. Previously, Autoware.Auto was used to develop slow-speed autonomous valet parking and cargo delivery services. This competition uses Autoware.Auto for racing with speeds up to 160km/h and for overtaking maneuvers at the limits of the vehicle’s dynamics. To support reproducible environments, docker containers with ROS2 Foxy and Autoware.Auto running on Ubuntu 20.04 are distributed to all participants. The interface to the LGSVL simulator, as well as the basic modules needed to get the simulated Dallara IL-15 running, were all provided by Autoware.Auto.” ([Zang et al., 2022, p. 2](zotero://select/library/items/WCDNLLQX)) 

Autoware, ROS2, Modules, perception, planning, control

![](MZQZJSBN.png)  
>[Go to annotation](zotero://open-pdf/library/items/SHI79HRU?page=2&annotation=MZQZJSBN)  
([Zang et al., 2022, p. 2](zotero://select/library/items/WCDNLLQX)) 

Autoware components