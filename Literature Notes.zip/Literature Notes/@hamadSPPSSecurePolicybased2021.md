---
title: "SPPS: Secure Policy-based Publish/Subscribe System for V2C Communication"
authors: Mohammad Hamad, Emanuel Regnath, Jan Lauinger, Vassilis Prevelakis, Sebastian Steinhorst
year: 2021
---

# SPPS: Secure Policy-based Publish/Subscribe System for V2C Communication
##### Mohammad Hamad, Emanuel Regnath, Jan Lauinger, Vassilis Prevelakis, Sebastian Steinhorst (2021)
[Zotero-Link](zotero://select/items/@hamadSPPSSecurePolicybased2021)

Tags: #CIA #V2C #PubSub 

>[!ABSTRACT]-
>


---

# Summary

- The paper proposes **SPPS**, a secure policy-based publish/subscribe system designed to enhance **Vehicle-to-Cloud (V2C)** communication while addressing confidentiality, integrity, and access control challenges. The system allows vehicles to securely publish messages to the cloud using a **policy-based encryption** model.
- SPPS employs a **distributed secret sharing** method where encryption keys are split and stored across multiple semi-honest services called **KeyStores**. Authorized subscribers can retrieve these shares based on predefined security policies set by the vehicle. This ensures secure data transmission without trusting the brokers managing the message traffic.
- The authors compare SPPS with traditional methods like **SSL/TLS** and **Attribute-Based Encryption (ABE)**, demonstrating that SPPS achieves lower overhead and better performance, especially when re-establishing connections in scenarios with unreliable network conditions.

# Relevancy

- **Explores Secure Communication in Connected Vehicles**: While the focus is on V2C communication, the insights into secure message transmission and encryption policies can inform your understanding of how secure communication is implemented in autonomous systems.
- **Discusses Encryption and Key Management**: The use of secret sharing and secure key management may provide ideas for implementing similar security mechanisms in CAN traffic manipulation and testing scenarios.
- **Highlights Performance and Security Trade-offs**: The performance analysis of SPPS against other security protocols could offer a perspective on the limitations and potential optimizations applicable to CAN bus security.

# Notable Sections and Pages

- **Section II: System and Threat Model (Pages 1-2)**: Outlines the threat model, providing insights into the types of attacks and security measures relevant to vehicle communication.
- **Section III: Policy-Based Trust Management (Pages 3-5)**: Explains how policies manage access control and encryption, useful for understanding secure communication mechanisms that could be adapted for CAN messages.
- **Section V: Protocol Analysis (Pages 6-7)**: Discusses the security and performance evaluation of SPPS, highlighting key takeaways for implementing efficient security systems.

# Recommendations

This paper provides valuable insights into secure communication methods and encryption techniques, though its direct application to CAN traffic testing may be limited. It’s worth citing for its innovative approach to secure V2C communication and its analysis of protocol performance.

---

# Annotations  
(11/7/2024, 9:44:55 PM)

>[Go to annotation](zotero://open-pdf/library/items/QJXNMJKQ?page=1&annotation=2F9UUPLJ) “Today, vehicles are equipped with many smart sensors that collect a vast amount of data. V2C communication will allow vehicles to benefit from cloud computation power to handle this processing via different services in order to enhance the intelligent transportation system. V2C communication faces many challenges, such as the unstable connectivity with cloud services and the need to communicate securely with many services owned by different authorities. The Pub/Sub model is a communication paradigm that enables a sender, known as a publisher, to disseminate messages to multiple receivers, known as subscribers, at once via a mediator, known as a broker. The Pub/Sub pattern provides full decoupling in time, space, and flow between publishers and subscribers, which are important properties of distributed systems. These characteristics make the Pub/Sub model an excellent candidate to implement V2C communication. However, in terms of security, the Pub/Sub model is susceptible to a wide variety of security threats that affect the confidentiality, integrity, and access control of published data [1].” ([Hamad et al., 2021, p. 1](zotero://select/library/items/A5PY8IXT)) 

CIA, V2C, PubSub

>[Go to annotation](zotero://open-pdf/library/items/QJXNMJKQ?page=6&annotation=22RL9UB9) “Using the Pub/Sub model to support V2C communication seems promising if security concerns are solved. This paper proposes a secure policy-based Pub/Sub model that allows vehicles to encrypt and control access to the published messages. Our solution leverages semi-honest KeyStores to guarantee the end-to-end confidentiality of V2C communication without trusting the brokers. Experimental results show that our solution outperforms alternative state-of-the-art methods such as SSL/TLS and ABE. Based on that, our solution is considered as a very efficient method to ensure end-to-end secure communication using Pub/Sub model.” ([Hamad et al., 2021, p. 6](zotero://select/library/items/A5PY8IXT))